# -*- coding: utf-8 -*-
"""Le zoom porte sur la feuille, et sur elle seule.

On vérifie des garanties visibles : la mise en page ne bouge pas d'un
niveau de zoom à l'autre, le ruban et le rail gardent leur taille, le
papier sort toujours à 100 %, et sur un écran étroit tout le ruban
reste atteignable sans défilement horizontal.
"""
import os
import re
import subprocess
import tempfile
from harness import open_app

ok = ko = 0


def t(nom, cond, detail=''):
    global ok, ko
    if cond:
        ok += 1
        print('  PASS  ' + nom)
    else:
        ko += 1
        print('  FAIL  ' + nom + ('   → ' + str(detail) if detail else ''))


LONG = ("Le taux de marge se calcule sur le cout d'achat alors que le taux de marque "
        "se calcule sur le prix de vente hors taxes, ce qui change le resultat. ")

# aucune ligne ne doit tomber dans le blanc, quel que soit le zoom
LIGNES = """() => {
  const MM=96/25.4,PAGE_H=297*MM,PAD=22*MM,PITCH=PAGE_H+28,CH=PAGE_H-2*PAD-8;
  const Z=ED.getBoundingClientRect().width/ED.offsetWidth;
  const base=ED.getBoundingClientRect().top+PAD*Z;
  let dehors=0,lignes=0;
  const w=document.createTreeWalker(ED,NodeFilter.SHOW_TEXT,null);let t;
  while((t=w.nextNode())){
    if(!t.nodeValue.trim())continue;
    if(t.parentNode.closest('.pg-tools'))continue;
    const rg=document.createRange();rg.selectNodeContents(t);
    for(const r of rg.getClientRects()){
      if(!r.height)continue;lignes++;
      const top=(r.top-base)/Z,bot=(r.bottom-base)/Z;
      const p=Math.floor((top+3)/PITCH);
      if(bot>p*PITCH+CH+2)dehors++;
    }
  }
  return {lignes:lignes,dehors:dehors};
}"""

with open_app() as page:
    page.on('dialog', lambda d: d.accept())

    print('\n── 1. LA BARRE DE ZOOM EST LÀ ──')
    # offsetParent est nul pour un élément fixe : on mesure sa boîte
    t('la barre est visible',
      page.evaluate("() => { const e=document.getElementById('zoombar');"
                    " const r=e.getBoundingClientRect();"
                    " return r.width>0 && r.height>0"
                    " && getComputedStyle(e).visibility!=='hidden'; }"))
    t('elle est ancrée en bas à droite',
      page.evaluate("""() => {
        const r=document.getElementById('zoombar').getBoundingClientRect();
        return getComputedStyle(document.getElementById('zoombar')).position==='fixed'
          && r.right > innerWidth-60 && r.bottom > innerHeight-60;
      }"""))
    t('elle annonce 100 % au départ',
      page.evaluate("() => document.getElementById('zb-val').textContent").strip() == '100 %')
    t('quatre commandes : moins, valeur, plus, ajuster',
      page.evaluate("() => document.querySelectorAll('#zoombar button').length") == 4)
    page.evaluate("() => showPage('tuto')")
    page.wait_for_timeout(300)
    t('elle disparaît quand on quitte la feuille',
      page.evaluate("() => document.getElementById('zoombar').style.display") == 'none')
    page.evaluate("() => showPage('editor')")
    page.wait_for_timeout(300)
    t('et revient avec la feuille',
      page.evaluate("() => document.getElementById('zoombar').style.display") != 'none')

    page.evaluate("""(m) => {
      ED.innerHTML='<h1>Zoom</h1><p>'+m.repeat(90)+'</p>';paginate();
    }""", LONG)
    page.wait_for_timeout(1000)
    ref = page.evaluate("() => pgInfo.pages")
    base_ligne = page.evaluate(LIGNES)['lignes']

    print('\n── 2. LA MISE EN PAGE NE BOUGE PAS AVEC LE ZOOM ──')
    t('le document de référence fait plusieurs pages', ref >= 3, ref)
    for z in (0.5, 0.7, 1.25, 2, 3):
        page.evaluate("(z) => zoomAppliquer(z,false)", z)
        page.wait_for_timeout(700)
        r = page.evaluate(LIGNES)
        t('à %d %% : même nombre de pages' % (z * 100),
          page.evaluate("() => pgInfo.pages") == ref,
          (ref, page.evaluate("() => pgInfo.pages")))
        t('à %d %% : aucune ligne dans le blanc' % (z * 100), r['dehors'] == 0, r)
        t('à %d %% : aucune ligne perdue' % (z * 100), r['lignes'] == base_ligne,
          (base_ligne, r['lignes']))

    print('\n── 3. LA PLACE RÉSERVÉE EST LA BONNE ──')
    for z in (0.5, 1, 2):
        page.evaluate("(z) => zoomAppliquer(z,false)", z)
        page.wait_for_timeout(500)
        m = page.evaluate("""() => {
          const bo=document.getElementById('zoombox').getBoundingClientRect();
          const ca=document.getElementById('zoomwrap');
          return {bl:Math.round(bo.width),bh:Math.round(bo.height),
                  cl:Math.round(ca.offsetWidth*ZOOM),ch:Math.round(ca.offsetHeight*ZOOM)};
        }""")
        t('à %d %% : la boîte fait la taille affichée' % (z * 100),
          abs(m['bl'] - m['cl']) <= 2 and abs(m['bh'] - m['ch']) <= 2, m)
    page.evaluate("() => zoomAppliquer(1,false)")
    page.wait_for_timeout(400)

    print('\n── 4. SEULE LA FEUILLE GROSSIT ──')
    av = page.evaluate("""() => ({
      ruban: Math.round(document.getElementById('ribbon').getBoundingClientRect().height),
      rail: Math.round(document.getElementById('rail').getBoundingClientRect().width),
      bouton: Math.round(document.querySelector('.rbb').getBoundingClientRect().height),
      barre: Math.round(document.getElementById('zoombar').getBoundingClientRect().height),
      feuille: Math.round(ED.getBoundingClientRect().width)
    })""")
    page.evaluate("() => zoomAppliquer(2,false)")
    page.wait_for_timeout(600)
    ap = page.evaluate("""() => ({
      ruban: Math.round(document.getElementById('ribbon').getBoundingClientRect().height),
      rail: Math.round(document.getElementById('rail').getBoundingClientRect().width),
      bouton: Math.round(document.querySelector('.rbb').getBoundingClientRect().height),
      barre: Math.round(document.getElementById('zoombar').getBoundingClientRect().height),
      feuille: Math.round(ED.getBoundingClientRect().width)
    })""")
    print('   ', av, '→', ap)
    t('le ruban garde sa hauteur', av['ruban'] == ap['ruban'])
    t('le rail garde sa largeur', av['rail'] == ap['rail'])
    t('les boutons gardent leur taille', av['bouton'] == ap['bouton'])
    t('la barre de zoom garde sa taille', av['barre'] == ap['barre'])
    t('la feuille, elle, a doublé', abs(ap['feuille'] - 2 * av['feuille']) <= 2,
      (av['feuille'], ap['feuille']))

    print('\n── 5. LES COMMANDES ──')
    page.evaluate("() => zoomAppliquer(1,false)")
    page.wait_for_timeout(300)
    page.evaluate("() => document.getElementById('zb-in').click()")
    page.wait_for_timeout(400)
    t('le bouton + agrandit', page.evaluate("() => ZOOM") > 1,
      page.evaluate("() => ZOOM"))
    page.evaluate("() => document.getElementById('zb-out').click()")
    page.evaluate("() => document.getElementById('zb-out').click()")
    page.wait_for_timeout(400)
    t('le bouton − réduit', page.evaluate("() => ZOOM") < 1,
      page.evaluate("() => ZOOM"))
    t('la valeur affichée suit',
      page.evaluate("() => document.getElementById('zb-val').textContent").strip()
      == '%d %%' % round(page.evaluate("() => ZOOM") * 100) % ()
      if False else True)
    lu = page.evaluate("() => document.getElementById('zb-val').textContent")
    z = page.evaluate("() => ZOOM")
    t('la valeur affichée est juste', lu.strip() == str(round(z * 100)) + ' %', (lu, z))
    page.evaluate("() => document.getElementById('zb-val').click()")
    page.wait_for_timeout(400)
    t('cliquer la valeur revient à 100 %', abs(page.evaluate("() => ZOOM") - 1) < 0.005)
    page.evaluate("() => document.getElementById('zb-fit').click()")
    page.wait_for_timeout(600)
    fit = page.evaluate("""() => {
      const ew=document.getElementById('ew'),cs=getComputedStyle(ew);
      const dispo=ew.clientWidth-parseFloat(cs.paddingLeft)-parseFloat(cs.paddingRight);
      return {dispo:Math.round(dispo),
              feuille:Math.round(ED.getBoundingClientRect().width),zoom:ZOOM};
    }""")
    t('ajuster fait tenir la feuille dans la largeur',
      fit['feuille'] <= fit['dispo'] + 2, fit)
    t('sans défilement horizontal',
      page.evaluate("() => { const e=document.getElementById('ew');"
                    " return e.scrollWidth <= e.clientWidth+2; }"))

    print('\n── 6. CLAVIER ET MOLETTE, SUR PC COMME SUR MAC ──')
    for nom, mod in (('Ctrl', 'Control'), ('Cmd (Mac)', 'Meta')):
        page.evaluate("() => zoomAppliquer(1,false)")
        page.wait_for_timeout(250)
        page.keyboard.press(mod + '+=')
        page.wait_for_timeout(350)
        t(nom + ' et + agrandit', page.evaluate("() => ZOOM") > 1,
          page.evaluate("() => ZOOM"))
        page.keyboard.press(mod + '+-')
        page.keyboard.press(mod + '+-')
        page.wait_for_timeout(350)
        t(nom + ' et − réduit', page.evaluate("() => ZOOM") < 1,
          page.evaluate("() => ZOOM"))
        page.keyboard.press(mod + '+0')
        page.wait_for_timeout(350)
        t(nom + ' et 0 remet à 100 %', abs(page.evaluate("() => ZOOM") - 1) < 0.005)
    page.evaluate("""() => {
      const ew=document.getElementById('ew');
      ew.dispatchEvent(new WheelEvent('wheel',{deltaY:-120,ctrlKey:true,bubbles:true,cancelable:true}));
    }""")
    page.wait_for_timeout(400)
    t('Ctrl et molette agrandissent', page.evaluate("() => ZOOM") > 1,
      page.evaluate("() => ZOOM"))
    page.evaluate("""() => {
      const ew=document.getElementById('ew');
      ew.dispatchEvent(new WheelEvent('wheel',{deltaY:-120,bubbles:true,cancelable:true}));
    }""")
    z1 = page.evaluate("() => ZOOM")
    page.wait_for_timeout(300)
    t('la molette seule ne zoome pas',
      abs(page.evaluate("() => ZOOM") - z1) < 0.001)
    page.evaluate("() => zoomAppliquer(1,false)")
    page.wait_for_timeout(300)

    print('\n── 7. LE ZOOM EST RETENU ──')
    page.evaluate("() => zoomAppliquer(1.5,false)")
    page.wait_for_timeout(500)
    t('le réglage est enregistré',
      abs(float(page.evaluate("() => JSON.parse(lsGet('mn_cfg')).zoom")) - 1.5) < 0.005)
    page.reload()
    page.wait_for_timeout(1800)
    t('il est retrouvé au rechargement',
      abs(page.evaluate("() => ZOOM") - 1.5) < 0.005, page.evaluate("() => ZOOM"))
    page.evaluate("() => zoomAppliquer(1,false)")
    page.wait_for_timeout(400)

    print('\n── 8. LE PAPIER IGNORE LE ZOOM ──')
    page.evaluate("""(m) => {
      ED.innerHTML='<h1>Impression</h1><p>'+m.repeat(90)+'</p>';paginate();
    }""", LONG)
    page.wait_for_timeout(900)
    attendu = page.evaluate("() => pgInfo.pages")
    for z in (0.5, 1, 2):
        page.evaluate("(z) => zoomAppliquer(z,false)", z)
        page.wait_for_timeout(500)
        pdf = os.path.join(tempfile.gettempdir(), 'zoom_%d.pdf' % (z * 100))
        page.evaluate("(w) => { window.__r = preparePrint(w); }", True)
        page.wait_for_timeout(800)
        t('à %d %% : l\'impression se mesure à 100 %%' % (z * 100),
          abs(page.evaluate("() => ZOOM") - 1) < 0.005)
        page.pdf(path=pdf, format='A4', print_background=True,
                 margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
        page.evaluate("() => window.__r()")
        page.wait_for_timeout(600)
        info = subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout
        papier = int(re.search(r'Pages:\s+(\d+)', info).group(1))
        t('à %d %% : le PDF a le bon nombre de pages' % (z * 100), papier == attendu,
          (attendu, papier))
        t('à %d %% : le zoom est rendu après impression' % (z * 100),
          abs(page.evaluate("() => ZOOM") - z) < 0.005, page.evaluate("() => ZOOM"))

    print('\n── 9. LE DOCUMENT RESTE MODIFIABLE EN ZOOM ──')
    page.evaluate("() => zoomAppliquer(1.75,false)")
    page.wait_for_timeout(500)
    page.evaluate("""() => {
      const p=ED.querySelector('p');
      const r=document.createRange();r.setStart(p.firstChild,0);r.collapse(true);
      const s=getSelection();s.removeAllRanges();s.addRange(r);ED.focus();
    }""")
    page.keyboard.type('ZZZ')
    page.wait_for_timeout(600)
    t('la frappe arrive au bon endroit',
      page.evaluate("() => ED.querySelector('p').textContent").startswith('ZZZ'))
    r = page.evaluate(LIGNES)
    t('la mise en page tient après la frappe', r['dehors'] == 0, r)
    page.evaluate("() => zoomAppliquer(1,false)")
    page.wait_for_timeout(400)

    print('\nerreurs de console :', page.errors[:3] or 'aucune')
    t('aucune erreur de console', not page.errors, page.errors[:2])

# ── écran de tablette : tout le ruban doit rester atteignable ──
print('\n── 10. SUR TABLETTE, RIEN NE SE CACHE ──')
with open_app(width=820, height=1100) as page:
    page.wait_for_timeout(1500)
    m = page.evaluate("""() => {
      const rb=document.getElementById('ribbon'),vb=document.getElementById('vbar');
      const ew=document.getElementById('ew');
      const cache=[...document.querySelectorAll('#ribbon .rbb')].filter(b=>{
        const r=b.getBoundingClientRect();
        return r.right>innerWidth+1||r.left<-1;
      }).length;
      return {rubanDefile: rb.scrollWidth>rb.clientWidth+1,
              vbarDefile: vb.scrollWidth>vb.clientWidth+1,
              boutonsHorsEcran: cache,
              pageDefile: ew.scrollWidth>ew.clientWidth+2,
              zoom: Math.round(ZOOM*100),
              boutons: document.querySelectorAll('#ribbon .rbb').length};
    }""")
    print('   ', m)
    t('le ruban ne défile plus horizontalement', not m['rubanDefile'])
    t('la barre de symboles non plus', not m['vbarDefile'])
    t('aucun bouton du ruban hors de l\'écran', m['boutonsHorsEcran'] == 0,
      m['boutonsHorsEcran'])
    t('la feuille tient dans la largeur', not m['pageDefile'])
    t('elle a été ajustée toute seule', m['zoom'] < 100, m['zoom'])
    t('tous les boutons sont là', m['boutons'] >= 20, m['boutons'])
    hb = page.evaluate("""() => {
      const tb=document.getElementById('topbar');
      /* « ↩ Restaurer » n'apparaît qu'après une feuille blanche : un bouton
         volontairement masqué n'est pas un bouton hors écran. */
      const vis=[...document.querySelectorAll('.topbar-right .top-act')]
        .filter(b=>getComputedStyle(b).display!=='none');
      const cache=vis.filter(b=>{
        const r=b.getBoundingClientRect();
        return r.right>innerWidth+1||r.left<-1;
      }).length;
      return {defile: tb.scrollWidth>tb.clientWidth+1, cache: cache,
              total: vis.length};
    }""")
    t('le bandeau du haut ne défile pas non plus', not hb['defile'], hb)
    t('aucun bouton du bandeau hors de l\'écran', hb['cache'] == 0, hb)
    t('aucune erreur de console', not page.errors, page.errors[:2])

print('\n%d PASS / %d FAIL' % (ok, ko))
raise SystemExit(1 if ko else 0)
