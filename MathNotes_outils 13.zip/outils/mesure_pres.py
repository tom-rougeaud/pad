import pathlib
from playwright.sync_api import sync_playwright
CHROME='/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
p=pathlib.Path('/home/claude/presentation.html')
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path=CHROME,args=['--no-sandbox'])
    pg=b.new_page(); pg.goto(p.as_uri()); pg.wait_for_timeout(600)
    pg.emulate_media(media='print'); pg.wait_for_timeout(300)
    print(pg.evaluate("""()=>{
      const mm=96/25.4, A4=297*mm;
      return [...document.querySelectorAll('.page')].map((e,i)=>{
        const h=e.getBoundingClientRect().height;
        return {page:i+1, hauteur:Math.round(h), A4:Math.round(A4),
                deborde:Math.round(h-A4)};
      });
    }"""))
    print(pg.evaluate("""()=>[...document.querySelectorAll('.page')][0]
      .querySelectorAll(':scope > *').length"""), 'blocs page 1')
    print(pg.evaluate("""()=>[...document.querySelectorAll('.page')].map(p=>
      [...p.querySelectorAll(':scope > *')].map(e=>
        (e.className||e.tagName)+' : '+Math.round(e.getBoundingClientRect().height)))"""))
    b.close()
