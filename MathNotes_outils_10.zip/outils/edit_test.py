# -*- coding: utf-8 -*-
"""Reprendre la main : surlignage, blocs, police, casse, tableaux.

On vérifie des garanties visibles : ce qui est surligné à l'écran sort
sur le papier, un bloc venu d'une ressource s'efface et s'espace comme
n'importe quel autre, et une taille de police s'applique partout.
"""
import json
import os
import subprocess
import tempfile
from harness import open_app

ok = ko = 0


def t(nom, cond, detail=''):
    global ok, ko
    if cond:
        ok += 1
        print('  PASS  ' + nom)
    else:
        ko += 1
        print('  FAIL  ' + nom + ('   → ' + str(detail) if detail else ''))


RES = json.load(open('/mnt/user-data/outputs/ressource-exemple.mathnotes-ressource.json',
                     encoding='utf-8'))


def jaunes(png):
    from PIL import Image
    im = Image.open(png).convert('RGB')
    return sum(1 for px in im.getdata() if px[0] > 240 and px[1] > 230 and 170 < px[2] < 215)


with open_app() as page:
    page.on('dialog', lambda d: d.accept())

    print('\n── 1. LE SURLIGNEUR AGIT SUR LA SÉLECTION ──')
    page.evaluate("""() => {
      ED.innerHTML='<p id="p">Un texte avec un passage a surligner dedans.</p>';
      const t=document.getElementById('p').firstChild;
      const r=document.createRange();r.setStart(t,22);r.setEnd(t,31);
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();ED.focus();
      toggleHL();
    }""")
    page.wait_for_timeout(500)
    t('un seul clic sur 🖍 surligne',
      page.evaluate("() => ED.querySelectorAll('mark.hl').length") == 1)
    t('le mode marqueur ne s\'est pas armé', page.evaluate("() => hlMode") is False)
    t('le texte surligné est le bon',
      page.evaluate("() => ED.querySelector('mark').textContent") == 'ge a surl')
    t('aucun span de fond ne subsiste',
      page.evaluate("() => ED.querySelectorAll('span[style*=background]').length") == 0)
    t('la couleur est prête pour le papier',
      page.evaluate("() => getComputedStyle(ED.querySelector('mark')).printColorAdjust") == 'exact')
    page.evaluate("""() => {
      const m=ED.querySelector('mark');
      const r=document.createRange();r.selectNodeContents(m);
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();ED.focus();
      pickHL('transparent');
    }""")
    page.wait_for_timeout(400)
    t('on retire le surlignage aussi facilement',
      page.evaluate("() => ED.querySelectorAll('mark').length") == 0)
    t('le texte est resté entier',
      'passage a surligner' in page.evaluate("() => ED.textContent"))

    print('\n── 2. SANS SÉLECTION, LE MARQUEUR S\'ARME ──')
    page.evaluate("() => { getSelection().removeAllRanges(); SR=null; toggleHL(); }")
    page.wait_for_timeout(300)
    t('le marqueur s\'arme', page.evaluate("() => hlMode") is True)
    page.evaluate("() => toggleHL()")
    page.wait_for_timeout(200)
    t('et se désarme au clic suivant', page.evaluate("() => hlMode") is False)

    print('\n── 3. LE SURLIGNAGE SORT SUR LE PAPIER ──')
    page.evaluate("""() => {
      ED.innerHTML='<p id="p">Un texte avec un passage a surligner dedans.</p>';
      const t=document.getElementById('p').firstChild;
      const r=document.createRange();r.setStart(t,22);r.setEnd(t,31);
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();ED.focus();
      pickHL('#FFF3C4');paginate();
    }""")
    page.wait_for_timeout(600)
    for fonds in (False, True):
        pdf = os.path.join(tempfile.gettempdir(), 'e_hl%d.pdf' % fonds)
        page.evaluate("(w) => { window.__r = preparePrint(w); }", True)
        page.wait_for_timeout(500)
        page.pdf(path=pdf, format='A4', print_background=fonds,
                 margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
        page.evaluate("() => window.__r()")
        page.wait_for_timeout(400)
        subprocess.run(['pdftoppm', '-png', '-r', '100', '-f', '1', '-l', '1', pdf,
                        '/tmp/claude-0/e_hl%d' % fonds], check=True)
        nb = jaunes('/tmp/claude-0/e_hl%d-1.png' % fonds)
        t('fonds %s : le surlignage est sur le PDF' % ('cochés' if fonds else 'décochés'),
          nb > 300, nb)
    t('le surlignage part dans la page web',
      'mark' in page.evaluate("() => cleanHTML({export:true})"))
    t('son style aussi', 'mark' in page.evaluate("() => buildExportCSS()"))

    print('\n── 4. UNE RESSOURCE GÉNÉRÉE RESTE ENTIÈREMENT ÉDITABLE ──')
    page.evaluate("(m) => { ED.innerHTML=''; ED.appendChild(mnrCompile(m,{}));"
                  " reattach(); paginate(); }", RES)
    page.wait_for_timeout(1400)
    pages0 = page.evaluate("() => pgInfo.pages")
    t('aucun bloc n\'en touche un autre',
      page.evaluate("""() => {
        const l=[...ED.children].filter(e=>!e.classList.contains('pg-auto'));
        let k=0;for(let i=0;i+1<l.length;i++)if(blocFige(l[i])&&blocFige(l[i+1]))k++;return k;
      }""") == 0)
    t('la respiration ne coûte aucune hauteur',
      page.evaluate("""() => [...ED.querySelectorAll('p.mn-resp')]
        .every(p=>p.getBoundingClientRect().height===0)"""))
    t('le document garde sa pagination', pages0 >= 10, pages0)
    t('elle n\'entre pas dans la sauvegarde',
      'mn-resp' not in page.evaluate("() => cleanHTML()"))
    t('ni dans la page web', 'mn-resp' not in page.evaluate("() => cleanHTML({export:true})"))

    n0 = page.evaluate("() => ED.querySelectorAll('.exo-block').length")
    page.evaluate("() => { blocMontrer(ED.querySelector('.exo-block')); blocSupprimer(); }")
    page.wait_for_timeout(600)
    t('un exercice généré se supprime',
      page.evaluate("() => ED.querySelectorAll('.exo-block').length") == n0 - 1)
    page.evaluate("() => { blocMontrer(ED.querySelector('.exo-block')); blocLigne(-1); }")
    page.wait_for_timeout(500)
    t('une ligne s\'insère avant un bloc',
      page.evaluate("""() => {
        const p=ED.querySelector('.exo-block').previousElementSibling;
        return !!p && p.tagName==='P' && !p.classList.contains('mn-resp');
      }"""))
    page.evaluate("() => { blocMontrer(ED.querySelector('.qcm-block')); blocLigne(1); }")
    page.wait_for_timeout(500)
    t('et après un bloc',
      page.evaluate("""() => {
        const p=ED.querySelector('.qcm-block').nextElementSibling;
        return !!p && p.tagName==='P' && !p.classList.contains('mn-resp');
      }"""))
    nd = page.evaluate("() => ED.querySelectorAll('.callout').length")
    page.evaluate("() => { blocMontrer(ED.querySelector('.callout')); blocDupliquer(); }")
    page.wait_for_timeout(700)
    t('un encadré se duplique',
      page.evaluate("() => ED.querySelectorAll('.callout').length") == nd + 1)
    page.evaluate("() => doUndo()")
    page.wait_for_timeout(600)
    t('et l\'annulation revient en arrière',
      page.evaluate("() => ED.querySelectorAll('.callout').length") == nd,
      page.evaluate("() => ED.querySelectorAll('.callout').length"))

    print('\n── 5. DÉPLACER ET REDIMENSIONNER UN BLOC ──')
    page.evaluate("""() => {
      ED.innerHTML='<p>Avant.</p>';
      ED.appendChild(mnrBloc({b:'definition',t:'Un encadré.'}));
      ED.appendChild(mnrBloc({b:'texte',t:'Entre les deux.'}));
      ED.appendChild(mnrBloc({b:'exemple',lignes:['Une zone verte.']}));
      reattach();paginate();
    }""")
    page.wait_for_timeout(700)
    av = page.evaluate("() => [...ED.children].filter(e=>!e.classList.contains('pg-auto'))"
                       ".map(e=>e.className||e.tagName).join('|')")
    page.evaluate("""() => {
      /* on rejoue ce que fait le dépôt : le bloc change de voisin */
      const z=ED.querySelector('.czone'), d=ED.querySelector('.callout');
      pushHistNow(); ED.insertBefore(z,d); reattach(); pushHist();
    }""")
    page.wait_for_timeout(600)
    ap = page.evaluate("() => [...ED.children].filter(e=>!e.classList.contains('pg-auto'))"
                       ".map(e=>e.className||e.tagName).join('|')")
    t('un bloc change de place', av != ap, (av, ap))
    t('la respiration suit le déplacement',
      page.evaluate("""() => {
        const l=[...ED.children].filter(e=>!e.classList.contains('pg-auto'));
        let k=0;for(let i=0;i+1<l.length;i++)if(blocFige(l[i])&&blocFige(l[i+1]))k++;return k;
      }""") == 0)
    page.evaluate("""() => {
      const d=ED.querySelector('.callout');
      blocMontrer(d);
      const g=document.querySelector('.bloc-gl-w');
      g.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:500,clientY:300}));
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:300,clientY:300}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
    }""")
    page.wait_for_timeout(600)
    t('la largeur d\'un bloc se réduit',
      page.evaluate("() => parseFloat(ED.querySelector('.callout').style.width)") > 0,
      page.evaluate("() => ED.querySelector('.callout').style.width"))
    page.evaluate("""() => {
      const d=ED.querySelector('.callout');
      blocMontrer(d);
      const g=document.querySelector('.bloc-gl-h');
      g.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:400,clientY:300}));
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:400,clientY:420}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
    }""")
    page.wait_for_timeout(600)
    t('la hauteur d\'un bloc s\'augmente',
      page.evaluate("() => parseFloat(ED.querySelector('.callout').style.minHeight)") > 24,
      page.evaluate("() => ED.querySelector('.callout').style.minHeight"))
    t('la taille choisie suit dans la sauvegarde',
      'width' in page.evaluate("() => cleanHTML()"))

    print('\n── 6. LA TAILLE DE POLICE EST LIBRE ──')
    page.evaluate("""() => {
      ED.innerHTML='<p id="p">Un texte ordinaire à redimensionner.</p>';
      const t=document.getElementById('p').firstChild;
      const r=document.createRange();r.setStart(t,3);r.setEnd(t,15);
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();ED.focus();
      applySize('13,2');
    }""")
    page.wait_for_timeout(500)
    t('13,2 est accepté',
      '13.2px' in page.evaluate("() => ED.querySelector('p').innerHTML"))
    t('le champ affiche la virgule française',
      page.evaluate("() => document.getElementById('rb-size').value") == '13,2')
    t('une valeur absurde est ramenée dans les clous',
      page.evaluate("() => tailleValide('900')") == 300
      and page.evaluate("() => tailleValide('0')") == 4
      and page.evaluate("() => tailleValide('abc')") is None)
    page.evaluate("() => { document.getElementById('rb-size').value='13,2'; pasSize(1); }")
    page.wait_for_timeout(300)
    t('A+ augmente d\'un point',
      page.evaluate("() => document.getElementById('rb-size').value") == '14,2',
      page.evaluate("() => document.getElementById('rb-size').value"))

    page.evaluate("(m) => { ED.innerHTML=''; ED.appendChild(mnrCompile(m,{}));"
                  " reattach(); paginate(); }", RES)
    page.wait_for_timeout(1300)
    t('la taille s\'applique dans un exercice généré',
      page.evaluate("""() => {
        const b=ED.querySelector('.exo-body');
        const r=document.createRange();r.selectNodeContents(b);
        const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();b.focus();
        wrapStyle({fontSize:'22px'});
        return b.querySelectorAll('span[style*="22px"]').length>0;
      }"""))
    t('et dans une question de QCM',
      page.evaluate("""() => {
        const b=ED.querySelector('.qcm-q-text');
        const r=document.createRange();r.selectNodeContents(b);
        const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();b.focus();
        wrapStyle({fontSize:'9px'});
        return b.querySelectorAll('span[style*="9px"]').length>0;
      }"""))

    print('\n── 7. MAJUSCULES ET MINUSCULES ──')
    page.evaluate("""() => {
      ED.innerHTML='<p id="q">le taux de marge se calcule ainsi</p>';
      const r=document.createRange();r.selectNodeContents(document.getElementById('q'));
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();ED.focus();
    }""")
    suite = []
    for _ in range(3):
        page.evaluate("() => changerCasse()")
        page.wait_for_timeout(250)
        suite.append(page.evaluate("() => ED.querySelector('#q').textContent"))
    t('minuscules → Première Lettre', suite[0] == 'Le Taux De Marge Se Calcule Ainsi', suite[0])
    t('puis MAJUSCULES', suite[1] == 'LE TAUX DE MARGE SE CALCULE AINSI', suite[1])
    t('puis minuscules', suite[2] == 'le taux de marge se calcule ainsi', suite[2])
    page.evaluate("""() => {
      ED.innerHTML='<p id="q">élève à côté, ça pèse</p>';
      const r=document.createRange();r.selectNodeContents(document.getElementById('q'));
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();ED.focus();
      changerCasse();changerCasse();
    }""")
    page.wait_for_timeout(400)
    t('les accents passent en majuscules',
      page.evaluate("() => ED.querySelector('#q').textContent") == 'ÉLÈVE À CÔTÉ, ÇA PÈSE',
      page.evaluate("() => ED.querySelector('#q').textContent"))

    print('\n── 8. LES TABLEAUX ──')
    page.evaluate("""() => {
      ED.innerHTML='';
      ED.appendChild(mnrBloc({b:'tableau',entete:['Évolution','CM'],
        lignes:[['+ 20 %','1,20'],['− 30 %','0,70']]}));
      reattach();paginate();
      curTable=ED.querySelector('table');
    }""")
    page.wait_for_timeout(600)
    pleine = page.evaluate("() => Math.round(ED.querySelector('table').getBoundingClientRect().width)")
    page.evaluate("() => tblLargeur('50')")
    page.wait_for_timeout(400)
    demi = page.evaluate("() => Math.round(ED.querySelector('table').getBoundingClientRect().width)")
    t('un tableau peut ne pas prendre toute la largeur', demi < pleine * 0.6, (pleine, demi))
    page.evaluate("() => tblLargeur('auto')")
    page.wait_for_timeout(400)
    t('il peut s\'ajuster à son contenu',
      page.evaluate("() => Math.round(ED.querySelector('table').getBoundingClientRect().width)")
      < pleine, (pleine, page.evaluate("() => Math.round(ED.querySelector('table').getBoundingClientRect().width)")))
    page.evaluate("() => tblLargeur('100')")
    page.wait_for_timeout(400)
    t('et revenir à toute la largeur',
      abs(page.evaluate("() => Math.round(ED.querySelector('table').getBoundingClientRect().width)")
          - pleine) <= 2)
    t('le retour à la ligne dans les cellules est conservé',
      page.evaluate("() => getComputedStyle(ED.querySelector('td')).overflowWrap")
      in ('anywhere', 'break-word'))
    page.evaluate("() => { tblToutSelectionner(); wrapStyle({fontSize:'11px'}); }")
    page.wait_for_timeout(500)
    t('tout le tableau se met en forme d\'un coup',
      page.evaluate("() => ED.querySelectorAll('table span[style*=\"11px\"]').length") >= 6,
      page.evaluate("() => ED.querySelectorAll('table span[style*=\"11px\"]').length"))
    page.evaluate("() => tblPlace('c')")
    page.wait_for_timeout(300)
    t('le tableau se place dans la page',
      page.evaluate("() => ED.querySelector('table').classList.contains('tbl-c')"))

    print('\n── 9. LES NOUVELLES ICÔNES ──')
    ic = page.evaluate("() => ({familles: ICON_SETS.map(s=>s.cat),"
                       " total: ICON_SETS.reduce((n,s)=>n+s.items.length,0)})")
    t('une famille IA existe', 'IA' in ic['familles'], ic['familles'])
    t('elle contient un robot',
      page.evaluate("() => ICON_SETS.find(s=>s.cat==='IA').items.some(i=>i.c==='🤖')"))
    t('les maths se sont étoffées', ic['total'] >= 185, ic['total'])
    for mot in ('pythagore', 'fraction', 'suite', 'proportionnalité', 'écart type'):
        t('on trouve « %s »' % mot,
          page.evaluate("(m) => ICON_SETS.some(s=>s.items.some(i=>"
                        "(i.n+' '+i.k).toLowerCase().includes(m)))", mot))

    print('\nerreurs de console :', page.errors[:3] or 'aucune')
    t('aucune erreur de console', not page.errors, page.errors[:2])

print('\n%d PASS / %d FAIL' % (ok, ko))
raise SystemExit(1 if ko else 0)
