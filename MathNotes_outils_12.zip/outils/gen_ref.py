# -*- coding: utf-8 -*-
"""Transforme le fichier de progression de l'auteur en référentiel embarqué.

On ne garde que ce dont l'application se sert : les compteurs se
recalculent, les identifiants de chapitre servent de racine aux codes
d'item (chapitre « pm0m1 » → items « pm0m1-1 », « pm0m1-2 »…).
"""
import json

SRC = ("/root/.claude/uploads/fb0e2b8b-6d93-57a9-b1b2-da755eb04303/"
       "99adbb58-programme_maths_accordeon.json")
d = json.load(open(SRC, encoding='utf-8'))

ref = {
    'format': 'mathnotes-programme', 'version': 2,
    'matiere': d.get('matiere', 'Mathématiques'),
    'licence': d.get('licence', ''),
    'source': d.get('source', ''),
    'niveaux': [],
}
n_items = n_chap = 0
codes = set()
for cle, niv in d['niveaux'].items():
    N = {'cle': cle, 'label': niv['label'], 'bo': niv.get('bo', ''), 'themes': []}
    for th in niv['themes']:
        T = {'id': th['id'], 'label': th['label'], 'icone': th.get('icone', ''),
             'couleur': th.get('couleur', ''), 'chapitres': []}
        for ch in th['chapitres']:
            C = {'id': ch['id'], 'nom': ch['nom'], 'icone': ch.get('icone', ''),
                 'note': ch.get('note', ''), 'sections': []}
            k = 0
            for s in ch['sections']:
                S = {'titre': s.get('titre_section', ''), 'items': []}
                for it in s['items']:
                    k += 1
                    code = '%s-%d' % (ch['id'], k)
                    assert code not in codes, code
                    codes.add(code)
                    S['items'].append(it)
                C['sections'].append(S)
            n_items += k
            n_chap += 1
            T['chapitres'].append(C)
        N['themes'].append(T)
    ref['niveaux'].append(N)

compact = json.dumps(ref, ensure_ascii=False, separators=(',', ':'))
open('_ref.json', 'w', encoding='utf-8').write(compact)
print('%d niveaux · %d chapitres · %d items' % (len(ref['niveaux']), n_chap, n_items))
print('compact : %.1f Ko' % (len(compact.encode()) / 1024))
