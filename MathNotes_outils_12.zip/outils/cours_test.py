# -*- coding: utf-8 -*-
"""Le fichier de démonstration doit s'importer et tout doit fonctionner."""
import json
import os
import re
import subprocess
import tempfile
from harness import open_app

FICHIER = '/mnt/user-data/outputs/Cours_Pourcentages_Bac_Pro.mathnotes.json'
bundle = json.load(open(FICHIER, encoding='utf-8'))
ok = ko = 0


def t(nom, cond, detail=''):
    global ok, ko
    if cond:
        ok += 1
        print('  PASS  ' + nom)
    else:
        ko += 1
        print('  FAIL  ' + nom + ('   → ' + str(detail) if detail else ''))


LIGNES = """() => {
  const MM=96/25.4,PAGE_H=297*MM,PAD=22*MM,PITCH=PAGE_H+28,CH=PAGE_H-2*PAD-8;
  const base=ED.getBoundingClientRect().top+PAD;
  const dehors=[];
  const w=document.createTreeWalker(ED,NodeFilter.SHOW_TEXT,null);let t;
  while((t=w.nextNode())){
    if(!t.nodeValue.trim())continue;
    if(t.parentNode.closest('#pg-overlay,.pg-tools,.zone-hint,.czone-bar,.exo-btn,.qcm-btn,.qcm-mini'))continue;
    const rg=document.createRange();rg.selectNodeContents(t);
    for(const r of rg.getClientRects()){
      if(!r.height)continue;
      const top=r.top-base,bot=r.bottom-base;
      const p=Math.floor((top+3)/PITCH);
      if(bot>p*PITCH+CH+2)dehors.push({page:p+1,texte:t.nodeValue.slice(0,34)});
    }
  }
  return dehors.slice(0,4);
}"""

print('\n── 1. LE FICHIER EST BIEN UN PROJET MATHNOTES ──')
t('format reconnu', bundle.get('format') == 'mathnotes-project', bundle.get('format'))
t('version 3', bundle.get('version') == 3)
t('titre présent', bool(bundle.get('title')), bundle.get('title'))
t('le corps est du texte', isinstance(bundle.get('html'), str))
t('aucun espaceur de mise en page', 'pg-auto' not in bundle['html'])
t('aucun marqueur interne', 'data-bound' not in bundle['html'])

with open_app() as page:
    page.on('dialog', lambda d: d.accept())
    print('\n── 2. L\'IMPORT SE PASSE BIEN ──')
    page.evaluate("(b) => applyProject(b)", bundle)
    page.wait_for_timeout(1500)
    t('aucune erreur à l\'ouverture', not page.errors, page.errors[:2])
    t('le titre est repris',
      page.evaluate("() => document.getElementById('doc-title').textContent") == bundle['title'])
    t('la vue éditeur est affichée',
      page.evaluate("() => !!document.querySelector('#editor').offsetParent"))

    print('\n── 3. LE COURS EST COMPLET ──')
    c = page.evaluate("""() => ({
      h1: ED.querySelectorAll('h1').length,
      h2: ED.querySelectorAll('h2').length,
      callouts: ED.querySelectorAll('.callout').length,
      zones: ED.querySelectorAll('.czone').length,
      formules: ED.querySelectorAll('.md').length,
      inline: ED.querySelectorAll('.mx').length,
      tables: ED.querySelectorAll('table.mn-table').length,
      exos: ED.querySelectorAll('.exo-block').length,
      qcm: ED.querySelectorAll('.qcm-block').length,
      questions: ED.querySelectorAll('.qcm-q').length,
      comps: ED.querySelectorAll('.comp').length,
      sauts: ED.querySelectorAll('.pg-manual').length
    })""")
    print('   ', c)
    t('quatre parties (quatre titres de niveau 1)', c['h1'] == 4, c['h1'])
    t('trois sauts de page voulus', c['sauts'] == 3, c['sauts'])
    t('les encadrés sont là', c['callouts'] >= 8, c['callouts'])
    t('les zones colorées sont là', c['zones'] >= 5, c['zones'])
    t('les formules en bloc sont là', c['formules'] == 6, c['formules'])
    t('les formules en ligne sont là', c['inline'] >= 30, c['inline'])
    t('les tableaux sont là', c['tables'] == 3, c['tables'])
    t('quatre exercices', c['exos'] == 4, c['exos'])
    t('un QCM de six questions', c['qcm'] == 1 and c['questions'] == 6,
      (c['qcm'], c['questions']))
    t('les pastilles de compétences sont là', c['comps'] >= 17, c['comps'])

    print('\n── 4. LES MATHÉMATIQUES SONT RENDUES ──')
    m = page.evaluate("""() => {
      const els=[...ED.querySelectorAll('.md,.mx')];
      const vides=els.filter(e=>!e.querySelector('.katex'));
      const err=[...ED.querySelectorAll('.katex-error')];
      return {total:els.length,vides:vides.length,
              exVide:vides.slice(0,3).map(e=>e.getAttribute('data-latex')),
              err:err.length,exErr:err.slice(0,3).map(e=>e.textContent.slice(0,40))};
    }""")
    t('toutes les formules sont rendues par KaTeX', m['vides'] == 0, m['exVide'])
    t('aucune formule en erreur', m['err'] == 0, m['exErr'])
    pct = page.evaluate(
        "() => { const e=[...ED.querySelectorAll('.md')]"
        ".find(x=>x.getAttribute('data-latex').indexOf('de } N')>=0);"
        " return e ? e.textContent : 'introuvable'; }")
    t('le signe pourcent est bien affiché dans les formules', '%' in pct, pct)

    print('\n── 5. LE QCM EST VIVANT ──')
    t('les bonnes réponses sont enregistrées',
      page.evaluate("() => ED.querySelectorAll('.qcm-a[data-ok=\"1\"]').length") == 7,
      page.evaluate("() => ED.querySelectorAll('.qcm-a[data-ok=\"1\"]').length"))
    t('une question à réponses multiples',
      page.evaluate("() => ED.querySelectorAll('.qcm-q[data-multi=\"1\"]').length") == 1)
    t('chaque question a sa correction',
      page.evaluate("() => [...ED.querySelectorAll('.qcm-q-corr')].filter(c=>c.textContent.trim()).length") == 6)
    t('les questions sont numérotées',
      page.evaluate("() => [...ED.querySelectorAll('.qcm-num')].map(n=>n.textContent).join('')") == '1.2.3.4.5.6.')
    avant = page.evaluate("() => ED.querySelectorAll('.qcm-a[data-ok=\"1\"]').length")
    page.evaluate("""() => {
      const a=ED.querySelectorAll('.qcm-q')[0].querySelectorAll('.qcm-a')[3];
      a.querySelector('.qcm-box').click();
    }""")
    page.wait_for_timeout(300)
    t('cocher une autre réponse décoche la précédente (réponse unique)',
      page.evaluate("() => ED.querySelectorAll('.qcm-a[data-ok=\"1\"]').length") == avant,
      page.evaluate("() => ED.querySelectorAll('.qcm-a[data-ok=\"1\"]').length"))
    page.evaluate("""() => {
      const a=ED.querySelectorAll('.qcm-q')[0].querySelectorAll('.qcm-a')[3];
      a.querySelector('.qcm-box').click();
      const b=ED.querySelectorAll('.qcm-q')[0].querySelectorAll('.qcm-a')[1];
      if(b.dataset.ok!=='1')b.querySelector('.qcm-box').click();
    }""")
    page.wait_for_timeout(300)

    print('\n── 6. LES EXERCICES SE DÉPLIENT ──')
    t('les quatre corrections sont remplies',
      page.evaluate("() => [...ED.querySelectorAll('.exo-corr-body')].filter(c=>c.textContent.trim().length>60).length") == 4)
    t('les corrections sont repliées au départ',
      page.evaluate("() => [...ED.querySelectorAll('.exo-corr-body')].every(c=>c.style.display==='none')"))
    page.evaluate("() => ED.querySelector('.exo-corr-toggle').click()")
    page.wait_for_timeout(300)
    t('le bouton déplie bien la correction',
      page.evaluate("() => ED.querySelector('.exo-corr-body').style.display") != 'none')
    t('le titre de l\'exercice est modifiable',
      page.evaluate("() => ED.querySelector('.exo-label').getAttribute('contenteditable')") == 'true')
    page.evaluate("() => ED.querySelector('.exo-corr-toggle').click()")
    page.wait_for_timeout(300)

    print('\n── 7. LES PASTILLES DE COMPÉTENCES ──')
    comp = page.evaluate("""() => {
      const els=[...ED.querySelectorAll('.comp')];
      const couleurs=new Set(els.map(e=>getComputedStyle(e).backgroundColor));
      const svg=els.filter(e=>e.querySelector('svg')).length;
      const ref=ED.querySelector('p');
      return {n:els.length,couleurs:couleurs.size,svg:svg,
              nommees:els.filter(e=>e.dataset.v==='n').length,
              seules:els.filter(e=>e.dataset.v==='i').length,
              hauteur:Math.round(els[0].getBoundingClientRect().height),
              police:getComputedStyle(els[0]).fontSize,
              policeTexte:getComputedStyle(ref).fontSize};
    }""")
    print('   ', comp)
    t('les cinq couleurs sont distinctes', comp['couleurs'] == 5, comp['couleurs'])
    t('chaque pastille a son pictogramme', comp['svg'] == comp['n'])
    t('les deux formes sont présentes', comp['nommees'] > 0 and comp['seules'] > 0,
      (comp['nommees'], comp['seules']))
    t('la pastille reste plus petite que le texte',
      float(comp['police'][:-2]) < float(comp['policeTexte'][:-2]),
      (comp['police'], comp['policeTexte']))
    # elle s'efface comme un caractère
    n0 = page.evaluate("() => ED.querySelectorAll('.comp').length")
    page.evaluate("""() => {
      const c=ED.querySelector('.comp');
      const r=document.createRange();r.setStartAfter(c);r.collapse(true);
      const s=getSelection();s.removeAllRanges();s.addRange(r);
      editHost(c.parentNode).focus();
    }""")
    page.keyboard.press('Backspace')
    page.wait_for_timeout(400)
    t('une pastille s\'efface d\'un retour arrière',
      page.evaluate("() => ED.querySelectorAll('.comp').length") == n0 - 1,
      page.evaluate("() => ED.querySelectorAll('.comp').length"))
    page.evaluate("() => doUndo()")
    page.wait_for_timeout(500)
    t('l\'annulation la remet',
      page.evaluate("() => ED.querySelectorAll('.comp').length") == n0,
      page.evaluate("() => ED.querySelectorAll('.comp').length"))

    print('\n── 8. LA MISE EN PAGE TIENT ──')
    page.evaluate("() => paginate()")
    page.wait_for_timeout(800)
    pages = page.evaluate("() => pgInfo.pages")
    dehors = page.evaluate(LIGNES)
    t('aucune ligne dans le blanc entre deux pages', not dehors, dehors)
    t('document de plusieurs pages', pages >= 8, pages)
    t('aucune page vide au milieu',
      page.evaluate("""() => {
        const MM=96/25.4,PITCH=297*MM+28,base=ED.getBoundingClientRect().top+22*MM;
        const occ=new Set();
        [...ED.querySelectorAll('h1,h2,p,div,table,li')].forEach(e=>{
          if(e.closest('.pg-tools'))return;
          if(!e.textContent.trim())return;
          const r=e.getBoundingClientRect();
          occ.add(Math.floor((r.top-base+3)/PITCH));
        });
        let vides=0;for(let i=0;i<pgInfo.pages;i++)if(!occ.has(i))vides++;
        return vides;
      }""") == 0)

    print('\n── 9. LE PAPIER CORRESPOND À L\'ÉCRAN ──')
    # on emprunte le chemin de l'application : elle déplie les corrections
    # PUIS remet en page, pour que le papier suive l'écran.
    for version, corr in (('professeur', True), ('élève', False)):
        pdf = os.path.join(tempfile.gettempdir(), 'cours_demo_%s.pdf' % corr)
        page.evaluate("(w) => { window.__r = preparePrint(w); }", corr)
        page.wait_for_timeout(900)
        attendu = page.evaluate("() => pgInfo.pages")
        page.pdf(path=pdf, format='A4', print_background=True,
                 margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
        page.evaluate("() => window.__r()")
        page.wait_for_timeout(700)
        info = subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout
        papier = int(re.search(r'Pages:\s+(\d+)', info).group(1))
        t('version %s : même nombre de pages à l\'écran et sur le papier' % version,
          papier == attendu, (attendu, papier))
        if corr:
            pdf_prof = pdf
        else:
            corrige_absent = 'Première méthode' not in re.sub(
                r'\s+', ' ', subprocess.run(['pdftotext', pdf, '-'],
                                            capture_output=True, text=True).stdout)
    t('la version élève ne montre pas les corrections', corrige_absent)
    pdf = pdf_prof
    txt = re.sub(r'\s+', ' ', subprocess.run(['pdftotext', pdf, '-'],
                                             capture_output=True, text=True).stdout)
    for mot in ['coefficient multiplicateur', 'Méca-Pro', 'plaquettes de frein',
                'Feuille d’exercices corrigés', '1 840 kWh', '504']:
        t('« %s » est bien imprimé' % mot, mot in txt)

    print('\n── 10. LA PAGE WEB EXPORTÉE ──')
    exp = page.evaluate("() => cleanHTML({export:true})")
    css = page.evaluate("() => buildExportCSS()")
    t('les pastilles partent à l\'export', 'class="comp"' in exp)
    t('les corrections de QCM partent à l\'export', 'qcm-q-corr' in exp)
    t('aucun espaceur de mise en page à l\'export', 'pg-auto' not in exp)
    t('le style des pastilles est repris à l\'export', '.comp' in css)
    t('le style des encadrés est repris à l\'export', '.callout' in css)

    print('\nerreurs de console :', page.errors[:3] or 'aucune')
    t('aucune erreur de console', not page.errors, page.errors[:2])

print('\n%d PASS / %d FAIL' % (ok, ko))
raise SystemExit(1 if ko else 0)
