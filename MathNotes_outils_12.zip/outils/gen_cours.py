# -*- coding: utf-8 -*-
"""Fabrique le fichier de démonstration à importer dans MathNotes.

Le document est construit *dans l'application*, avec ses propres fabriques,
puis exporté par le même chemin que le bouton « Enregistrer ». Le fichier
obtenu est donc, à l'octet près, ce qu'aurait produit l'application.
"""
import json
import pathlib
from harness import open_app

SRC = pathlib.Path('cours_pourcentages.js').read_text(encoding='utf-8')
OUT = pathlib.Path('/mnt/user-data/outputs/Cours_Pourcentages_Bac_Pro.mathnotes.json')
TITRE = 'Pourcentages et coefficients multiplicateurs — Bac Pro'

with open_app() as page:
    n = page.evaluate(SRC)
    page.wait_for_timeout(1200)
    bundle = page.evaluate("""(titre) => {
      const sheets={};
      Object.keys(SHEETS).forEach(id=>{
        const g=SHEETS[id];
        sheets[id]={data:g.data,fmt:g.fmt,widths:g.widths,rows:g.rows,cols:g.cols};
      });
      document.getElementById('doc-title').textContent=titre;
      return {format:'mathnotes-project',version:3,
              savedAt:new Date().toISOString(),
              title:titre,config:loadCfg(),html:cleanHTML(),sheets:sheets};
    }""", TITRE)
    pages = page.evaluate('() => pgInfo.pages')
    erreurs = page.errors[:3]

bundle['savedAt'] = '2026-09-25T20:00:00.000Z'
bundle['config']['pagenum'] = True
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(bundle, ensure_ascii=False, indent=1), encoding='utf-8')

print('questions de QCM :', n)
print('pages            :', pages)
print('taille du fichier: %.1f Ko' % (OUT.stat().st_size / 1024))
print('erreurs          :', erreurs or 'aucune')
