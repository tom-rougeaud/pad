# -*- coding: utf-8 -*-
"""Atelier de ressources : le compilateur dessine, le contrôle refuse.

On vérifie des garanties : chaque bloc produit l'objet MathNotes attendu,
les trois parcours sortent d'une seule source, et chaque classe de défaut
est bien arrêtée — en particulier un calcul faux.
"""
import json
from harness import open_app

ok = ko = 0


def t(nom, cond, detail=''):
    global ok, ko
    if cond:
        ok += 1
        print('  PASS  ' + nom)
    else:
        ko += 1
        print('  FAIL  ' + nom + ('   → ' + str(detail) if detail else ''))


BASE = {
    "format": "mathnotes-ressource", "version": 1,
    "meta": {"titre": "Coefficient multiplicateur", "niveau": "Niveau d'essai",
             "chapitre": "Chapitre d'essai", "capacites": [], "duree": 55},
    "ressources": [
        {"type": "cours", "titre": "Le coefficient multiplicateur",
         "chapeau": "Chapitre 3.",
         "blocs": [
             {"b": "titre", "n": 2, "t": "1. Définition"},
             {"b": "texte", "t": "Un texte avec du **gras**, de l'*italique* et $x^2$."},
             {"b": "definition", "t": "Une définition."},
             {"b": "propriete", "t": "Une propriété."},
             {"b": "attention", "t": "Une erreur fréquente."},
             {"b": "methode", "titre": "TVA", "t": "Comment on s'y prend."},
             {"b": "formule", "latex": "CM = 1 + \\frac{t}{100}", "titre": "Coefficient"},
             {"b": "exemple", "lignes": ["**Exemple** — Un article à 60 € augmente de 15 %.",
                                         "$CM = 1 + \\frac{15}{100} = 1,15$",
                                         "Nouveau prix : $60 \\times 1,15 = 69$ €."]},
             {"b": "situation", "titre": "Garage",
              "lignes": ["Un devis comprend 340 € HT et 185 € HT.",
                         "Total : $340 + 185 = 525$ €."]},
             {"b": "remarque", "titre": "Contexte", "lignes": ["Une consigne générale."]},
             {"b": "etapes", "items": ["Première étape.", "Deuxième étape."]},
             {"b": "liste", "items": ["Un point.", "Un autre."]},
             {"b": "tableau", "entete": ["Évolution", "CM"],
              "lignes": [["+ 20 %", "1,20"], ["− 30 %", "0,70"]]},
             {"b": "methode", "niv": "-", "titre": "Pas à pas", "t": "On détaille."},
             {"b": "formule", "niv": "+", "latex": "CM_1 \\times CM_2"},
         ]},
        {"type": "evaluation", "titre": "Évaluation",
         "blocs": [
             {"b": "remarque", "lignes": ["Le magasin vend à 48 € HT, 250 en mars."]},
             {"b": "question", "comp": "s'approprier", "t": "Relever le prix.", "bareme": 2},
             {"b": "question", "comp": "raisonner", "t": "Le gérant a-t-il raison ?", "bareme": 4},
             {"b": "question", "comp": "réaliser", "t": "Calculer le prix TTC.", "bareme": 3},
             {"b": "question", "comp": "valider", "t": "Est-ce vraisemblable ?", "bareme": 4},
             {"b": "question", "comp": "communiquer", "t": "Expliquer au client.", "bareme": 3},
             {"b": "grille", "lignes": [
                 {"comp": "réaliser", "attendu": "Mener un calcul", "questions": "3"}]},
         ]},
        {"type": "exercices", "titre": "Exercices corrigés",
         "exercices": [
             {"titre": "Appliquer une remise",
              "enonce": ["Un lot est facturé **148 € HT**, remise de **12 %**.",
                         "**1.** Calculer le montant de la remise."],
              "correction": ["**1.** $\\frac{12}{100} \\times 148 = 17,76$ €.",
                             "Le prix payé est donc de 17,76 € de moins."]},
             {"titre": "Version détaillée", "niv": "-",
              "enonce": ["Un lot est facturé **148 € HT**, remise de **12 %**."],
              "correction": ["$148 \\times 0,12 = 17,76$ €."]},
         ]},
        {"type": "qcm", "titre": "QCM — Coefficients",
         "commentaire": "Un coefficient est toujours positif.",
         "questions": [
             {"comp": "réaliser", "t": "Le prix passe de 60 € à 69 €. Taux ?",
              "multi": False, "reponses": ["+ 9 %", "+ 13 %", "+ 15 %", "+ 90 %"],
              "justes": [2],
              "correction": "$\\frac{69 - 60}{60} \\times 100 = 15$."},
             {"comp": "raisonner", "t": "Lesquels traduisent une hausse ?",
              "multi": True, "reponses": ["1,04", "0,96", "2,5"], "justes": [0, 2],
              "correction": "Un coefficient supérieur à 1 traduit une hausse."},
         ]},
    ]
}


def cl(o):
    return json.loads(json.dumps(o))


with open_app() as page:
    page.on('dialog', lambda d: d.accept())
    # un vrai code d'item, pris dans le programme embarqué
    CODE = page.evaluate("() => { const c=refNiveaux()[0].themes[0].chapitres[0];"
                         " return refItemsChapitre(c)[0].code; }")
    BASE['meta']['capacites'] = [CODE]

    print('\n── 1. CHAQUE BLOC PRODUIT SON OBJET MATHNOTES ──')
    page.evaluate("""(m) => {
      ED.innerHTML='';ED.appendChild(mnrCompile(m,{parcours:'standard'}));
      reattach();tableColumnsAsPercent();paginate();
    }""", BASE)
    page.wait_for_timeout(1200)
    c = page.evaluate("""() => ({
      h1: ED.querySelectorAll('h1').length, h2: ED.querySelectorAll('h2').length,
      def: ED.querySelectorAll('.c-def').length, thm: ED.querySelectorAll('.c-thm').length,
      warn: ED.querySelectorAll('.c-warn').length, meth: ED.querySelectorAll('.c-meth').length,
      md: ED.querySelectorAll('.md').length, mx: ED.querySelectorAll('.mx').length,
      vert: ED.querySelectorAll('.czone[data-cz="green"]').length,
      orange: ED.querySelectorAll('.czone[data-cz="orange"]').length,
      gris: ED.querySelectorAll('.czone[data-cz="grey"]').length,
      ol: ED.querySelectorAll('ol').length, ul: ED.querySelectorAll('ul').length,
      tables: ED.querySelectorAll('table.mn-table').length,
      comps: ED.querySelectorAll('.comp').length,
      exos: ED.querySelectorAll('.exo-block').length,
      qcm: ED.querySelectorAll('.qcm-block').length,
      quest: ED.querySelectorAll('.qcm-q').length,
      justes: ED.querySelectorAll('.qcm-a[data-ok="1"]').length,
      sauts: ED.querySelectorAll('.pg-manual').length,
      strong: ED.querySelectorAll('p strong').length,
      em: ED.querySelectorAll('p em').length
    })""")
    print('   ', c)
    t('les quatre encadrés', c['def'] == 1 and c['thm'] == 1 and c['warn'] == 1 and c['meth'] == 1)
    t('l\'encadré Méthode porte son titre',
      page.evaluate("() => ED.querySelector('.c-meth strong').textContent") == 'TVA')
    t('les trois couleurs de zone', c['vert'] == 1 and c['orange'] == 1 and c['gris'] == 2,
      (c['vert'], c['orange'], c['gris']))
    t('la formule en bloc', c['md'] == 1, c['md'])
    t('les formules au fil du texte', c['mx'] >= 6, c['mx'])
    t('les deux sortes de liste', c['ol'] == 1 and c['ul'] == 1)
    t('les tableaux, grille comprise', c['tables'] == 2, c['tables'])
    t('les pastilles de compétences', c['comps'] >= 8, c['comps'])
    t('un exercice de tronc commun', c['exos'] == 1, c['exos'])
    t('le QCM et ses deux questions', c['qcm'] == 1 and c['quest'] == 2)
    t('les bonnes réponses sont cochées', c['justes'] == 3, c['justes'])
    t('un saut entre chaque ressource', c['sauts'] == 3, c['sauts'])
    t('le gras et l\'italique', c['strong'] >= 1 and c['em'] >= 1)
    t('un titre de niveau 1 par ressource', c['h1'] == 4, c['h1'])
    t('les mathématiques sont rendues',
      page.evaluate("() => [...ED.querySelectorAll('.md,.mx')].every(e=>e.querySelector('.katex'))"))
    t('aucune erreur de rendu', page.evaluate("() => ED.querySelectorAll('.katex-error').length") == 0)
    t('le pied de page cite la référence',
      'Référence' in page.evaluate("() => ED.textContent"))
    t('aucune erreur de console', not page.errors, page.errors[:2])

    print('\n── 2. UNE SOURCE, TROIS SORTIES ──')
    mesures = {}
    for p in ('standard', 'plus', 'pas-a-pas'):
        page.evaluate("""(a) => {
          ED.innerHTML='';ED.appendChild(mnrCompile(a.m,{parcours:a.p}));
          reattach();paginate();
        }""", {"m": BASE, "p": p})
        page.wait_for_timeout(500)
        mesures[p] = page.evaluate("""() => ({
          md: ED.querySelectorAll('.md').length,
          meth: ED.querySelectorAll('.c-meth').length,
          exos: ED.querySelectorAll('.exo-block').length,
          def: ED.querySelector('.c-def').textContent.trim()
        })""")
    print('   ', mesures)
    t('le parcours standard ne prend que le tronc commun',
      mesures['standard']['md'] == 1 and mesures['standard']['meth'] == 1
      and mesures['standard']['exos'] == 1, mesures['standard'])
    t('« plus loin » ajoute son enrichissement',
      mesures['plus']['md'] == 2 and mesures['plus']['meth'] == 1, mesures['plus'])
    t('« pas à pas » ajoute son étayage',
      mesures['pas-a-pas']['meth'] == 2 and mesures['pas-a-pas']['exos'] == 2,
      mesures['pas-a-pas'])
    t('les trois versions partagent la même définition',
      mesures['standard']['def'] == mesures['plus']['def'] == mesures['pas-a-pas']['def'])
    t('« plus loin » n\'emporte pas l\'étayage', mesures['plus']['meth'] == 1)
    t('« pas à pas » n\'emporte pas l\'enrichissement', mesures['pas-a-pas']['md'] == 1)

    print('\n── 3. ON PEUT NE DEMANDER QU\'UNE PARTIE ──')
    page.evaluate("""(m) => {
      ED.innerHTML='';ED.appendChild(mnrCompile(m,{ressources:['qcm']}));reattach();paginate();
    }""", BASE)
    page.wait_for_timeout(500)
    t('seul le QCM est produit',
      page.evaluate("() => ED.querySelectorAll('.qcm-block').length") == 1
      and page.evaluate("() => ED.querySelectorAll('.exo-block').length") == 0)
    t('aucun saut de page inutile',
      page.evaluate("() => ED.querySelectorAll('.pg-manual').length") == 0)

    print('\n── 4. LE CONTRÔLE ACCEPTE CE QUI EST BON ──')
    r = page.evaluate("(m) => mnrAudit(m)", BASE)
    durs = [x for x in r if x['n'] == 'err']
    print('   ', [x['msg'][:64] for x in r if x['n'] != 'ok'][:4])
    t('aucune erreur bloquante sur une ressource saine', not durs, durs[:2])
    msgs = ' '.join(x['msg'] for x in r)
    t('les calculs ont été refaits', 'calculs des corrections' in msgs, msgs[:90])
    t('les cinq compétences sont signalées', 'cinq compétences' in msgs)
    t('la différenciation est comptée', 'Pour aller plus loin' in msgs and 'pas à pas' in msgs)

    print('\n── 5. LE CONTRÔLE REFAIT LES CALCULS ──')
    for expr, attendu in [("$\\frac{12}{100} \\times 148 = 17,76$", True),
                          ("$\\frac{12}{100} \\times 148 = 17,80$", False),
                          ("$62 \\times 1,134 = 70,31$", True),
                          ("$62 \\times 1,134 = 70,41$", False),
                          ("$1,25 \\times 0,75 = 0,9375$", True),
                          ("$1 + \\frac{20}{100} = 1,20$", True),
                          ("$1 + \\frac{20}{100} = 1,02$", False),
                          ("$\\frac{1564 - 1840}{1840} \\times 100 = -15$", True),
                          ("Total : $340 + 185 = 525$ €", True),
                          ("Total : $340 + 185 = 520$ €", False),
                          ("$1 250 \\times 0,88 = 1 100$", True),
                          ("$t = \\frac{V_f - V_i}{V_i} \\times 100$", True),
                          ("$P_{TTC} = P_{HT} \\times 1,20$", True),
                          ("La remise vaut 17,76 € puis 3 = 3.", True)]:
        faux = page.evaluate("(s) => mnrEgalitesFausses(s)", expr)
        bon = not faux
        t(('accepté' if attendu else 'refusé') + ' : ' + expr[:46], bon == attendu, faux[:1])

    print('\n── 6. CHAQUE CLASSE DE DÉFAUT EST ARRÊTÉE ──')

    def audit(mut):
        m = cl(BASE)
        mut(m)
        return page.evaluate("(m) => mnrAudit(m)", m)

    def a_erreur(r, motif):
        return any(x['n'] == 'err' and motif in x['msg'] for x in r)

    def a_avert(r, motif):
        return any(x['n'] == 'warn' and motif in x['msg'] for x in r)

    r = audit(lambda m: m['ressources'][3]['questions'][0].update({'justes': []}))
    t('un QCM sans bonne réponse est refusé', a_erreur(r, 'aucune bonne réponse'))

    r = audit(lambda m: m['ressources'][2]['exercices'][0].update({'correction': []}))
    t('un exercice sans correction est refusé', a_erreur(r, 'pas de correction'))

    r = audit(lambda m: m['ressources'][2]['exercices'][0].update(
        {'correction': ["**1.** $\\frac{12}{100} \\times 148 = 17,80$ €."]}))
    t('un calcul faux est refusé', a_erreur(r, 'calcul faux'))

    r = audit(lambda m: m['ressources'][1]['blocs'][1].update({'comp': 'bricoler'}))
    t('une question sans compétence reconnue est refusée', a_erreur(r, 'compétence'))

    r = audit(lambda m: m['ressources'][0]['blocs'].append({'b': 'diagramme', 't': 'x'}))
    t('un bloc hors vocabulaire est refusé', a_erreur(r, 'type inconnu'))

    r = audit(lambda m: m['ressources'][0]['blocs'][6].update({'latex': ''}))
    t('une formule vide est refusée', a_erreur(r, 'formule est vide'))

    r = audit(lambda m: m['ressources'][3]['questions'][0].update({'justes': [9]}))
    t('une bonne réponse qui n\'existe pas est refusée', a_erreur(r, 'n’existe pas'))

    r = audit(lambda m: m['ressources'][2]['exercices'][0].update(
        {'correction': ["**1.** Le prix payé est de 130,24 €."]}))
    t('un nombre qui sort de nulle part est signalé', a_avert(r, '130,24'))

    r = audit(lambda m: m['ressources'][1]['blocs'].pop(5))
    t('une compétence non évaluée est signalée', a_avert(r, 'Communiquer'))

    r = audit(lambda m: m['ressources'][3]['questions'][0].pop('correction'))
    t('une question de QCM sans commentaire est signalée', a_avert(r, 'commentaire'))

    r = audit(lambda m: m['ressources'][3]['questions'][0].update({'justes': [0, 2]}))
    t('plusieurs bonnes réponses sur une question unique sont signalées',
      a_avert(r, 'une seule est attendue'))

    r = page.evaluate("() => mnrAudit({format:'autre chose'})")
    t('un fichier étranger est refusé', a_erreur(r, 'pas une ressource'))

    print('\n── 7. LE PROGRAMME EMBARQUÉ EST VÉRIFIÉ ──')
    k = page.evaluate("() => refCompte()")
    t('le programme fourni est présent',
      k['niveaux'] == 6 and k['chapitres'] == 86 and k['items'] == 507, k)
    t('chaque item se retrouve par son code',
      page.evaluate("""() => {
        let n=0, bons=0;
        refNiveaux().forEach(v=>(v.themes||[]).forEach(t=>(t.chapitres||[]).forEach(c=>{
          refItemsChapitre(c).forEach(it=>{n++;if(refItem(it.code))bons++;});})));
        return n===bons && n===507;
      }"""))
    r = page.evaluate("(m) => mnrAudit(m)", BASE)
    t('un item réel est reconnu',
      any(x['n'] == 'ok' and 'du programme reconnu' in x['msg'] for x in r),
      [x['msg'][:60] for x in r if x['n'] == 'ok'])
    r = audit(lambda m: m['meta'].update({'capacites': ['s1m1-999']}))
    t('un item inventé est refusé', a_erreur(r, 'hors programme'))
    pied = page.evaluate("""(m) => {
        m.meta.capacites=['s1m1-5'];
        const d=document.createElement('div');d.appendChild(mnrCompile(m,{}));
        return d.textContent;
      }""", cl(BASE))
    t('le pied de page nomme le niveau et son Bulletin officiel', 'BO' in pied)
    t('le pied de page nomme le chapitre visé', 'Nombres réels' in pied)
    t("l'ancien format plat est encore accepté",
      page.evaluate("""() => {
        const v=refConvertir({niveaux:[{code:'X',nom:'Essai',chapitres:[
          {code:'XC1',nom:'Chap',capacites:[{code:'XC1-C1',libelle:'Faire'}]}]}]});
        return !!v && v.niveaux[0].themes[0].chapitres[0].sections[0].items[0]==='Faire';
      }"""))

    print('\n── 8. LE PROMPT EST FABRIQUÉ PAR L\'APPLICATION ──')
    pr = page.evaluate("""() => {
      openAtelier();
      RF_SEL={'s1m1-5':true,'s1m1-6':true,'pm0m1-1':true};
      rfRendu();
      [].forEach.call(document.querySelectorAll('.at-ty'),c=>{c.checked=true;});
      mnrMajPrompt();
      return document.getElementById('at-prompt').value;
    }""")
    t('le prompt est rempli', len(pr) > 2500, len(pr))
    t('il contient les items cochés', 's1m1-5' in pr and 's1m1-6' in pr and 'pm0m1-1' in pr)
    t('il reprend le texte des items', 'Taux de pourcentage' in pr)
    t('il cite le Bulletin officiel', 'BO' in pr)
    t('il groupe par niveau', '2nde Pro' in pr and '3ème Prépa-Métiers' in pr)
    t('il décrit tous les blocs du vocabulaire',
      all(('"b":"%s"' % b) in pr for b in
          ['titre', 'texte', 'definition', 'propriete', 'attention', 'methode', 'formule',
           'exemple', 'situation', 'remarque', 'etapes', 'liste', 'tableau', 'question',
           'grille']))
    t('il nomme les cinq compétences',
      all(x in pr for x in ["S'approprier", 'Raisonner', 'Réaliser', 'Valider', 'Communiquer']))
    t('il annonce que les calculs seront refaits', 'REFAIT tous tes calculs' in pr)
    t('il rappelle de ne pas sauter la multiplication par 100', '13,4' in pr)
    t('il interdit le HTML', 'jamais de HTML' in pr)
    t('il contient un exemple complet', 'mathnotes-ressource' in pr and '"justes"' in pr)
    t('il exige un fichier téléchargeable', 'FICHIER JSON TÉLÉCHARGEABLE' in pr)
    t('il donne le nom du fichier attendu', 'ressource.mathnotes-ressource.json' in pr)
    t('il prévoit le repli en texte brut', 'Si tu ne peux pas joindre de fichier' in pr)

    print('\n── 9. L\'EXEMPLE DU PROMPT EST LUI-MÊME VALIDE ──')
    ex = page.evaluate("() => MNR_EXEMPLE")
    try:
        exo = json.loads(ex)
        bonjson = True
    except Exception as e:
        exo, bonjson = None, str(e)
    t('l\'exemple est un JSON valide', bonjson is True, bonjson)
    if exo:
        r = page.evaluate("(m) => mnrAudit(m)", exo)
        t('l\'exemple passe le contrôle qualité',
          not [x for x in r if x['n'] == 'err'],
          [x['msg'][:70] for x in r if x['n'] == 'err'])
        page.evaluate("""(m) => {
          ED.innerHTML='';ED.appendChild(mnrCompile(m,{}));reattach();paginate();
        }""", exo)
        page.wait_for_timeout(700)
        t('l\'exemple se compile', page.evaluate("() => ED.querySelectorAll('.md,.mx').length") > 3)
        t('ses mathématiques se rendent',
          page.evaluate("() => [...ED.querySelectorAll('.md,.mx')]"
                        ".every(e=>e.querySelector('.katex'))"))

    print('\n── 10. L\'IMPORT DE BOUT EN BOUT ──')
    page.evaluate("() => openAtelier()")
    page.wait_for_timeout(400)
    page.evaluate("""(m) => {
      atelierTab(2);
      document.getElementById('at-json').value='```json\\n'+JSON.stringify(m)+'\\n```';
      mnrControler();
    }""", BASE)
    page.wait_for_timeout(400)
    t('un JSON entouré de balises de code est accepté',
      page.evaluate("() => !document.getElementById('at-go').disabled"))
    n_av = page.evaluate("() => LIB.docs.length")
    page.evaluate("() => mnrImporter()")
    page.wait_for_timeout(2500)
    t('un cours est créé dans la bibliothèque',
      page.evaluate("() => LIB.docs.length") == n_av + 1)
    t('le document porte le titre de la ressource',
      page.evaluate("() => document.getElementById('doc-title').textContent")
      == 'Coefficient multiplicateur')
    t('le document est bien dessiné',
      page.evaluate("() => ED.querySelectorAll('.exo-block').length") == 1
      and page.evaluate("() => ED.querySelectorAll('.qcm-block').length") == 1)
    t('le QCM est réactif après import',
      page.evaluate("""() => {
        const a=ED.querySelectorAll('.qcm-q')[0].querySelectorAll('.qcm-a')[0];
        a.querySelector('.qcm-box').click();
        return a.dataset.ok==='1';
      }"""))
    t('la mise en page est faite', page.evaluate("() => pgInfo.pages") >= 2,
      page.evaluate("() => pgInfo.pages"))

    print('\n── 11. UN FICHIER FAUTIF NE PASSE PAS ──')
    page.evaluate("() => openAtelier()")
    page.wait_for_timeout(300)
    page.evaluate("""() => {
      atelierTab(2);
      document.getElementById('at-json').value='ceci n\\'est pas du JSON';
      mnrControler();
    }""")
    page.wait_for_timeout(300)
    t('un texte illisible bloque le bouton',
      page.evaluate("() => document.getElementById('at-go').disabled"))
    t('le rapport le dit', 'JSON valide' in
      page.evaluate("() => document.getElementById('at-rap').textContent"))
    page.evaluate("""(m) => {
      m.ressources[3].questions[0].justes=[];
      document.getElementById('at-json').value=JSON.stringify(m);
      mnrControler();
    }""", cl(BASE))
    page.wait_for_timeout(300)
    t('une erreur bloquante empêche l\'import',
      page.evaluate("() => document.getElementById('at-go').disabled"))
    t('le rapport nomme le défaut', 'bonne réponse' in
      page.evaluate("() => document.getElementById('at-rap').textContent"))

    print('\n── 12. LE PARCOURS CHOISI À L\'IMPORT ──')
    page.evaluate("""(m) => {
      atelierTab(2);
      document.getElementById('at-parcours').value='pas-a-pas';
      document.getElementById('at-json').value=JSON.stringify(m);
      mnrControler();
    }""", BASE)
    page.wait_for_timeout(300)
    page.evaluate("() => mnrImporter()")
    page.wait_for_timeout(2500)
    t('le titre porte le nom du parcours',
      'pas à pas' in page.evaluate("() => document.getElementById('doc-title').textContent"),
      page.evaluate("() => document.getElementById('doc-title').textContent"))
    t('l\'étayage est bien présent',
      page.evaluate("() => ED.querySelectorAll('.exo-block').length") == 2)
    t('l\'enrichissement est bien absent',
      page.evaluate("() => ED.querySelectorAll('.md').length") == 1)

    print('\n── 13. L\'ARBRE DU PROGRAMME ──')
    page.evaluate("() => { openAtelier(); RF_SEL={};"
                  " document.getElementById('at-q').value=''; rfRendu(); }")
    page.wait_for_timeout(500)
    t('les six niveaux sont affichés',
      page.evaluate("() => document.querySelectorAll('#at-arbre > .rf-n').length") == 6)
    t('les niveaux sont repliés au départ',
      page.evaluate("() => document.querySelectorAll('#at-arbre .rf-n.ouvert').length") == 0)
    t('chaque niveau annonce son Bulletin officiel',
      page.evaluate("() => document.querySelectorAll('#at-arbre .rf-bo').length") == 6)
    t('les 86 chapitres sont présents',
      page.evaluate("() => document.querySelectorAll('#at-arbre .rf-ch').length") == 86)
    t('les 507 items sont présents',
      page.evaluate("() => document.querySelectorAll('#at-arbre .rf-it').length") == 507)
    page.evaluate("() => { document.getElementById('at-q').value='indice simple'; rfRendu(); }")
    page.wait_for_timeout(300)
    nres = page.evaluate("() => document.querySelectorAll('#at-arbre .rf-it').length")
    t('la recherche réduit la liste', 0 < nres < 20, nres)
    t('la recherche ouvre le chemin trouvé',
      page.evaluate("() => document.querySelectorAll('#at-arbre .rf-n.ouvert').length") > 0)
    t('le terme cherché est surligné',
      page.evaluate("() => document.querySelectorAll('#at-arbre mark.rf-m').length") > 0)
    page.evaluate("() => { document.getElementById('at-q').value='zzzzz'; rfRendu(); }")
    page.wait_for_timeout(250)
    t('une recherche sans résultat le dit',
      'Aucun chapitre' in page.evaluate("() => document.getElementById('at-arbre').textContent"))
    page.evaluate("() => { document.getElementById('at-q').value=''; rfRendu(); }")
    page.wait_for_timeout(400)
    page.evaluate("""() => {
      const c=[...document.querySelectorAll('#at-arbre .rf-chh input')]
        .find(x=>x.dataset.ch==='s1m1');
      c.checked=true;rfTout(c);
    }""")
    page.wait_for_timeout(300)
    t('cocher le chapitre prend tous ses items',
      page.evaluate("() => rfChoisis().length") == 9,
      page.evaluate("() => rfChoisis().length"))
    t('le bilan est juste',
      '9 items' in page.evaluate("() => document.getElementById('at-bilan').textContent"),
      page.evaluate("() => document.getElementById('at-bilan').textContent"))
    page.evaluate("""() => {
      const i=[...document.querySelectorAll('#at-arbre .rf-i')].find(x=>x.value==='pm0m1-1');
      i.checked=true;rfCoche(i);
    }""")
    page.wait_for_timeout(300)
    t('on pioche dans plusieurs niveaux',
      '2 niveaux' in page.evaluate("() => document.getElementById('at-bilan').textContent"),
      page.evaluate("() => document.getElementById('at-bilan').textContent"))
    t('un chapitre partiellement coché est signalé',
      page.evaluate("""() => {
        const c=[...document.querySelectorAll('#at-arbre .rf-chh input')]
          .find(x=>x.dataset.ch==='pm0m1');
        return c.indeterminate===true;
      }"""))
    page.evaluate("""() => {
      const i=[...document.querySelectorAll('#at-arbre .rf-i')].find(x=>x.value==='s1m1-3');
      i.checked=false;rfCoche(i);
    }""")
    page.wait_for_timeout(300)
    t('décocher un item ne touche pas les autres',
      page.evaluate("() => rfChoisis().length") == 9,
      page.evaluate("() => rfChoisis().length"))
    t("le chapitre n'est plus entièrement coché",
      page.evaluate("""() => {
        const c=[...document.querySelectorAll('#at-arbre .rf-chh input')]
          .find(x=>x.dataset.ch==='s1m1');
        return !c.checked;
      }"""))
    page.evaluate("() => rfVider()")
    page.wait_for_timeout(250)
    t('tout décocher vide la sélection', page.evaluate("() => rfChoisis().length") == 0)
    t('le bilan revient à zéro',
      'Aucun item' in page.evaluate("() => document.getElementById('at-bilan').textContent"))

    print('\n── 14. SAISIE LIBRE ET ASSISTANTS ──')
    page.evaluate("""() => {
      document.getElementById('at-libre-on').checked=true;rfLibre();
      document.getElementById('at-libre-niv').value='1re Bac Pro, groupement B';
      document.getElementById('at-libre-chap').value='Statistique à une variable';
      document.getElementById('at-libre-obj').value=
        'Calculer une moyenne pondérée\\nLire un diagramme en boîte';
      mnrMajPrompt();
    }""")
    page.wait_for_timeout(300)
    pr = page.evaluate("() => document.getElementById('at-prompt').value")
    t('la saisie libre apparaît',
      page.evaluate("() => document.getElementById('at-libre').style.display") != 'none')
    t('le niveau libre passe dans le prompt', '1re Bac Pro, groupement B' in pr)
    t('le chapitre libre passe dans le prompt', 'Statistique à une variable' in pr)
    t('les objectifs libres passent dans le prompt',
      'moyenne pondérée' in pr and 'diagramme en boîte' in pr)
    t('ils sont codés à part', '[libre-1]' in pr and '"libre-1"' in pr)
    t('les quatre assistants sont proposés',
      page.evaluate("() => document.querySelectorAll('#at-ia .at-ia-b').length") == 4)
    liens = page.evaluate("() => [...document.querySelectorAll('#at-ia .at-ia-b')]"
                          ".map(a=>a.getAttribute('href'))")
    t('ChatGPT est proposé', 'https://chatgpt.com/' in liens, liens)
    t('Gemini est proposé', 'https://gemini.google.com/app' in liens)
    t('Claude est proposé', 'https://claude.ai/new' in liens)
    t("l'assistant souverain de l'Éducation nationale est proposé",
      'https://assistance.phm.education.gouv.fr' in liens)
    t("chaque lien s'ouvre dans un nouvel onglet",
      page.evaluate("() => [...document.querySelectorAll('#at-ia .at-ia-b')]"
                    ".every(a=>a.target==='_blank'&&/noopener/.test(a.rel))"))
    t("l'onglet s'appelle Générer Ressource",
      'Générer Ressource' in page.evaluate("() => document.getElementById('at-t1').textContent"))
    page.evaluate("() => { document.getElementById('at-libre-on').checked=false;rfLibre(); }")

    print('\nerreurs de console :', page.errors[:3] or 'aucune')
    t('aucune erreur de console au total', not page.errors, page.errors[:2])

print('\n%d PASS / %d FAIL' % (ok, ko))
raise SystemExit(1 if ko else 0)
