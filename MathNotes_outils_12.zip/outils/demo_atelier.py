# -*- coding: utf-8 -*-
"""Preuve de la boucle : programme → prompt → ressource → document.

La ressource ci-dessous est écrite comme le ferait la conversation à
partir du prompt fabriqué par l'application. Elle est ensuite contrôlée
et compilée par MathNotes, sans retouche.
"""
import json
import os
import re
import subprocess
import tempfile
from harness import open_app

SORTIE = '/mnt/user-data/outputs'

# Le programme de l'auteur est désormais embarqué dans l'application :
# on vise de vrais items du chapitre « Nombres réels et calcul numérique »
# de 2nde Pro.
CODES = ['s1m1-4', 's1m1-5', 's1m1-6', 's1m1-7', 's1m1-9']

# ── la réponse de la conversation ──
RESSOURCE = {
 "format": "mathnotes-ressource", "version": 1,
 "meta": {"titre": "Pourcentages et coefficients multiplicateurs",
          "niveau": "2nde Pro", "chapitre": "Nombres réels et calcul numérique",
          "capacites": CODES,
          "duree": 55},
 "ressources": [

  {"type": "cours", "titre": "Pourcentages et coefficients multiplicateurs",
   "chapeau": "**2de Bac Pro — Chapitre 3.** Facturation, devis, remises, TVA, suivi de consommation : ce chapitre sert dans tous les ateliers.",
   "blocs": [
    {"b": "titre", "n": 2, "t": "1. Proportion et pourcentage"},
    {"b": "definition", "t": "Dans une population de $N$ individus, une partie de $n$ individus représente la **proportion** $p$. Multipliée par 100, cette proportion s’écrit en **pourcentage**."},
    {"b": "formule", "latex": "p = \\frac{n}{N} = \\frac{\\text{effectif partiel}}{\\text{effectif total}}"},
    {"b": "methode", "t": "Pour appliquer un pourcentage à une quantité, on multiplie cette quantité par le taux divisé par 100."},
    {"b": "formule", "latex": "p\\,\\% \\text{ de } N = \\frac{p}{100} \\times N"},
    {"b": "exemple", "lignes": [
      "**Exemple** — Dans un atelier de 25 apprentis, 15 préparent un CAP Maintenance des véhicules.",
      "$\\frac{15}{25} = 0,6$ et $0,6 \\times 100 = 60$",
      "La proportion d’apprentis en CAP est donc de **60 %** de l’effectif."]},
    {"b": "methode", "niv": "-", "titre": "Pas à pas",
     "t": "**1.** Je repère l’effectif total, celui du dessous de la barre de fraction. **2.** Je repère l’effectif partiel, celui du dessus. **3.** Je divise le partiel par le total. **4.** Je multiplie par 100 pour lire le pourcentage."},

    {"b": "titre", "n": 2, "t": "2. Le taux d’évolution"},
    {"b": "definition", "t": "Une grandeur passe d’une valeur initiale $V_i$ à une valeur finale $V_f$. Le **taux d’évolution** $t$, en pourcentage, mesure cette variation par rapport à la valeur de départ."},
    {"b": "formule", "latex": "t = \\frac{V_f - V_i}{V_i} \\times 100"},
    {"b": "exemple", "lignes": [
      "**Exemple** — Le prix d’un scooter d’occasion passe de 1 250 € à 1 100 €.",
      "$t = \\frac{1100 - 1250}{1250} \\times 100 = -12$",
      "Le prix a donc **baissé de 12 %**."]},
    {"b": "attention", "t": "Le taux se calcule toujours sur la **valeur de départ**. Diviser par la valeur d’arrivée est l’erreur la plus fréquente."},
    {"b": "etapes", "niv": "-", "items": [
      "Je soustrais : valeur d’arrivée moins valeur de départ.",
      "Je divise ce résultat par la valeur de départ.",
      "Je multiplie par 100.",
      "Si je trouve un nombre négatif, c’est une baisse."]},

    {"b": "titre", "n": 2, "t": "3. Le coefficient multiplicateur"},
    {"b": "propriete", "t": "Appliquer une évolution de $t$ %, c’est multiplier par un nombre appelé **coefficient multiplicateur**, noté $CM$."},
    {"b": "formule", "titre": "Coefficient multiplicateur",
     "latex": "CM = 1 + \\frac{t}{100} \\\\ V_f = V_i \\times CM"},
    {"b": "tableau", "entete": ["Évolution", "Calcul du CM", "CM", "Lecture"],
     "lignes": [["+ 20 %", "$1 + \\frac{20}{100}$", "1,20", "hausse"],
                ["+ 5,5 %", "$1 + \\frac{5,5}{100}$", "1,055", "hausse"],
                ["− 30 %", "$1 - \\frac{30}{100}$", "0,70", "baisse"],
                ["− 12 %", "$1 - \\frac{12}{100}$", "0,88", "baisse"]]},
    {"b": "texte", "t": "Un coefficient **supérieur à 1** traduit une hausse, **inférieur à 1** une baisse, **égal à 1** aucune variation."},
    {"b": "attention", "t": "Une hausse de 20 % suivie d’une baisse de 20 % ne ramène pas au prix de départ : $1,20 \\times 0,80 = 0,96$, soit une **baisse de 4 %**."},

    {"b": "titre", "n": 2, "t": "4. Évolutions successives"},
    {"b": "propriete", "t": "Deux évolutions qui se suivent se traduisent par le **produit** de leurs coefficients multiplicateurs. Les taux, eux, ne s’additionnent pas."},
    {"b": "formule", "latex": "CM_{\\text{global}} = CM_1 \\times CM_2"},
    {"b": "exemple", "lignes": [
      "**Exemple** — Un blouson affiché 80 € subit une première démarque de −30 %, puis une seconde de −20 % supplémentaires.",
      "$CM_1 = 0,70$ et $CM_2 = 0,80$, donc $0,70 \\times 0,80 = 0,56$",
      "$0,56 - 1 = -0,44$ puis $-0,44 \\times 100 = -44$ : le taux global vaut **−44 %**, et non −50 %.",
      "Prix final : $80 \\times 0,56 = 44,80$ €."]},
    {"b": "propriete", "niv": "+", "titre": "Évolution réciproque",
     "t": "Pour annuler une évolution, on multiplie par l’**inverse** de son coefficient. Annuler une hausse de 25 % revient donc à multiplier par $\\frac{1}{1,25}$, soit une baisse de 20 % : $\\frac{1}{1,25} = 0,8$."},

    {"b": "titre", "n": 2, "t": "5. Deux applications de l’atelier"},
    {"b": "methode", "titre": "TVA", "t": "Le prix toutes taxes comprises s’obtient en appliquant le taux de TVA au prix hors taxes."},
    {"b": "formule", "latex": "P_{TTC} = P_{HT} \\times \\left(1 + \\frac{t_{TVA}}{100}\\right)"},
    {"b": "tableau", "entete": ["Taux de TVA", "Ce qu’il concerne", "CM"],
     "lignes": [["20 %", "taux normal : pièces, main-d’œuvre", "1,20"],
                ["10 %", "travaux de rénovation d’un logement", "1,10"],
                ["5,5 %", "travaux d’amélioration énergétique", "1,055"]]},
    {"b": "situation", "titre": "Garage", "lignes": [
      "Un devis de réparation comprend 340 € HT de main-d’œuvre et 185 € HT de pièces. Le taux de TVA applicable est le taux normal, 20 %.",
      "Total hors taxes : $340 + 185 = 525$ €.",
      "Total toutes taxes : $525 \\times 1,20 = 630$ €.",
      "La TVA facturée vaut donc $630 - 525 = 105$ €."]},
    {"b": "methode", "titre": "Retrouver le prix hors taxes",
     "t": "L’opération inverse d’une multiplication par $CM$ est une **division** par $CM$. Retirer 20 % du prix TTC donnerait un résultat faux."},
   ]},

  {"type": "evaluation", "titre": "Évaluation par compétences — Les pourcentages",
   "chapeau": "Nom : …………………………  Classe : ……………  Date : ……………  **Durée : 45 min.** Calculatrice autorisée.",
   "blocs": [
    {"b": "remarque", "titre": "📋 Contexte — Magasin de pièces détachées « Méca-Pro »", "lignes": [
      "Le magasin vend des plaquettes de frein au prix de **48 € HT** l’unité. Il en a vendu **250** en mars et **290** en avril. Le taux de TVA appliqué est le **taux normal, 20 %**.",
      "Pour la Semaine de la mécanique, le gérant décide d’une **remise de 15 %** sur le prix hors taxes."]},
    {"b": "question", "comp": "s'approprier", "bareme": 2,
     "t": "Relever, dans le contexte ci-dessus, le prix hors taxes d’une plaquette et le nombre de plaquettes vendues en mars."},
    {"b": "question", "comp": "réaliser", "bareme": 3,
     "t": "Calculer le prix TTC d’une plaquette, au taux normal de 20 %."},
    {"b": "question", "comp": "réaliser", "bareme": 4,
     "t": "Calculer le taux d’évolution du nombre de plaquettes vendues entre mars et avril. Arrondir à 0,1 %."},
    {"b": "question", "comp": "raisonner", "bareme": 4,
     "t": "Le gérant affirme : « une remise de 15 %, puis 10 % de plus sur le reste, cela revient à 25 % de remise ». A-t-il raison ? Justifier par le calcul du coefficient multiplicateur global."},
    {"b": "question", "comp": "valider", "bareme": 4,
     "t": "Un client annonce payer **40 € TTC** une plaquette remisée de 15 %. Ce montant est-il vraisemblable ? Justifier."},
    {"b": "question", "comp": "communiquer", "bareme": 3,
     "t": "Rédiger en trois lignes, à l’intention d’un client, l’explication de la remise appliquée au prix hors taxes puis de la TVA."},
    {"b": "question", "comp": "raisonner", "bareme": 2, "niv": "+",
     "t": "Quelle remise unique, arrondie à 0,1 %, remplacerait exactement les deux remises successives de l’affirmation du gérant ?"},
    {"b": "texte", "t": "**Grille d’évaluation**"},
    {"b": "grille", "lignes": [
      {"comp": "s'approprier", "attendu": "Extraire l’information utile de l’énoncé", "questions": "1"},
      {"comp": "réaliser", "attendu": "Mener à bien un calcul de pourcentage", "questions": "2 et 3"},
      {"comp": "raisonner", "attendu": "Enchaîner deux évolutions successives", "questions": "4"},
      {"comp": "valider", "attendu": "Contrôler la vraisemblance d’un résultat", "questions": "5"},
      {"comp": "communiquer", "attendu": "Expliquer une démarche par écrit", "questions": "6"}]},
   ]},

  {"type": "qcm", "titre": "QCM — Coefficients multiplicateurs et pourcentages",
   "chapeau": "Cochez la ou les bonnes réponses. ◯ signale une seule bonne réponse, ☐ plusieurs.",
   "commentaire": "Retenir : un coefficient multiplicateur est **toujours positif**. Au-dessus de 1 il traduit une hausse, en dessous une baisse. Deux évolutions successives se **multiplient**, elles ne s’additionnent pas.",
   "questions": [
    {"comp": "s'approprier", "multi": False,
     "t": "Un article coûte 60 €. Son prix augmente de 15 %. Quel est le coefficient multiplicateur ?",
     "reponses": ["0,15", "1,15", "15", "1,015"], "justes": [1],
     "correction": "Une hausse de $t$ % correspond à $1 + \\frac{15}{100} = 1,15$."},
    {"comp": "réaliser", "multi": False,
     "t": "Le prix d’une pièce passe de 60 € à 69 €. Quel est le taux d’évolution ?",
     "reponses": ["+ 9 %", "+ 13 %", "+ 15 %", "+ 90 %"], "justes": [2],
     "correction": "$\\frac{69 - 60}{60} \\times 100 = 15$. Le prix a augmenté de 15 %."},
    {"comp": "raisonner", "multi": False,
     "t": "Quel coefficient multiplicateur correspond à une baisse de 30 % ?",
     "reponses": ["0,30", "0,70", "1,30", "− 0,30"], "justes": [1],
     "correction": "Une baisse de 30 % donne $1 - \\frac{30}{100} = 0,70$. Un coefficient est toujours positif."},
    {"comp": "réaliser", "multi": True,
     "t": "Parmi ces coefficients multiplicateurs, lesquels traduisent une hausse ?",
     "reponses": ["1,04", "0,96", "2,5", "0,995"], "justes": [0, 2],
     "correction": "Un coefficient strictement supérieur à 1 traduit une hausse. Les deux autres sont inférieurs à 1, donc des baisses."},
    {"comp": "raisonner", "multi": False,
     "t": "Une hausse de 25 % suivie d’une baisse de 25 % correspond à :",
     "reponses": ["aucune variation", "une baisse de 6,25 %", "une hausse de 6,25 %", "une baisse de 50 %"],
     "justes": [1],
     "correction": "$1,25 \\times 0,75 = 0,9375$. Le coefficient global est inférieur à 1 : c’est une baisse. Les taux ne s’additionnent jamais."},
    {"comp": "valider", "multi": False,
     "t": "Une facture de 300 € TTC a été établie au taux de TVA de 20 %. Pour retrouver le prix hors taxes, il faut :",
     "reponses": ["retirer 20 % de 300 €", "diviser 300 par 1,20",
                  "multiplier 300 par 0,80", "retirer 60 € à 300 €"], "justes": [1],
     "correction": "$300 \\div 1,20 = 250$ €, et l’on vérifie que $250 \\times 1,20 = 300$. Retirer 20 % donnerait $300 \\times 0,80 = 240$ €, ce qui est faux."},
   ]},

  {"type": "exercices", "titre": "Feuille d’exercices corrigés",
   "chapeau": "Chaque correction se replie et se déplie avec son bouton. À l’impression, choisissez la version élève pour la masquer.",
   "exercices": [
    {"titre": "Appliquer une remise",
     "enonce": ["Un lot de 40 cartouches d’encre est facturé **148 € HT**. Le fournisseur accorde une **remise de 12 %** sur ce montant.",
                "**1.** Calculer le montant de la remise.",
                "**2.** En déduire le prix payé, par deux méthodes différentes."],
     "correction": ["**1.** $\\frac{12}{100} \\times 148 = 17,76$ €.",
                    "**2.** Première méthode — on retire la remise : $148 - 17,76 = 130,24$ €.",
                    "Seconde méthode — on multiplie par le coefficient : $1 - \\frac{12}{100} = 0,88$ puis $148 \\times 0,88 = 130,24$ €.",
                    "Les deux méthodes donnent le même prix payé."]},
    {"titre": "Appliquer une remise, pas à pas", "niv": "-",
     "enonce": ["Un lot de 40 cartouches d’encre est facturé **148 € HT**. Le fournisseur accorde une **remise de 12 %** sur ce montant.",
                "**1.** Compléter : la remise vaut $\\frac{12}{100}$ de $148$ €, c’est-à-dire $\\frac{12}{100} \\times \\square$.",
                "**2.** Effectuer ce calcul.",
                "**3.** Retirer le résultat au prix de départ."],
     "correction": ["**1.** On complète par le prix de départ : $\\frac{12}{100} \\times 148$.",
                    "**2.** $\\frac{12}{100} \\times 148 = 17,76$ €.",
                    "**3.** $148 - 17,76 = 130,24$ €."]},
    {"titre": "Calculer un taux d’évolution",
     "enonce": ["La consommation électrique d’un atelier était de **1 840 kWh** en janvier et de **1 564 kWh** en février.",
                "**1.** Calculer le taux d’évolution de la consommation.",
                "**2.** Interpréter le résultat en une phrase."],
     "correction": ["**1.** $t = \\frac{1564 - 1840}{1840} \\times 100 = -15$.",
                    "**2.** La consommation de l’atelier a **baissé de 15 %** entre janvier et février.",
                    "Vérification : $1840 \\times 0,85 = 1564$ kWh."]},
    {"titre": "Deux évolutions qui se suivent",
     "enonce": ["Une pièce détachée valait **62 €** fin 2023. Son prix a augmenté de **8 %** en 2024, puis de **5 %** en 2025.",
                "**1.** Donner le coefficient multiplicateur de chaque année.",
                "**2.** En déduire le coefficient global, puis le taux global.",
                "**3.** Calculer le prix de la pièce fin 2025, arrondi au centime."],
     "correction": ["**1.** $1 + \\frac{8}{100} = 1,08$ et $1 + \\frac{5}{100} = 1,05$.",
                    "**2.** $1,08 \\times 1,05 = 1,134$, donc $1,134 - 1 = 0,134$ et $0,134 \\times 100 = 13,4$ : le taux global vaut **+ 13,4 %**.",
                    "Ce n’est pas la somme des deux taux, car la seconde hausse porte sur un prix déjà augmenté.",
                    "**3.** $62 \\times 1,134 = 70,31$ € arrondi au centime."]},
    {"titre": "Facturation TTC et HT",
     "enonce": ["**🔧 Situation professionnelle.** Un artisan facture une intervention **468 € TTC**, au **taux normal de TVA, 20 %**.",
                "**1.** Calculer le prix hors taxes de l’intervention.",
                "**2.** En déduire le montant de la TVA facturée.",
                "**3.** Pour une autre intervention, l’artisan veut un prix hors taxes de **420 €**. Quel montant TTC annoncer ?"],
     "correction": ["**1.** Le prix TTC s’obtient en multipliant le prix HT par $1 + \\frac{20}{100} = 1,20$. On effectue l’opération inverse : $468 \\div 1,20 = 390$ €.",
                    "**2.** $468 - 390 = 78$ €. On vérifie : $\\frac{20}{100} \\times 390 = 78$ €.",
                    "**3.** $420 \\times 1,20 = 504$ €."]},
    {"titre": "Remonter à la valeur de départ", "niv": "+",
     "enonce": ["Après une hausse de **6 %**, une pièce est affichée **53 €**, arrondi au centime.",
                "**1.** Quel coefficient multiplicateur a été appliqué ?",
                "**2.** Retrouver le prix avant la hausse, arrondi au centime.",
                "**3.** Quelle baisse, arrondie à 0,1 %, ramènerait au prix de départ ?"],
     "correction": ["**1.** $1 + \\frac{6}{100} = 1,06$.",
                    "**2.** $53 \\div 1,06 = 50$ €.",
                    "**3.** On multiplie par l’inverse : $\\frac{1}{1,06} = 0,943$ au millième, et $0,943 - 1 = -0,057$ puis $-0,057 \\times 100 = -5,7$ : une baisse d’environ **5,7 %**."]},
   ]},
 ]
}

ok = ko = 0


def t(nom, cond, detail=''):
    global ok, ko
    if cond:
        ok += 1
        print('  PASS  ' + nom)
    else:
        ko += 1
        print('  FAIL  ' + nom + ('   → ' + str(detail) if detail else ''))


with open_app() as page:
    page.on('dialog', lambda d: d.accept())

    print('\n── LE PROGRAMME EMBARQUÉ ──')
    k = page.evaluate("() => refCompte()")
    print('   ', k)
    t('les six niveaux sont là', k['niveaux'] == 6, k)
    t('les 86 chapitres sont là', k['chapitres'] == 86, k)
    t('les 507 items sont là', k['items'] == 507, k)
    t('les items visés existent tous',
      page.evaluate("(c) => c.every(x => !!refItem(x))", CODES))

    print('\n── L\'APPLICATION FABRIQUE LE PROMPT ──')
    prompt = page.evaluate("""(codes) => {
      openAtelier();
      RF_SEL={};codes.forEach(c=>{RF_SEL[c]=true;});
      rfRendu();
      document.getElementById('at-filiere').value='maintenance des véhicules';
      [].forEach.call(document.querySelectorAll('.at-ty'),c=>{c.checked=true;});
      mnrMajPrompt();
      closeM('m-atelier');
      return document.getElementById('at-prompt').value;
    }""", CODES)
    t('le prompt contient les cinq items visés', all(c in prompt for c in CODES))
    t('il cite le Bulletin officiel du niveau', 'BO spécial' in prompt, prompt[:0])
    t('il nomme le chapitre', 'Nombres réels et calcul numérique' in prompt)
    t('il annonce les cinq ressources demandées',
      all(x in prompt for x in ['"cours"', '"fiche"', '"evaluation"', '"qcm"', '"exercices"']))
    open(os.path.join(SORTIE, 'PROMPT_MathNotes_Atelier.txt'), 'w',
         encoding='utf-8').write(prompt)
    print('   %d lignes, %.1f Ko' % (prompt.count('\n') + 1, len(prompt.encode()) / 1024))

    print('\n── LE CONTRÔLE QUALITÉ PASSE LA RESSOURCE AU CRIBLE ──')
    rap = page.evaluate("(m) => mnrAudit(m)", RESSOURCE)
    for x in rap:
        print('   %s %s' % ({'err': '❌', 'warn': '⚠️ ', 'ok': '✅'}[x['n']], x['msg'][:96]))
    t('aucune erreur bloquante', not [x for x in rap if x['n'] == 'err'],
      [x['msg'] for x in rap if x['n'] == 'err'][:3])
    t('aucun avertissement', not [x for x in rap if x['n'] == 'warn'],
      [x['msg'] for x in rap if x['n'] == 'warn'][:3])

    print('\n── LES TROIS PARCOURS SORTENT D\'UNE SEULE SOURCE ──')
    pages = {}
    for p in ('standard', 'plus', 'pas-a-pas'):
        page.evaluate("""(a) => {
          ED.innerHTML='';ED.appendChild(mnrCompile(a.m,{parcours:a.p}));
          reattach();tableColumnsAsPercent();paginate();
        }""", {"m": RESSOURCE, "p": p})
        page.wait_for_timeout(1400)
        pages[p] = page.evaluate("""() => ({
          pages: pgInfo.pages,
          exos: ED.querySelectorAll('.exo-block').length,
          quest: ED.querySelectorAll('.qcm-q').length,
          comps: ED.querySelectorAll('.comp').length,
          katex: ED.querySelectorAll('.katex').length,
          err: ED.querySelectorAll('.katex-error').length
        })""")
        print('   %-10s %s' % (p, pages[p]))
    t('le parcours standard tient sur plusieurs pages', pages['standard']['pages'] >= 8)
    t('« pas à pas » ajoute son étayage',
      pages['pas-a-pas']['exos'] == pages['standard']['exos'] + 1)
    t('« plus loin » ajoute son enrichissement',
      pages['plus']['exos'] == pages['standard']['exos'] + 1)
    t('les deux parcours différenciés diffèrent bien',
      pages['plus']['pages'] != pages['pas-a-pas']['pages']
      or pages['plus']['comps'] != pages['pas-a-pas']['comps'])
    t('aucune formule en erreur, dans les trois',
      all(p['err'] == 0 for p in pages.values()))
    t('les mathématiques sont toutes rendues',
      all(p['katex'] > 40 for p in pages.values()),
      {k: v['katex'] for k, v in pages.items()})

    print('\n── L\'IMPORT COMPLET, PAR LA FENÊTRE ──')
    page.evaluate("""(m) => {
      openAtelier();atelierTab(2);
      document.getElementById('at-parcours').value='standard';
      document.getElementById('at-json').value=JSON.stringify(m,null,1);
      mnrControler();
    }""", RESSOURCE)
    page.wait_for_timeout(500)
    t('le bouton de création est actif',
      not page.evaluate("() => document.getElementById('at-go').disabled"))
    page.evaluate("() => mnrImporter()")
    page.wait_for_timeout(3000)
    t('le document porte le titre de la ressource',
      page.evaluate("() => document.getElementById('doc-title').textContent")
      == 'Pourcentages et coefficients multiplicateurs')
    n_pages = page.evaluate("() => pgInfo.pages")
    t('le document est paginé', n_pages >= 8, n_pages)

    print('\n── LE PAPIER SUIT L\'ÉCRAN ──')
    pdf = os.path.join(tempfile.gettempdir(), 'atelier.pdf')
    page.evaluate("(w) => { window.__r = preparePrint(w); }", True)
    page.wait_for_timeout(1200)
    attendu = page.evaluate("() => pgInfo.pages")
    page.pdf(path=pdf, format='A4', print_background=True,
             margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
    page.evaluate("() => window.__r()")
    page.wait_for_timeout(900)
    info = subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout
    papier = int(re.search(r'Pages:\s+(\d+)', info).group(1))
    t('même nombre de pages à l\'écran et sur le papier', papier == attendu, (attendu, papier))

    # captures
    for i, sel in enumerate(["ED.querySelector('h1')",
                             "[...ED.querySelectorAll('h1')][1]",
                             "ED.querySelector('.qcm-block')"]):
        page.evaluate("(s)=>{const e=eval(s);e.scrollIntoView({block:'start'});window.scrollBy(0,-110);}", sel)
        page.wait_for_timeout(400)
        page.screenshot(path='/tmp/claude-0/d%d.png' % i)

    print('\nerreurs de console :', page.errors[:3] or 'aucune')
    t('aucune erreur de console', not page.errors, page.errors[:2])

# fichiers livrés
json.dump(RESSOURCE, open(os.path.join(SORTIE, 'ressource-exemple.mathnotes-ressource.json'),
                          'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('\n%d PASS / %d FAIL' % (ok, ko))
raise SystemExit(1 if ko else 0)
