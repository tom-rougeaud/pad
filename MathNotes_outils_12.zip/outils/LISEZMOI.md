# Outils de MathNotes

Chaîne de fabrication et batterie de tests. Voir `MathNotes_DOSSIER_TECHNIQUE.md`
pour le mode d'emploi complet.

## Installation

```bash
npm install katex@0.16.9 @fontsource/dm-sans @fontsource/dm-mono @fontsource/lora
pip install playwright beautifulsoup4
```

Placer `MathNotes_source.html` (ou `MathNotes.html`) dans ce dossier.

## Fabrication

```bash
python3 build.py source MathNotes.html MathNotes_source.html   # version éditable, 0,52 Mo
python3 build.py dist   MathNotes_source.html MathNotes.html   # version publiable, 1,13 Mo
```

L'aller-retour doit rendre un fichier **identique à l'octet près** :

```bash
python3 build.py source MathNotes.html /tmp/s.html \
  && python3 build.py dist /tmp/s.html /tmp/d.html && cmp MathNotes.html /tmp/d.html
```

## Catalogue de modèles

```bash
# éditer tpl_a.py / tpl_b.py, puis :
python3 gen_tpls.py && python3 catalog_test.py && python3 exc_audit.py
```

## Relecture du JavaScript

À faire après chaque modification, avant les tests :

```bash
python3 extract_js.py \
  && node --check _app.js \
  && npx eslint --no-eslintrc -c .eslintrc.json _app.js \
  && python3 check_calls.py
```

## Tests — 539 vérifications

```bash
for t in catalog_test exc_audit ex_test qcm_test qcm2_test regress_test \
         pdf_test qcm_pdf_test lib_test img2_test safety_test offline_test \
         tablet_test idb_test leak_test fmt_test comp_test pg_test mnr_test \
         demo_atelier porte_test print_audit; do
  printf '%-16s ' $t; python3 $t.py 2>&1 | tail -1
done
```

Les tests s'exécutent sur `MathNotes.html`. Pour tester la version source,
lancer d'abord `python3 build.py dist MathNotes_source.html MathNotes.html`.

`pg_test.py` et `pdf_test.py` produisent des PDF et ont besoin de `pdfinfo`
et `pdftotext` (paquet `poppler-utils`).

## Programme embarqué

```bash
python3 gen_ref.py   # programme_maths_accordeon.json → _ref.json (compact, 46 Ko)
```

`_ref.json` est inséré tel quel dans `REF_DEFAUT` par `p_ref.py`. Les codes
d'item sont fabriqués à partir de l'identifiant de chapitre et du rang :
le chapitre `pm0m1` donne `pm0m1-1`, `pm0m1-2`…

## Atelier de ressources

```bash
python3 mnr_test.py      # 124 vérifications sur le compilateur, le contrôle et l'arbre
python3 porte_test.py    # 40 vérifications sur la reconnaissance des fichiers
python3 demo_atelier.py  # la boucle complète, et les fichiers d'exemple livrés
```

`demo_atelier.py` contient le programme d'exemple et une ressource écrite comme
le ferait la conversation : c'est le meilleur endroit où lire le format MNR.
Le prompt, lui, ne vit nulle part en fichier — il est fabriqué par `mnrPrompt`
à partir de `MNR_BLOCS` et du référentiel, pour ne jamais vieillir.

## Cours de démonstration

```bash
python3 gen_cours.py    # fabrique Cours_Pourcentages_Bac_Pro.mathnotes.json
python3 cours_test.py   # 55 vérifications sur ce fichier, réimporté dans l'application
```

Le contenu se modifie dans `cours_pourcentages.js`. Le document est construit
*dans l'application*, avec ses propres fabriques : le fichier obtenu est donc
exactement ce qu'aurait produit un professeur en cliquant dans le ruban.

## Documents dérivés

```bash
python3 build_guide.py && python3 guide_pdf.py   # guide complet, tiré du Tuto de l'application
python3 pres_pdf.py                              # présentation 2 pages, tirée de presentation.html
```
