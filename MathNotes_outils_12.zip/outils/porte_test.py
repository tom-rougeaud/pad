# -*- coding: utf-8 -*-
"""Une seule porte : quoi qu'on ouvre, l'application reconnaît et emmène.

On éprouve surtout les fichiers tels qu'un assistant les renvoie
vraiment : emballés dans un bloc de code, précédés d'une phrase, avec
une virgule de trop, ou sans l'étiquette « format ».
"""
import json
from harness import open_app

ok = ko = 0


def t(nom, cond, detail=''):
    global ok, ko
    if cond:
        ok += 1
        print('  PASS  ' + nom)
    else:
        ko += 1
        print('  FAIL  ' + nom + ('   → ' + str(detail) if detail else ''))


RES = json.load(open('/mnt/user-data/outputs/ressource-exemple.mathnotes-ressource.json',
                     encoding='utf-8'))
BRUT = json.dumps(RES, ensure_ascii=False, indent=1)

with open_app() as page:
    page.on('dialog', lambda d: d.accept())
    msgs = []
    page.expose_function('__t', lambda m: msgs.append(m))
    page.evaluate("() => { const o=showToast; showToast=m=>{window.__t(m);o(m);}; }")

    def ouvre(txt):
        msgs.clear()
        # on emprunte exactement le chemin de « 📂 Ouvrir »
        page.evaluate("""(txt) => {
          closeM('m-atelier');
          const lu=mnrLireJSON(txt);
          if(!lu.o){showToast('Fichier illisible : ce n\\u2019est pas du JSON.');return;}
          ouvrirFichierJSON(lu.o,'essai.json');
        }""", txt)
        page.wait_for_timeout(500)
        return page.evaluate("() => ({"
                             " atelier: document.getElementById('m-atelier').classList.contains('on'),"
                             " onglet: [1,2,3].find(i=>document.getElementById('at-p'+i).style.display!=='none'),"
                             " pret: !document.getElementById('at-go').disabled })")

    print('\n── 1. UNE RESSOURCE OUVERTE PAR « 📂 OUVRIR » ──')
    e = ouvre(BRUT)
    t('l\'atelier s\'ouvre tout seul', e['atelier'])
    t('sur l\'onglet d\'import', e['onglet'] == 2, e['onglet'])
    t('le contrôle est déjà passé, le bouton est actif', e['pret'])
    t('le message explique ce qui se passe',
      any('ressource' in m for m in msgs), msgs)
    t('aucun refus', not any('pas un projet' in m or 'non reconnu' in m for m in msgs), msgs)

    print('\n── 2. LES HABITUDES DES ASSISTANTS ──')
    for nom, txt in [
        ('entourée de ```json', '```json\n' + BRUT + '\n```'),
        ('précédée d\'une phrase', 'Voici le fichier demandé :\n\n' + BRUT),
        ('suivie d\'une phrase', BRUT + '\n\nDis-moi si tu veux des ajustements.'),
        ('avec un BOM', '﻿' + BRUT),
        ('avec une virgule en trop', BRUT.replace('"duree": 55', '"duree": 55,')),
        ('avec une virgule en trop dans une liste',
         BRUT.replace('"s1m1-9"', '"s1m1-9",')),
        ('sans étiquette « format »',
         json.dumps({k: v for k, v in RES.items() if k != 'format'}, ensure_ascii=False)),
    ]:
        e = ouvre(txt)
        t(nom + ' : acceptée', e['atelier'] and e['onglet'] == 2 and e['pret'],
          (e, msgs[:1]))

    print('\n── 2 bis. UN PROJET N\'EST JAMAIS ABÎMÉ PAR LA RÉPARATION ──')
    piege = {"format": "mathnotes-project", "version": 3, "title": "Piège",
             "html": "<p>Un texte avec une accolade, } et une virgule.</p>", "sheets": {}}
    e = ouvre(json.dumps(piege, ensure_ascii=False))
    t('le projet s\'ouvre', not e['atelier'])
    t('son HTML est intact au caractère près',
      page.evaluate("() => ED.innerHTML").find('accolade, } et une virgule') >= 0,
      page.evaluate("() => ED.innerHTML")[:120])

    print('\n── 3. L\'ÉTIQUETTE MANQUANTE EST SIGNALÉE SANS BLOQUER ──')
    page.evaluate("""(o) => {
      openAtelier();atelierTab(2);
      document.getElementById('at-json').value=JSON.stringify(o);
      mnrControler();
    }""", {k: v for k, v in RES.items() if k != 'format'})
    page.wait_for_timeout(400)
    rap = page.evaluate("() => document.getElementById('at-rap').textContent")
    t('un avertissement le dit', 'étiquette' in rap, rap[:110])
    page.evaluate("""(txt) => {
      document.getElementById('at-json').value=txt;mnrControler();
    }""", BRUT.replace('"duree": 55', '"duree": 55,'))
    page.wait_for_timeout(300)
    t('la virgule retirée est signalée',
      'virgule en trop' in page.evaluate("() => document.getElementById('at-rap').textContent"),
      page.evaluate("() => document.getElementById('at-rap').textContent")[:130])
    t('mais l\'import reste possible',
      not page.evaluate("() => document.getElementById('at-go').disabled"))

    print('\n── 4. CHAQUE FICHIER VA AU BON ENDROIT ──')
    e = ouvre(json.dumps({"format": "mathnotes-project", "version": 3, "title": "Essai",
                          "html": "<h1>Un cours</h1><p>Du texte.</p>", "sheets": {}},
                         ensure_ascii=False))
    t('un projet s\'ouvre dans l\'éditeur, pas dans l\'atelier', not e['atelier'])
    t('son contenu est en place',
      'Un cours' in page.evaluate("() => ED.textContent"))
    t('son titre aussi',
      page.evaluate("() => document.getElementById('doc-title').textContent") == 'Essai')

    prog = page.evaluate("() => JSON.parse(JSON.stringify(REF_DEFAUT))")
    prog['niveaux'] = prog['niveaux'][:2]
    e = ouvre(json.dumps(prog, ensure_ascii=False))
    t('un programme va dans l\'onglet Programme', e['atelier'] and e['onglet'] == 3, e)
    t('il est bien chargé', page.evaluate("() => refNiveaux().length") == 2,
      page.evaluate("() => refNiveaux().length"))
    page.evaluate("() => refRetablir()")
    page.wait_for_timeout(300)
    t('le programme fourni se rétablit', page.evaluate("() => refNiveaux().length") == 6)

    print('\n── 5. UN FICHIER ÉTRANGER EST REFUSÉ CLAIREMENT ──')
    e = ouvre('{"bidule": 12, "machin": [1,2,3]}')
    t('rien ne s\'ouvre', not e['atelier'])
    bulle = page.evaluate("() => { const e=document.querySelector('#toast,.toast');"
                          " return e ? e.textContent : ''; }")
    t('le message dit quoi faire', 'non reconnu' in bulle, bulle[:90])
    t('il propose d\'aller à l\'atelier', 'Atelier' in bulle, bulle[:90])
    msgs.clear()
    page.evaluate("""() => {
      const lu=mnrLireJSON('ceci nest pas du json');
      if(!lu.o){showToast('Fichier illisible : ce n\\u2019est pas du JSON.');return;}
      ouvrirFichierJSON(lu.o,'x.json');
    }""")
    page.wait_for_timeout(300)
    t('un texte illisible le dit', any('illisible' in m for m in msgs), msgs)

    print('\n── 6. LE CONTRÔLE ORIENTE AU LIEU DE REFUSER SÈCHEMENT ──')
    for nom, obj, motif in [
        ('un projet collé dans l\'atelier',
         {"format": "mathnotes-project", "html": "<p>x</p>"}, 'Ouvrir'),
        ('un programme collé dans l\'atelier',
         {"format": "mathnotes-programme", "niveaux": []}, 'Programme'),
    ]:
        page.evaluate("""(o) => {
          openAtelier();atelierTab(2);
          document.getElementById('at-json').value=JSON.stringify(o);
          mnrControler();
        }""", obj)
        page.wait_for_timeout(300)
        rap = page.evaluate("() => document.getElementById('at-rap').textContent")
        t(nom + ' : renvoyé au bon endroit', motif in rap, rap[:120])

    print('\n── 7. LA RESSOURCE PEUT ÊTRE GARDÉE EN FICHIER ──')
    page.evaluate("""(txt) => {
      openAtelier();atelierTab(2);
      document.getElementById('at-json').value=txt;mnrControler();
    }""", BRUT)
    page.wait_for_timeout(400)
    t('le bouton d\'enregistrement s\'active',
      not page.evaluate("() => document.getElementById('at-dl').disabled"))
    with page.expect_download() as dl:
        page.evaluate("() => mnrEnregistrerRessource()")
    d = dl.value
    t('le nom du fichier est parlant',
      d.suggested_filename.endswith('.mathnotes-ressource.json'), d.suggested_filename)
    chemin = d.path()
    relu = json.load(open(chemin, encoding='utf-8'))
    t('le fichier enregistré est complet',
      relu['format'] == 'mathnotes-ressource' and len(relu['ressources']) == len(RES['ressources']))
    t('il se réouvre sans broncher',
      page.evaluate("(o) => mnrAudit(o).filter(x=>x.n==='err').length", relu) == 0)

    print('\n── 8. LE PROMPT EXIGE UN FICHIER TÉLÉCHARGEABLE ──')
    pr = page.evaluate("() => { atelierTab(1); mnrMajPrompt();"
                       " return document.getElementById('at-prompt').value; }")
    t('il demande un fichier', 'FICHIER JSON TÉLÉCHARGEABLE' in pr)
    t('il donne le nom attendu', 'ressource.mathnotes-ressource.json' in pr)
    t('il prévoit le repli en texte brut', 'Si tu ne peux pas joindre de fichier' in pr)

    print('\n── 9. L\'IMPORT VA JUSQU\'AU DOCUMENT ──')
    n_av = page.evaluate("() => LIB.docs.length")
    page.evaluate("""(txt) => {
      openAtelier();atelierTab(2);
      document.getElementById('at-json').value=txt;mnrControler();
    }""", '```json\n' + BRUT + '\n```')
    page.wait_for_timeout(400)
    page.evaluate("() => mnrImporter()")
    page.wait_for_timeout(3000)
    t('un cours est créé', page.evaluate("() => LIB.docs.length") == n_av + 1)
    t('il est dessiné',
      page.evaluate("() => ED.querySelectorAll('.exo-block').length") >= 4)
    t('et paginé', page.evaluate("() => pgInfo.pages") >= 8,
      page.evaluate("() => pgInfo.pages"))

    print('\nerreurs de console :', page.errors[:3] or 'aucune')
    t('aucune erreur de console', not page.errors, page.errors[:2])

print('\n%d PASS / %d FAIL' % (ok, ko))
raise SystemExit(1 if ko else 0)
