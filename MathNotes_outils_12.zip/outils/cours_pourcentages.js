/* Construction du cours de démonstration.
   Tout passe par les fabriques de l'application (makeCZone, mkMD, mkMX,
   compHTML, qcmQuestionHTML…) : le HTML produit est donc exactement celui
   qu'obtiendrait un professeur en cliquant dans le ruban. */
(() => {

const E = (t, cls, html) => {
  const n = document.createElement(t);
  if (cls) n.className = cls;
  if (html !== undefined) n.innerHTML = html;
  return n;
};
const add = n => { ED.appendChild(n); return n; };
ED.innerHTML = '';   /* on repart d'une feuille vraiment vierge */

/* mini-balisage : **gras**, $latex$ en ligne, {app} … {com} pastille nommée,
   [app] … [com] pastille seule */
function rich(s) {
  let out = '';
  let rest = String(s);
  const re = /(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\$[^$]+\$)|(\{(?:app|rai|rea|val|com)\})|(\[(?:app|rai|rea|val|com)\])/;
  let m;
  while ((m = re.exec(rest))) {
    out += esc(rest.slice(0, m.index));
    const tok = m[0];
    if (tok.startsWith('**')) out += '<strong>' + esc(tok.slice(2, -2)) + '</strong>';
    else if (tok.startsWith('*')) out += '<em>' + esc(tok.slice(1, -1)) + '</em>';
    else if (tok.startsWith('$')) {
      const el = mkMX(sanitizeLatex(tok.slice(1, -1)));
      out += el.outerHTML;
    } else {
      const k = tok.slice(1, -1);
      out += compHTML(COMPETENCES.find(c => c.k === k), tok.startsWith('{'));
    }
    rest = rest.slice(m.index + tok.length);
  }
  return out + esc(rest);
}

const P = s => add(E('p', null, rich(s)));
const H = (n, s) => add(E('h' + n, null, rich(s)));

function callout(type, icon, label, txt) {
  const div = E('div', 'callout c-' + type);
  div.setAttribute('contenteditable', 'false');
  div.innerHTML = '<span class="callout-icon" contenteditable="false">' + icon + '</span>'
    + '<div class="callout-body" contenteditable="true"><strong>' + label + '</strong> — '
    + rich(txt) + '</div>';
  return add(div);
}

function zone(color, lignes) {
  const z = makeCZone(lignes.map(l => '<div>' + rich(l) + '</div>').join(''), color);
  return add(z);
}

function formule(latex, titre) {
  const md = mkMD(sanitizeLatex(latex), titre || '');
  renderMathEl(md);
  return add(md);
}

function table(lignes, entete) {
  const cols = lignes[0].length;
  const t = E('table', 'mn-table');
  const cg = document.createElement('colgroup');
  for (let j = 0; j < cols; j++) {
    const c = document.createElement('col');
    c.style.width = (100 / cols).toFixed(3) + '%';
    cg.appendChild(c);
  }
  t.appendChild(cg);
  const tb = document.createElement('tbody');
  lignes.forEach((ln, i) => {
    const tr = document.createElement('tr');
    ln.forEach(cell => {
      const td = document.createElement(i === 0 && entete ? 'th' : 'td');
      td.innerHTML = rich(cell) || '<br>';
      tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
  t.appendChild(tb);
  return add(t);
}

function sautDePage() {
  const br = E('div', 'pg-manual');
  br.setAttribute('contenteditable', 'false');
  return add(br);
}

/* ══════════════════════════════════════════════════════════
   1. LE COURS
══════════════════════════════════════════════════════════ */
H(1, 'Pourcentages et coefficients multiplicateurs');
P('**2de Bac Pro — Chapitre 3.** Ce chapitre sert dans tous les ateliers : facturation, devis, remises, TVA, suivi de consommation.');

H(2, '1. Proportion et pourcentage');
callout('def', '📘', 'Définition',
  "Dans une population de $N$ individus, une partie de $n$ individus représente la **proportion** $p$. Multipliée par 100, cette proportion s'écrit en **pourcentage**.");
formule('p = \\frac{n}{N} = \\frac{\\text{effectif partiel}}{\\text{effectif total}}');
callout('meth', '🛠️', 'Méthode',
  "Pour appliquer un pourcentage à une quantité, on multiplie cette quantité par le taux divisé par 100.");
formule('p\\,\\% \\text{ de } N = \\frac{p}{100} \\times N');
zone('green', [
  '**Exemple** — Dans un atelier de 25 apprentis, 15 préparent un CAP Maintenance des véhicules.',
  'Proportion : $\\frac{15}{25} = 0{,}6$, soit **60 %** de l\'effectif.',
  'Les 10 autres représentent $\\frac{10}{25} = 0{,}4$, soit **40 %**.',
]);

H(2, "2. Le taux d'évolution");
callout('def', '📘', 'Définition',
  "Une grandeur passe d'une valeur initiale $V_i$ à une valeur finale $V_f$. Le **taux d'évolution** $t$, exprimé en pourcentage, mesure cette variation par rapport à la valeur de départ.");
formule('t = \\frac{V_f - V_i}{V_i} \\times 100');
zone('blue', [
  "**Exemple** — Le prix d'un scooter d'occasion passe de 1 250 € à 1 100 €.",
  '$t = \\frac{1100 - 1250}{1250} \\times 100 = \\frac{-150}{1250} \\times 100 = -12$',
  'Le prix a donc **baissé de 12 %**.',
]);
callout('warn', '⚠️', 'Attention',
  "Le taux se calcule toujours sur la **valeur de départ**. Diviser par la valeur d'arrivée est l'erreur la plus fréquente.");

H(2, '3. Le coefficient multiplicateur');
callout('thm', '📐', 'Propriété',
  "Appliquer une évolution de $t$ %, c'est multiplier par un nombre appelé **coefficient multiplicateur**, noté $CM$.");
formule('CM = 1 + \\frac{t}{100} \\\\ V_f = V_i \\times CM', 'Coefficient multiplicateur');
table([
  ['Évolution', 'Calcul du CM', 'CM', 'Lecture'],
  ['+ 20 %', '$1 + \\frac{20}{100}$', '1,20', 'hausse'],
  ['+ 5,5 %', '$1 + \\frac{5{,}5}{100}$', '1,055', 'hausse'],
  ['− 30 %', '$1 - \\frac{30}{100}$', '0,70', 'baisse'],
  ['− 12 %', '$1 - \\frac{12}{100}$', '0,88', 'baisse'],
], true);
P('Un coefficient **supérieur à 1** traduit une hausse, **inférieur à 1** une baisse, **égal à 1** aucune variation.');

H(2, '4. Évolutions successives');
callout('thm', '📐', 'Propriété',
  'Deux évolutions qui se suivent se traduisent par le **produit** de leurs coefficients multiplicateurs. Les taux, eux, ne s\'additionnent pas.');
formule('CM_{\\text{global}} = CM_1 \\times CM_2');
callout('warn', '⚠️', 'Attention',
  'Une hausse de 20 % suivie d\'une baisse de 20 % ne ramène pas au prix de départ : $1{,}20 \\times 0{,}80 = 0{,}96$, soit une **baisse de 4 %**.');
zone('purple', [
  '**Exemple** — Un blouson affiché 80 € subit une première démarque de −30 %, puis une seconde de −20 % supplémentaires.',
  '$CM_1 = 0{,}70$ et $CM_2 = 0{,}80$, donc $CM_{\\text{global}} = 0{,}70 \\times 0{,}80 = 0{,}56$.',
  'Le taux global vaut $0{,}56 - 1 = -0{,}44$, soit **−44 %** (et non −50 %).',
  'Prix final : $80 \\times 0{,}56 = 44{,}80$ €.',
]);

H(2, "5. Deux applications de l'atelier");
callout('meth', '🛠️', 'TVA',
  "Le prix toutes taxes comprises s'obtient en appliquant le taux de TVA au prix hors taxes.");
formule('P_{TTC} = P_{HT} \\times \\left(1 + \\frac{t_{TVA}}{100}\\right)');
table([
  ['Taux de TVA', 'Ce qu’il concerne', 'CM'],
  ['20 %', 'taux normal : pièces, main-d’œuvre', '1,20'],
  ['10 %', 'travaux de rénovation d’un logement', '1,10'],
  ['5,5 %', 'travaux d’amélioration énergétique', '1,055'],
  ['2,1 %', 'médicaments remboursables', '1,021'],
], true);
zone('orange', [
  '**🔧 Situation professionnelle — Garage** Un devis de réparation comprend 340 € HT de main-d’œuvre et 185 € HT de pièces. Le taux de TVA applicable est le taux normal, 20 %.',
  'Total hors taxes : $340 + 185 = 525$ €.',
  'Total toutes taxes : $525 \\times 1{,}20 = 630$ €.',
  'Le montant de la TVA facturée est donc $630 - 525 = 105$ €.',
]);
callout('meth', '🛠️', 'Retrouver le prix hors taxes',
  "L'opération inverse d'une multiplication par $CM$ est une **division** par $CM$ : $P_{HT} = P_{TTC} \\div 1{,}20$. Retirer 20 % du prix TTC donnerait un résultat faux.");

/* ══════════════════════════════════════════════════════════
   2. ÉVALUATION PAR COMPÉTENCES
══════════════════════════════════════════════════════════ */
sautDePage();
H(1, 'Évaluation par compétences — Les pourcentages');
P('Nom : …………………………………  Classe : ……………  Date : ……………  **Durée : 45 min.** Calculatrice autorisée.');
P("Chaque question porte la **compétence évaluée**. La grille de la dernière page est remplie par l'enseignant.");

zone('grey', [
  '**📋 Contexte — Magasin de pièces détachées « Méca-Pro »**',
  'Le magasin vend des plaquettes de frein au prix de **48 € HT** l’unité. Il en a vendu **250** en mars et **290** en avril. Le taux de TVA appliqué est le **taux normal, 20 %**.',
  'Pour la Semaine de la mécanique, le gérant décide d’une **remise de 15 %** sur le prix hors taxes.',
]);

P('{app} **Question 1.** Relever, dans le contexte ci-dessus, le prix hors taxes d’une plaquette et le nombre de plaquettes vendues en mars. *(2 points)*');
P('{rea} **Question 2.** Calculer le prix TTC d’une plaquette, au taux normal de 20 %. *(3 points)*');
P('{rea} **Question 3.** Calculer le taux d’évolution du nombre de plaquettes vendues entre mars et avril. Arrondir à 0,1 %. *(4 points)*');
P('{rai} **Question 4.** Le gérant affirme : « une remise de 15 %, puis 10 % de plus sur le reste, cela revient à 25 % de remise ». A-t-il raison ? Justifier par le calcul du coefficient multiplicateur global. *(4 points)*');
P('{val} **Question 5.** Un client annonce payer **40 € TTC** une plaquette remisée de 15 %. Ce montant est-il vraisemblable ? Justifier. *(4 points)*');
P('{com} **Question 6.** Rédiger en trois lignes, à l’intention d’un client, l’explication de la remise de 15 % appliquée au prix hors taxes puis de la TVA à 20 %. *(3 points)*');

P('**Grille d’évaluation**');
table([
  ['Compétence', 'Ce qui est attendu', 'Question', 'Niveau atteint'],
  ['{app}', 'Extraire l’information utile de l’énoncé', '1', '1   2   3   4'],
  ['{rea}', 'Mener à bien un calcul de pourcentage', '2 et 3', '1   2   3   4'],
  ['{rai}', 'Choisir une démarche, enchaîner deux évolutions', '4', '1   2   3   4'],
  ['{val}', 'Contrôler la vraisemblance d’un résultat', '5', '1   2   3   4'],
  ['{com}', 'Expliquer une démarche par écrit', '6', '1   2   3   4'],
], true);

/* ══════════════════════════════════════════════════════════
   3. LE QCM
══════════════════════════════════════════════════════════ */
sautDePage();
H(1, 'QCM — Coefficients multiplicateurs et pourcentages');
P('Cochez la ou les bonnes réponses. Le symbole ◯ signale une seule bonne réponse, ☐ plusieurs.');

const QUESTIONS = [
  { c: 'app', multi: false,
    q: 'Un article coûte 60 €. Son prix augmente de 15 %. Quel est le coefficient multiplicateur ?',
    r: ['0,15', '1,15', '15', '1,015'], ok: [1],
    corr: 'Une hausse de $t$ % correspond à $CM = 1 + \\frac{t}{100} = 1 + 0{,}15 = 1{,}15$.' },
  { c: 'rea', multi: false,
    q: 'Le prix d’une pièce passe de 60 € à 69 €. Quel est le taux d’évolution ?',
    r: ['+ 9 %', '+ 13 %', '+ 15 %', '+ 90 %'], ok: [2],
    corr: '$t = \\frac{69 - 60}{60} \\times 100 = \\frac{9}{60} \\times 100 = 15$. Le prix a augmenté de 15 %.' },
  { c: 'rai', multi: false,
    q: 'Quel coefficient multiplicateur correspond à une baisse de 30 % ?',
    r: ['0,30', '0,70', '1,30', '− 0,30'], ok: [1],
    corr: 'Une baisse de 30 % donne $CM = 1 - \\frac{30}{100} = 0{,}70$. Un coefficient est toujours positif.' },
  { c: 'rea', multi: true,
    q: 'Parmi ces coefficients multiplicateurs, lesquels traduisent une hausse ?',
    r: ['1,04', '0,96', '2,5', '0,995'], ok: [0, 2],
    corr: 'Un coefficient strictement supérieur à 1 traduit une hausse : 1,04 correspond à + 4 % et 2,5 à + 150 %. Les deux autres sont inférieurs à 1, donc des baisses.' },
  { c: 'rai', multi: false,
    q: 'Une hausse de 25 % suivie d’une baisse de 25 % correspond à :',
    r: ['aucune variation', 'une baisse de 6,25 %', 'une hausse de 6,25 %', 'une baisse de 50 %'], ok: [1],
    corr: '$1{,}25 \\times 0{,}75 = 0{,}9375$. Le coefficient global est inférieur à 1 : c’est une baisse de 6,25 %. Les taux ne s’additionnent jamais.' },
  { c: 'val', multi: false,
    q: 'Une facture de 300 € TTC a été établie au taux de TVA de 20 %. Pour retrouver le prix hors taxes, il faut :',
    r: ['retirer 20 % de 300 €', 'diviser 300 par 1,20', 'multiplier 300 par 0,80', 'retirer 60 € à 300 €'], ok: [1],
    corr: 'L’opération inverse d’une multiplication par 1,20 est une division par 1,20 : $300 \\div 1{,}20 = 250$ €. Retirer 20 % donnerait 240 €, ce qui est faux : on vérifie que $250 \\times 1{,}20 = 300$.' },
];

const blk = E('div', 'qcm-block');
blk.setAttribute('contenteditable', 'false');
blk.dataset.id = 'qcm-demo-pourcentages';
blk.dataset.corr = '1';
blk.innerHTML =
  '<div class="qcm-head" contenteditable="false">'
  + '<div class="qcm-head-left">'
  + '<span class="qcm-emoji" contenteditable="false">☑️</span>'
  + '<span class="qcm-label" contenteditable="true" spellcheck="false" title="Cliquez pour renommer le QCM">QCM 1 — Coefficients multiplicateurs</span>'
  + '</div>'
  + '<div class="qcm-head-right">'
  + '<button class="qcm-btn" onclick="qcmAddQ(this)" title="Ajouter une question">＋ Question</button>'
  + '<button class="qcm-btn" onclick="qcmDelLastQ(this)" title="Retirer la dernière question">－ Question</button>'
  + '<button class="qcm-btn qcm-corr-btn" onclick="qcmToggleCorr(this)"></button>'
  + '<button class="qcm-btn qcm-trash" onclick="qcmAskDelete(this)" title="Supprimer tout le QCM">🗑</button>'
  + '</div></div>'
  + '<div class="qcm-body">'
  + QUESTIONS.map(x => qcmQuestionHTML(x.r.length, x.multi)).join('')
  + '</div>'
  + '<div class="qcm-corr-wrap" contenteditable="false">'
  + '<button class="qcm-corr-toggle" onclick="toggleQcmCorr(this)">▸ Commentaire général du QCM</button>'
  + '<div class="qcm-corr-body" contenteditable="true" style="display:none;"></div>'
  + '</div>';
add(blk);

[...blk.querySelectorAll('.qcm-q')].forEach((q, i) => {
  const d = QUESTIONS[i];
  q.querySelector('.qcm-q-text').innerHTML = rich('[' + d.c + '] ' + d.q);
  [...q.querySelectorAll('.qcm-a')].forEach((a, j) => {
    a.querySelector('.qcm-cell').innerHTML = rich(d.r[j]);
    a.dataset.ok = d.ok.indexOf(j) >= 0 ? '1' : '0';
  });
  q.querySelector('.qcm-q-corr-wrap').style.display = '';
  q.querySelector('.qcm-q-corr').innerHTML = rich(d.corr);
});
blk.querySelector('.qcm-corr-body').innerHTML = rich(
  'Retenir : un coefficient multiplicateur est **toujours positif**. Au-dessus de 1 il traduit une hausse, en dessous une baisse. Deux évolutions successives se **multiplient**, elles ne s’additionnent pas.');
blk.querySelector('.qcm-corr-body').style.display = '';
blk.querySelector('.qcm-corr-toggle').textContent = '▾ Commentaire général du QCM';
qcmRenumber(blk); qcmSyncCorrBtn(blk); bindQcm(blk);

/* ══════════════════════════════════════════════════════════
   4. EXERCICES CORRIGÉS
══════════════════════════════════════════════════════════ */
sautDePage();
H(1, 'Feuille d’exercices corrigés');
P('Chaque correction se replie et se déplie avec le bouton **▸ Afficher la correction**. À l’impression, choisissez la version élève pour la masquer.');

function exercice(titre, enonce, correction) {
  const div = E('div', 'exo-block');
  div.setAttribute('contenteditable', 'false');
  div.dataset.id = 'exo-' + titre.replace(/\W+/g, '-').toLowerCase();
  div.dataset.validated = '1';
  div.innerHTML =
    '<div class="exo-head" contenteditable="false">'
    + '<div class="exo-head-left">'
    + '<span class="exo-emoji" contenteditable="false">📝</span>'
    + '<span class="exo-label" contenteditable="true" spellcheck="false" title="Cliquez pour renommer l\'exercice">' + esc(titre) + '</span>'
    + '<span class="exo-badge done">✓ Validé</span>'
    + '</div>'
    + '<div class="exo-head-right">'
    + '<button class="exo-btn exo-modify" onclick="validateExo(this)">✎ Modifier</button>'
    + '</div></div>'
    + '<div class="exo-body" contenteditable="false">'
    + enonce.map(l => '<div>' + rich(l) + '</div>').join('')
    + '</div>'
    + '<div class="exo-corr-wrap" contenteditable="false">'
    + '<button class="exo-corr-toggle" onclick="toggleCorr(this)">▸ Afficher la correction</button>'
    + '<div class="exo-corr-body" contenteditable="true" style="display:none;">'
    + correction.map(l => '<div>' + rich(l) + '</div>').join('')
    + '</div></div>';
  return add(div);
}

exercice('Exercice 1 — Appliquer une remise', [
  'Un lot de 40 cartouches d’encre est facturé **148 € HT**. Le fournisseur accorde une **remise de 12 %** sur ce montant.',
  '**1.** Calculer le montant de la remise.',
  '**2.** En déduire le prix payé, par deux méthodes différentes.',
], [
  '**1.** Montant de la remise : $\\frac{12}{100} \\times 148 = 17{,}76$ €.',
  '**2.** Première méthode — on retire la remise : $148 - 17{,}76 = 130{,}24$ €.',
  'Seconde méthode — on multiplie par le coefficient : $CM = 1 - \\frac{12}{100} = 0{,}88$, donc $148 \\times 0{,}88 = 130{,}24$ €.',
  'Les deux méthodes donnent le même résultat : **130,24 €**.',
]);

exercice('Exercice 2 — Calculer un taux d’évolution', [
  'La consommation électrique d’un atelier était de **1 840 kWh** en janvier et de **1 564 kWh** en février.',
  '**1.** Calculer le taux d’évolution de la consommation entre janvier et février.',
  '**2.** Interpréter le résultat en une phrase.',
], [
  '**1.** $t = \\frac{1564 - 1840}{1840} \\times 100 = \\frac{-276}{1840} \\times 100 = -15$.',
  '**2.** La consommation de l’atelier a **baissé de 15 %** entre janvier et février.',
  'Vérification : $1840 \\times 0{,}85 = 1564$ kWh. ✔',
]);

exercice('Exercice 3 — Deux évolutions qui se suivent', [
  'Une pièce détachée valait **62 €** fin 2023. Son prix a augmenté de **8 %** en 2024, puis de **5 %** en 2025.',
  '**1.** Donner le coefficient multiplicateur de chaque année.',
  '**2.** En déduire le coefficient global, puis le taux global arrondi à 0,1 %.',
  '**3.** Calculer le prix de la pièce fin 2025, arrondi au centime.',
], [
  '**1.** $CM_1 = 1 + \\frac{8}{100} = 1{,}08$ et $CM_2 = 1 + \\frac{5}{100} = 1{,}05$.',
  '**2.** $CM_{\\text{global}} = 1{,}08 \\times 1{,}05 = 1{,}134$, soit un taux global de $1{,}134 - 1 = 0{,}134$ : **+ 13,4 %**.',
  'Attention : ce n’est pas 8 + 5 = 13 %, car la seconde hausse porte sur un prix déjà augmenté.',
  '**3.** $62 \\times 1{,}134 = 70{,}308$, soit **70,31 €** arrondi au centime.',
]);

exercice('Exercice 4 — Facturation TTC et HT', [
  '**🔧 Situation professionnelle.** Un artisan facture une intervention **468 € TTC**. Le taux de TVA appliqué est le **taux normal, 20 %**.',
  '**1.** Calculer le prix hors taxes de l’intervention.',
  '**2.** En déduire le montant de la TVA facturée.',
  '**3.** Pour une autre intervention, l’artisan veut un prix hors taxes de **420 €**. Quel montant TTC doit-il annoncer au client ?',
], [
  '**1.** Le prix TTC s’obtient en multipliant le prix HT par 1,20. On effectue donc l’opération inverse : $468 \\div 1{,}20 = 390$ €.',
  '**2.** Montant de la TVA : $468 - 390 = 78$ €. On vérifie : $\\frac{20}{100} \\times 390 = 78$ €. ✔',
  '**3.** $420 \\times 1{,}20 = 504$ €. L’artisan annonce **504 € TTC**.',
]);

P('Fin du document.');

reattach();
tableColumnsAsPercent();
paginate();
return ED.querySelectorAll('.qcm-q').length;
})();
