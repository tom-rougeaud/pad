# Outils de MathNotes

Chaîne de fabrication et batterie de tests. Voir `MathNotes_DOSSIER_TECHNIQUE.md`
pour le mode d'emploi complet.

## Installation

```bash
npm install katex@0.16.9 @fontsource/dm-sans @fontsource/dm-mono @fontsource/lora
pip install playwright beautifulsoup4
```

Placer `MathNotes_source.html` (ou `MathNotes.html`) dans ce dossier.

## Fabrication

```bash
python3 build.py source MathNotes.html MathNotes_source.html   # version éditable, 0,52 Mo
python3 build.py dist   MathNotes_source.html MathNotes.html   # version publiable, 1,13 Mo
```

L'aller-retour doit rendre un fichier **identique à l'octet près** :

```bash
python3 build.py source MathNotes.html /tmp/s.html \
  && python3 build.py dist /tmp/s.html /tmp/d.html && cmp MathNotes.html /tmp/d.html
```

## Catalogue de modèles

```bash
# éditer tpl_a.py / tpl_b.py, puis :
python3 gen_tpls.py && python3 catalog_test.py && python3 exc_audit.py
```

## Relecture du JavaScript

À faire après chaque modification, avant les tests :

```bash
python3 extract_js.py \
  && node --check _app.js \
  && npx eslint --no-eslintrc -c .eslintrc.json _app.js \
  && python3 check_calls.py
```

## Tests — 354 vérifications

```bash
for t in catalog_test exc_audit ex_test qcm_test qcm2_test regress_test \
         pdf_test qcm_pdf_test lib_test img2_test safety_test offline_test \
         tablet_test idb_test leak_test fmt_test comp_test pg_test print_audit; do
  printf '%-16s ' $t; python3 $t.py 2>&1 | tail -1
done
```

Les tests s'exécutent sur `MathNotes.html`. Pour tester la version source,
lancer d'abord `python3 build.py dist MathNotes_source.html MathNotes.html`.

`pg_test.py` et `pdf_test.py` produisent des PDF et ont besoin de `pdfinfo`
et `pdftotext` (paquet `poppler-utils`).

## Documents dérivés

```bash
python3 build_guide.py && python3 guide_pdf.py   # guide complet, tiré du Tuto de l'application
python3 pres_pdf.py                              # présentation 2 pages, tirée de presentation.html
```
