# -*- coding: utf-8 -*-
"""Détecte les appels à des fonctions qui n'existent pas
(dans le JS du fichier et dans les attributs onclick/oninput… du HTML)."""
import re, sys

src = open('MathNotes.html', encoding='utf-8').read()

defined = set(re.findall(r'\bfunction\s+([A-Za-z_$][\w$]*)\s*\(', src))
defined |= set(re.findall(r'\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:function|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)', src))

BUILTIN = set("""
alert atob btoa confirm prompt parseInt parseFloat isNaN isFinite encodeURIComponent
decodeURIComponent encodeURI decodeURI setTimeout setInterval clearTimeout clearInterval
requestAnimationFrame String Number Boolean Array Object Math JSON Date RegExp Map Set
Promise Error TypeError URL Blob FileReader Image FormData Intl Symbol WeakMap
katex renderMathInElement print focus blur open close scroll fetch structuredClone
queueMicrotask getComputedStyle matchMedia navigator localStorage document window
""".split())

calls = set()
for m in re.finditer(r'(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(', src):
    calls.add(m.group(1))

HTML_KEYWORDS = set(['if','for','while','return','typeof','function'])
KEYWORDS = set("""if for while switch catch return typeof new delete void in of do else
function class try finally throw case with yield await instanceof""".split())

missing = sorted(c for c in calls if c not in defined and c not in BUILTIN and c not in KEYWORDS)

# attributs HTML : onclick="maFonction(...)"
html_calls = set(re.findall(r'on\w+="\s*([A-Za-z_$][\w$]*)\s*\(', src))
missing_html = sorted(c for c in html_calls if c not in defined and c not in BUILTIN and c not in HTML_KEYWORDS)

if missing_html:
    print('FAIL — attributs HTML appelant une fonction inexistante :')
    for c in missing_html:
        print('   ', c)
    sys.exit(1)
print('PASS — les %d fonctions appelées depuis le HTML existent toutes' % len(html_calls))
print('(fonctions définies : %d)' % len(defined))
