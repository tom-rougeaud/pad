# -*- coding: utf-8 -*-
"""L'application et ses exports fonctionnent sans le moindre accès réseau."""
import pathlib, tempfile, re
from playwright.sync_api import sync_playwright
CHROME='/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:200])

def offline(app):
    """Aucun accès réseau : seul le fichier local est servi."""
    pw=sync_playwright().start()
    b=pw.chromium.launch(executable_path=CHROME,args=['--no-sandbox'])
    ctx=b.new_context(viewport={'width':1400,'height':900})
    page=ctx.new_page(); errs=[]
    page.on('pageerror',lambda e: errs.append(str(e)))
    blocked=[]
    def route(r,q):
        if q.url.startswith('file:'): r.continue_()
        else: blocked.append(q.url); r.abort()
    page.route('**/*',route)
    page.goto(pathlib.Path(app).resolve().as_uri()); page.wait_for_timeout(1400)
    page.errors=errs; page.blocked=blocked
    return pw,b,page

pw,b,page = offline('MathNotes.html')
chk('KaTeX chargé sans réseau',
    page.evaluate("() => typeof katex") != 'undefined'
    and page.evaluate("() => typeof katex.renderToString") == 'function')
chk('polices de KaTeX intégrées',
    page.evaluate("""() => document.getElementById('katex-style').textContent.includes('data:font/woff2')"""))
r = page.evaluate("""() => {
  const p=ED.querySelector('p')||ED;
  const r=document.createRange();r.selectNodeContents(p);r.collapse(false);
  const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();
  insMathInline('\\\\frac{a}{b}');
  const m=ED.querySelector('.mx');
  return {rendu: !!(m && m.querySelector('.katex')),
          police: getComputedStyle(m.querySelector('.katex')||m).fontFamily,
          brut: m ? m.textContent.trim() : ''};
}""")
chk('la formule est réellement rendue', r['rendu'], r['brut'])
chk('la police mathématique est appliquée', 'KaTeX' in r['police'], r['police'])
chk('le catalogue entier se rend hors ligne',
    page.evaluate("""() => { let bad=0;
      SC.forEach(c=>{ if(!c.l) return;
        try{ if(/katex-error/.test(katex.renderToString(sanitizeLatex(c.l),{throwOnError:false}))) bad++; }
        catch(e){ bad++; } });
      return bad; }""") == 0)
appels = [u for u in page.blocked if 'jsdelivr' in u or 'katex' in u]
chk('plus aucun appel au CDN de KaTeX', not appels, appels[:3])

# export produit hors ligne
html = page.evaluate("""() => {
  let out='';
  const a0=HTMLAnchorElement.prototype.click; HTMLAnchorElement.prototype.click=function(){};
  const OB=window.Blob; window.Blob=function(p,o){ out=p.join(''); return new OB(p,o); };
  try{ exportWeb(); } finally { window.Blob=OB; HTMLAnchorElement.prototype.click=a0; }
  return out;
}""")
chk('export : plus de lien vers le CDN', 'jsdelivr' not in html)
chk('export : polices KaTeX intégrées', 'data:font/woff2' in html)
print('    poids de l\'export : %d Ko' % (len(html.encode())/1024))
chk('aucune erreur JS', not page.errors, page.errors[:3])
tmp = pathlib.Path(tempfile.mkdtemp())/'export.html'
tmp.write_text(html, encoding='utf-8')
b.close(); pw.stop()

# la page exportée, elle aussi hors ligne
pw,b,page2 = offline(tmp)
chk('export : formule rendue sans réseau',
    page2.evaluate("""() => { const k=document.querySelector('.mn-sheet .katex');
      return !!k && getComputedStyle(k).fontFamily.includes('KaTeX'); }"""))
chk('export : aucune erreur JS', not page2.errors, page2.errors[:3])
b.close(); pw.stop()
print('\n%d PASS / %d FAIL' % (P,F))
