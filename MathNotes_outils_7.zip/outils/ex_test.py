# -*- coding: utf-8 -*-
"""Insertion des exemples : structure, rendu, éditabilité."""
from harness import open_app

P = F = 0
def chk(label, cond, extra=''):
    global P, F
    if cond: P += 1; print('PASS', label)
    else: F += 1; print('FAIL', label, extra)

with open_app() as page:
    # place le curseur dans l'éditeur
    page.evaluate("""() => {
      const p = ED.querySelector('p') || ED;
      const r = document.createRange(); r.selectNodeContents(p); r.collapse(false);
      const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
    }""")
    tpl = page.evaluate("() => TPLS['💶 Calculs commerciaux'].find(t => t.name === 'Taux de marge')")
    chk('modèle Taux de marge présent', bool(tpl))

    page.evaluate("""() => {
      const t = TPLS['💶 Calculs commerciaux'].find(x => x.name === 'Taux de marge');
      insertExample(t, 'simple');
    }""")
    page.wait_for_timeout(250)

    zones = page.evaluate("() => ED.querySelectorAll('.czone').length")
    chk('exemple inséré dans une zone colorée', zones == 1, zones)
    chk('zone orange', page.evaluate("() => ED.querySelector('.czone').dataset.cz") == 'orange')
    chk('corps éditable',
        page.evaluate("() => ED.querySelector('.czone-body').getAttribute('contenteditable')") == 'true')
    chk('titre de l\'exemple',
        'Exemple — Taux de marge' in page.evaluate("() => ED.querySelector('.czone-body').textContent"))
    chk('formule en bloc rendue',
        page.evaluate("() => { const m = ED.querySelector('.czone-body .md'); return !!m && !!m.querySelector('.katex'); }"))
    chk('formules en ligne rendues',
        page.evaluate("() => [...ED.querySelectorAll('.czone-body .mx')].every(m => m.querySelector('.katex'))"))
    chk('aucune formule vide',
        page.evaluate("() => [...ED.querySelectorAll('.czone-body .mx,.czone-body .md')].every(m => m.textContent.trim().length)"))

    # situation pro
    page.evaluate("""() => {
      const p = document.createElement('p'); p.innerHTML = '<br>'; ED.appendChild(p);
      const r = document.createRange(); r.selectNodeContents(p); r.collapse(true);
      const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
      const t = TPLS['🏦 Finance & paie'].find(x => x.name === 'Mensualité de crédit');
      insertExample(t, 'pro');
    }""")
    page.wait_for_timeout(250)
    chk('situation pro insérée', page.evaluate("() => ED.querySelectorAll('.czone').length") == 2)
    chk('zone turquoise',
        page.evaluate("() => [...ED.querySelectorAll('.czone')].some(z => z.dataset.cz === 'teal')"))
    chk('gras rendu',
        page.evaluate("() => [...ED.querySelectorAll('.czone-body strong')].some(s => s.textContent.includes('Achat'))"))

    # pas d'imbrication : depuis l'intérieur d'une zone, on insère du contenu simple
    page.evaluate("""() => {
      const body = ED.querySelector('.czone-body');
      const r = document.createRange(); r.selectNodeContents(body); r.collapse(false);
      const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
      insertExample(TPLS['Statistiques'].find(x => x.name === 'Fréquence'), 'simple');
    }""")
    page.wait_for_timeout(250)
    chk('aucune zone imbriquée',
        page.evaluate("() => ![...ED.querySelectorAll('.czone')].some(z => z.querySelector('.czone'))"))
    chk('toujours 2 zones', page.evaluate("() => ED.querySelectorAll('.czone').length") == 2)

    chk('aucune erreur JS', not page.errors, page.errors[:3])

print('\n%d PASS / %d FAIL' % (P, F))
