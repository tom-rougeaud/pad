# -*- coding: utf-8 -*-
"""Rend CHAQUE formule du catalogue (slash-commandes, modèles, exemples)
et échoue si l'une d'elles ne s'affiche pas correctement."""
from harness import open_app

JS = r"""
() => {
  const bad = [];
  const test = (where, latex) => {
    if (typeof latex !== 'string' || !latex.trim()) { bad.push([where, latex, 'vide']); return; }
    try {
      const html = katex.renderToString(sanitizeLatex(latex), {displayMode:false, throwOnError:true, strict:false});
      if (/katex-error/.test(html)) bad.push([where, latex, 'katex-error']);
      const tmp = document.createElement('div'); tmp.innerHTML = html;
      if (!tmp.textContent.trim()) bad.push([where, latex, 'rendu vide']);
    } catch (e) { bad.push([where, latex, String(e.message || e)]); }
  };
  SC.forEach(c => { if (c.l) test('/' + c.c, c.l); });
  Object.keys(TPLS).forEach(chap => TPLS[chap].forEach(t => {
    t.lls.forEach(l => test('modèle ' + chap + ' / ' + t.name, l));
    ['ex','exc'].forEach(k => (t[k] || []).forEach(line => {
      const s = String(line).trim();
      const m = s.match(/^\$\$([\s\S]+)\$\$$/);
      if (m) { test(k + ' ' + t.name, m[1]); return; }
      const parts = s.split('$');
      if (parts.length % 2 === 0) bad.push([k + ' ' + t.name, s, 'nombre impair de $']);
      parts.forEach((p, i) => { if (i % 2 === 1) test(k + ' ' + t.name, p); });
    }));
  }));
  return bad;
}
"""

COUNT = r"""
() => {
  let f = 0, ex = 0, chap = Object.keys(TPLS).length, tpl = 0;
  SC.forEach(c => { if (c.l) f++; });
  Object.keys(TPLS).forEach(c => TPLS[c].forEach(t => {
    tpl++; f += t.lls.length; ex += (t.ex ? 1 : 0) + (t.exc ? 1 : 0);
  }));
  return {chap, tpl, f, ex};
}
"""

with open_app() as page:
    bad = page.evaluate(JS)
    n = page.evaluate(COUNT)
    print('chapitres %(chap)d | modèles %(tpl)d | formules %(f)d | exemples %(ex)d' % n)
    if page.errors:
        print('ERREURS JS :', page.errors[:5])
    for b in bad:
        print('FAIL', b)
    print(('PASS — catalogue entièrement rendu' if not bad and not page.errors
           else 'FAIL — %d problème(s)' % (len(bad) + len(page.errors))))
