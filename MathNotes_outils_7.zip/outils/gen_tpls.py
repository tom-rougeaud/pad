# -*- coding: utf-8 -*-
"""Régénère le bloc TPLS (+ mots-clés de chapitres) dans MathNotes.html.
Tout est encodé en JSON : aucun antislash ne peut être mal échappé."""
import json, re, io, sys
import tpl_a, tpl_b

ORDER = [
    'Calcul numérique', 'Proportionnalité & %',
    '💶 Calculs commerciaux', '🏷️ Prix & rentabilité', '🏦 Finance & paie',
    'Fonctions', 'Équations', 'Suites',
    'Géométrie plane', 'Géométrie 3D',
    'Statistiques', 'Probabilités', 'Analyse',
]

ALL = {}
ALL.update(tpl_a.CH)
ALL.update(tpl_b.CH)
missing = [c for c in ORDER if c not in ALL]
extra = [c for c in ALL if c not in ORDER]
assert not missing and not extra, (missing, extra)

def j(x):
    return json.dumps(x, ensure_ascii=False)

out = io.StringIO()
out.write('const TPLS={\n')
n_tpl = 0
for chap in ORDER:
    out.write('  %s:[\n' % j(chap))
    for (name, lls, ex, exc) in ALL[chap]:
        assert ex and exc, (chap, name)
        out.write('    {name:%s,lls:%s,ex:%s,exc:%s},\n' % (j(name), j(lls), j(ex), j(exc)))
        n_tpl += 1
    out.write('  ],\n')
out.write('};\n')
tpls_js = out.getvalue()

KW = {
 'Calcul numérique': 'calcul nombre puissance exposant racine identite remarquable notation scientifique developpement factorisation fraction arrondi conversion unite',
 'Proportionnalité & %': 'pourcentage pourcent percent proportion taux evolution coefficient multiplicateur regle de trois quatrieme proportionnelle reduction augmentation solde remise partage proportionnel',
 '💶 Calculs commerciaux': 'commerce commercial vente achat cout prix revient marge taux de marge taux de marque coefficient multiplicateur tva ttc ht remise rabais ristourne escompte facture chiffre affaires benefice gestion',
 '🏷️ Prix & rentabilité': 'prix fixation rentabilite seuil point mort charges fixes variables marge sur cout variable resultat marge de securite prix psychologique indice pouvoir achat inflation',
 '🏦 Finance & paie': 'finance interet simple compose placement epargne valeur acquise credit emprunt mensualite endettement amortissement paie salaire brut net cotisation charge patronale cout employeur',
 'Fonctions': 'fonction affine lineaire courbe representation antecedent image logarithme exponentielle inverse polynome lecture graphique cout recette benefice',
 'Équations': 'equation inequation resoudre solution racine discriminant delta inconnue systeme droite tableau de signes',
 'Suites': 'suite arithmetique geometrique raison terme rang recurrence somme variation',
 'Géométrie plane': 'geometrie triangle pythagore thales trigonometrie cosinus sinus tangente aire perimetre distance milieu cercle echelle plan',
 'Géométrie 3D': 'volume solide espace prisme cylindre pyramide cone sphere agrandissement reduction echelle aire laterale capacite litre',
 'Statistiques': 'statistique moyenne mediane quartile ecart type variance frequence effectif serie pourcentage etendue mode cumule',
 'Probabilités': 'probabilite evenement hasard tirage arbre binomiale esperance contraire union intersection pourcentage conditionnelle totales',
 'Analyse': 'derivee limite tangente integrale primitive aire sous la courbe valeur moyenne variation cout marginal',
}
kw_js = 'const TPL_CHAP_KW={\n' + ''.join(
    '  %s:%s,\n' % (j(k), j(KW[k])) for k in ORDER) + '};\n'

src = open('MathNotes.html', encoding='utf-8').read()

# ── remplacement du bloc TPLS ────────────────────────────────
m = re.search(r'^const TPLS=\{\n.*?^\};\n', src, re.S | re.M)
assert m, 'TPLS introuvable'
src = src[:m.start()] + tpls_js + src[m.end():]

# ── remplacement de TPL_CHAP_KW ──────────────────────────────
m = re.search(r'^const TPL_CHAP_KW=\{\n.*?^\};\n', src, re.S | re.M)
assert m, 'TPL_CHAP_KW introuvable'
src = src[:m.start()] + kw_js + src[m.end():]

open('MathNotes.html', 'w', encoding='utf-8').write(src)
print('chapitres :', len(ORDER), '| modèles :', n_tpl)
