# -*- coding: utf-8 -*-
"""Banc d'essai Playwright : ouvre MathNotes.html dans Chromium,
sert KaTeX depuis node_modules et bloque tout autre appel externe."""
import pathlib, contextlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).parent
APP = ROOT / 'MathNotes.html'
KATEX = ROOT / 'node_modules' / 'katex' / 'dist'
CHROME = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome'


def _route(route, request):
    url = request.url
    if 'katex' in url:
        if url.endswith('.css'):
            f = KATEX / 'katex.min.css'
        elif url.endswith('.js') and 'auto-render' in url:
            f = KATEX / 'contrib' / 'auto-render.min.js'
        elif url.endswith('.js'):
            f = KATEX / 'katex.min.js'
        else:
            name = url.split('/')[-1].split('?')[0]
            f = KATEX / 'fonts' / name
        if f.exists():
            ct = ('text/css' if f.suffix == '.css'
                  else 'application/javascript' if f.suffix == '.js'
                  else 'font/woff2')
            route.fulfill(status=200, body=f.read_bytes(), headers={'content-type': ct})
            return
    if url.startswith('file://'):
        route.continue_()
        return
    route.fulfill(status=200, body=b'', headers={'content-type': 'text/plain'})


@contextlib.contextmanager
def open_app(app=None, width=1500, height=1000):
    with sync_playwright() as pw:
        b = pw.chromium.launch(executable_path=CHROME, args=['--no-sandbox'])
        ctx = b.new_context(viewport={'width': width, 'height': height})
        page = ctx.new_page()
        page.route('**/*', _route)
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto((app or APP).as_uri())
        page.wait_for_timeout(900)
        page.errors = errors
        try:
            yield page
        finally:
            ctx.close()
            b.close()
