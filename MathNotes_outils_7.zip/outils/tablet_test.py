# -*- coding: utf-8 -*-
"""Mode tablette : utilisable sur écran étroit, inchangé sur ordinateur."""
from harness import open_app
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:200])

MES = """() => {
  const cs = el => getComputedStyle(document.getElementById(el));
  const r  = el => document.getElementById(el).getBoundingClientRect();
  return {
    ribbon_wrap: cs('ribbon').flexWrap, ribbon_ovx: cs('ribbon').overflowX,
    ribbon_h: Math.round(r('ribbon').height),
    vbar_wrap: cs('vbar').flexWrap,
    ew_align: cs('ew').alignItems,
    dock_w: Math.round(r('dock').width),
    rail_w: Math.round(r('rail').width),
    sheet_w: Math.round(r('editor').width),
    headh: getComputedStyle(document.documentElement).getPropertyValue('--headh').trim(),
    topbar_right_visible: r('editor').width > 0,
  };
}"""

# ── ordinateur : rien ne doit changer ──
with open_app(width=1500, height=1000) as page:
    page.wait_for_timeout(300)
    d = page.evaluate(MES)
    chk('ordinateur : ruban toujours sur plusieurs rangées', d['ribbon_wrap'] == 'wrap', d)
    chk('ordinateur : feuille centrée', d['ew_align'] == 'center')
    chk('ordinateur : feuille à la largeur A4', 790 <= d['sheet_w'] <= 800, d['sheet_w'])
    chk('ordinateur : rail à 62 px', d['rail_w'] == 62, d['rail_w'])
    page.evaluate("() => openDock('sym')")
    page.wait_for_timeout(300)
    chk('ordinateur : le panneau décale la page',
        page.evaluate("() => getComputedStyle(document.getElementById('ew')).marginRight") != '0px')
    chk('ordinateur : aucune erreur', not page.errors, page.errors[:3])

# ── tablette ──
with open_app(width=820, height=1100) as page:
    page.wait_for_timeout(400)
    d = page.evaluate(MES)
    chk('tablette : ruban sur une seule rangée défilable',
        d['ribbon_wrap'] == 'nowrap' and d['ribbon_ovx'] in ('auto','scroll'), d)
    chk('tablette : barre de symboles défilable', d['vbar_wrap'] == 'nowrap')
    chk('tablette : le ruban prend peu de hauteur', d['ribbon_h'] < 80, d['ribbon_h'])
    chk('tablette : rail compact', d['rail_w'] == 52, d['rail_w'])
    chk('tablette : la feuille garde la largeur A4', 790 <= d['sheet_w'] <= 800, d['sheet_w'])
    chk('tablette : on peut atteindre le bord gauche de la feuille',
        page.evaluate("""() => { const ew=document.getElementById('ew');
          ew.scrollLeft=0;
          return document.getElementById('editor').getBoundingClientRect().left
                 >= ew.getBoundingClientRect().left - 1; }"""))
    chk('tablette : toute la feuille est atteignable par défilement',
        page.evaluate("""() => { const ew=document.getElementById('ew');
          ew.scrollLeft=ew.scrollWidth;
          const ed=document.getElementById('editor').getBoundingClientRect();
          return ed.right <= ew.getBoundingClientRect().right + 2; }"""))
    page.evaluate("() => openDock('tpl')")
    page.wait_for_timeout(350)
    d2 = page.evaluate(MES)
    chk('tablette : le panneau se superpose, sans décaler la page',
        page.evaluate("() => getComputedStyle(document.getElementById('ew')).marginRight") == '0px')
    chk('tablette : le panneau tient à l\'écran', d2['dock_w'] <= 820*0.88+1, d2['dock_w'])
    chk('tablette : le panneau est bien visible',
        page.evaluate("""() => { const r=document.getElementById('dock').getBoundingClientRect();
          return r.right <= window.innerWidth+1 && r.left >= 0; }"""))
    page.evaluate("() => closeDock()")
    # les fonctions essentielles marchent toujours
    page.evaluate("""() => { const p=ED.querySelector('p')||ED;
      const r=document.createRange();r.selectNodeContents(p);r.collapse(false);
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();
      insMathInline('x^2'); }""")
    chk('tablette : insertion de formule opérationnelle',
        page.evaluate("() => { const m=ED.querySelector('.mx'); return !!m && !!m.querySelector('.katex'); }"))
    chk('tablette : tous les boutons du ruban restent présents',
        page.evaluate("() => document.querySelectorAll('#ribbon .rbb').length") ==
        page.evaluate("() => document.querySelectorAll('#ribbon .rbb').length"))
    chk('tablette : aucune erreur', not page.errors, page.errors[:3])

# ── téléphone : on vérifie seulement que rien ne casse ──
with open_app(width=420, height=860) as page:
    page.wait_for_timeout(400)
    chk('téléphone : l\'application se charge sans erreur', not page.errors, page.errors[:3])
    chk('téléphone : le ruban reste accessible',
        page.evaluate("() => document.getElementById('ribbon').scrollWidth > document.getElementById('ribbon').clientWidth"))
print('\n%d PASS / %d FAIL' % (P,F))
