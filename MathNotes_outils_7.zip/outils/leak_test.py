# -*- coding: utf-8 -*-
"""Le stockage peut-il grossir tout seul ? Et des cours peuvent-ils
rester en base sans apparaître nulle part ?"""
from harness import open_app

with open_app() as page:
    page.wait_for_timeout(600)

    # ── 1. écrire cent fois le même cours fait-il grossir le stockage ? ──
    r = page.evaluate("""async () => {
      // état de départ déterministe : la sauvegarde automatique (1,5 s) a pu
      // écrire avant nous, on vide donc AUSSI la base
      clearTimeout(saveT);
      await new Promise(r => { const rq = DB.transaction('docs','readwrite').objectStore('docs').clear();
                               rq.onsuccess = r; rq.onerror = r; });
      Object.keys(DOC_CACHE).forEach(k => delete DOC_CACHE[k]);
      localStorage.clear(); LIB={cur:'',docs:[]}; libInit();
      ED.innerHTML = '<h1>Un cours</h1><p>' + 'X'.repeat(200000) + '</p>';
      await saveDoc(false);
      const e1 = await navigator.storage.estimate();
      for (let i=0;i<100;i++) await saveDoc(false);      // cent enregistrements
      const e2 = await navigator.storage.estimate();
      // et cent feuilles blanches (donc cent copies de secours)
      for (let i=0;i<100;i++) { ED.innerHTML='<h1>T'+i+'</h1><p>'+'Y'.repeat(50000)+'</p>';
                                await docPut(BACKUP_ID, cleanHTML()); }
      const e3 = await navigator.storage.estimate();
      return {apres_1:e1.usage, apres_100:e2.usage, apres_secours:e3.usage};
    }""")
    print('ÉCRITURES RÉPÉTÉES')
    print('  après 1 enregistrement   : %7.2f Mo' % (r['apres_1']/1048576))
    print('  après 100 enregistrements: %7.2f Mo' % (r['apres_100']/1048576))
    print('  après 100 copies secours : %7.2f Mo' % (r['apres_secours']/1048576))
    print('  → croissance : %+.2f Mo' % ((r['apres_secours']-r['apres_1'])/1048576))

    # ── 2. des cours peuvent-ils devenir invisibles ? ──
    o = page.evaluate("""async () => {
      const id='orphelin'+Date.now().toString(36);
      await docPut(id,'<h1>Cours devenu invisible</h1>');
      // la liste des cours est perdue (vidage partiel, échec d'écriture…)
      localStorage.removeItem('mn_lib');
      LIB={cur:'',docs:[]}; libInit();
      const cles = await new Promise(res=>{
        const st=DB.transaction('docs','readonly').objectStore('docs');
        const rq=st.getAllKeys(); rq.onsuccess=()=>res(rq.result); rq.onerror=()=>res([]);
      });
      const connus = LIB.docs.map(d=>d.id).concat(['__backup__']);
      const orphelins = cles.filter(k=>connus.indexOf(k)<0);
      return {cles_en_base:cles.length, orphelins:orphelins.length,
              visibles_dans_la_bibliotheque:LIB.docs.length};
    }""")
    print('\nCOURS INVISIBLES')
    for k,v in o.items(): print('  %-30s %s' % (k,v))
    print('\nErreurs JS :', page.errors[:2] or 'aucune')

# ═══════ récupération des contenus retrouvés ═══════
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:200])

with open_app() as page:
    page.wait_for_timeout(600)
    setup = page.evaluate("""async () => {
      // état de départ déterministe : la sauvegarde automatique (1,5 s) a pu
      // écrire avant nous, on vide donc AUSSI la base
      clearTimeout(saveT);
      await new Promise(r => { const rq = DB.transaction('docs','readwrite').objectStore('docs').clear();
                               rq.onsuccess = r; rq.onerror = r; });
      Object.keys(DOC_CACHE).forEach(k => delete DOC_CACHE[k]);
      localStorage.clear(); LIB={cur:'',docs:[]}; libInit();
      ED.innerHTML='<h1>Cours normal</h1>'; await saveDoc(false);
      const perdu='perdu'+Date.now().toString(36);
      await docPut(perdu,'<h1>Chapitre 4 — Statistiques</h1><p>Travail de deux heures.</p>');
      // la liste perd la trace de ce cours
      LIB.docs=LIB.docs.filter(d=>d.id!==perdu); libSave();
      const l=await scanOrphelins();
      return {orphelins:l.length, id:perdu};
    }""")
    chk('un contenu hors liste est détecté', setup['orphelins'] == 1, setup)
    page.evaluate("() => { renderLib(); }")
    chk('il apparaît dans la bibliothèque',
        'retrouvés dans le stockage' in page.evaluate("() => document.getElementById('lib-list').textContent"))
    chk('avec un bouton Récupérer',
        page.evaluate("""() => [...document.querySelectorAll('.lib-b')].some(b =>
            (b.getAttribute('onclick')||'').includes('orphelinRecuperer'))"""))
    page.evaluate("async (id) => await orphelinRecuperer(id)", setup['id'])
    page.wait_for_timeout(200)
    chk('la récupération le remet dans la liste',
        page.evaluate("() => LIB.docs.length") == 2)
    chk('son titre est repris du document',
        'Statistiques' in page.evaluate("() => LIB.docs.map(d=>d.title).join('|')"),
        page.evaluate("() => LIB.docs.map(d=>d.title)"))
    chk('plus aucun contenu hors liste',
        page.evaluate("async () => (await scanOrphelins()).length") == 0)
    page.evaluate("async (id) => { const c = await docGet(id); return !!c; }", setup['id'])
    chk('le contenu est intact et ouvrable',
        'deux heures' in (page.evaluate("async (id) => await docGet(id)", setup['id']) or ''))

    # suppression volontaire d'un contenu retrouvé
    r2 = page.evaluate("""async () => {
      const id='jeter'+Date.now().toString(36);
      await docPut(id,'<h1>À jeter</h1>');
      LIB.docs=LIB.docs.filter(d=>d.id!==id); libSave();
      await scanOrphelins();
      libArmed=id; await orphelinSupprimer(document.createElement('button'), id);
      return {restants:(await scanOrphelins()).length, contenu:await docGet(id)};
    }""")
    chk('la suppression volontaire libère la place',
        r2['restants'] == 0 and not r2['contenu'], r2)
    chk('aucune erreur JS', not page.errors, page.errors[:3])
print('\n%d PASS / %d FAIL' % (P,F))
