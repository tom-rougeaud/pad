# -*- coding: utf-8 -*-
"""Pastilles de compétences : insertion, taille, effacement, export, impression."""
from harness import open_app
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:200])

CARET = """() => {
  const p = ED.querySelector('p') || ED;
  const r = document.createRange(); r.selectNodeContents(p); r.collapse(false);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
}"""

with open_app() as page:
    chk('les 5 compétences sont définies',
        page.evaluate("() => COMPETENCES.length") == 5)
    chk('ce sont bien celles du Bac Pro',
        page.evaluate("() => COMPETENCES.map(c=>c.n).join('|')")
        == "S'approprier|Raisonner|Réaliser|Valider|Communiquer",
        page.evaluate("() => COMPETENCES.map(c=>c.n)"))
    couleurs = page.evaluate("() => COMPETENCES.map(c=>c.c)")
    chk('chacune a sa propre couleur', len(set(couleurs)) == 5, couleurs)
    chk('chacune a son pictogramme',
        page.evaluate("() => COMPETENCES.every(c => c.d && c.d.length > 20)"))
    chk('bouton dans le ruban',
        page.evaluate("""() => !!document.querySelector('#rb-comp')"""))

    # ── insertion des deux versions ──
    page.evaluate("() => { ED.innerHTML = '<p>Exercice 1. </p>'; }")
    page.evaluate(CARET)
    page.evaluate("() => insCompetence('rea', false)")
    page.evaluate("() => insCompetence('val', true)")
    page.wait_for_timeout(200)
    chk('deux pastilles insérées', page.evaluate("() => ED.querySelectorAll('.comp').length") == 2)
    chk('version icône seule sans texte',
        page.evaluate("""() => { const c=ED.querySelector('.comp[data-v="i"]');
          return !!c.querySelector('svg') && c.textContent.trim()===''; }"""))
    chk('version icône + nom',
        page.evaluate("""() => { const c=ED.querySelector('.comp[data-v="n"]');
          return !!c.querySelector('svg') && c.textContent.trim()==='Valider'; }"""))
    chk('la couleur est celle de la compétence',
        page.evaluate("""() => getComputedStyle(ED.querySelector('.comp[data-v="n"]')).backgroundColor""")
        == 'rgb(217, 119, 6)')
    chk('coins arrondis',
        page.evaluate("""() => parseFloat(getComputedStyle(ED.querySelector('.comp')).borderRadius) >= 4"""))
    chk('le pictogramme prend la couleur du texte (blanc)',
        page.evaluate("""() => getComputedStyle(ED.querySelector('.comp svg')).color""") == 'rgb(255, 255, 255)')

    # ── taille raisonnable par rapport au texte ──
    t = page.evaluate("""() => {
      const p = ED.querySelector('p');
      const txt = parseFloat(getComputedStyle(p).fontSize);
      const c = ED.querySelector('.comp');
      const r = c.getBoundingClientRect();
      const ligne = parseFloat(getComputedStyle(p).lineHeight);
      return {texte_px: txt, pastille_px: parseFloat(getComputedStyle(c).fontSize),
              hauteur: Math.round(r.height), hauteur_de_ligne: Math.round(ligne)};
    }""")
    chk('taille de police inférieure au texte (%(pastille_px)s vs %(texte_px)s)' % t,
        t['pastille_px'] < t['texte_px'], t)
    chk('hauteur contenue dans l\'interligne (%(hauteur)s vs %(hauteur_de_ligne)s)' % t,
        t['hauteur'] <= t['hauteur_de_ligne'] + 4, t)

    # ── elle ne casse pas la ligne ──
    chk('la pastille reste sur la ligne du texte',
        page.evaluate("""() => { const p=ED.querySelector('p');
          return p.getBoundingClientRect().height < 60; }"""))

    # ── effacement comme un caractère ──
    n0 = page.evaluate("() => ED.querySelectorAll('.comp').length")
    page.evaluate("""() => {
      const c = ED.querySelectorAll('.comp')[1];
      const r = document.createRange(); r.setStartAfter(c.nextSibling || c); r.collapse(true);
      const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
      ED.focus();
    }""")
    page.keyboard.press('Backspace')   # l'espace insécable
    page.keyboard.press('Backspace')   # la pastille
    page.wait_for_timeout(150)
    chk('un Retour arrière efface la pastille entière',
        page.evaluate("() => ED.querySelectorAll('.comp').length") == n0 - 1,
        page.evaluate("() => ED.innerHTML.slice(0,200)"))
    chk('rien ne reste du pictogramme',
        page.evaluate("() => ED.querySelectorAll('.comp svg').length") == n0 - 1)

    # ── survit à l'enregistrement ──
    page.evaluate("() => { window.__s = cleanHTML(); ED.innerHTML = window.__s; reattach(); }")
    chk('la pastille survit à l\'enregistrement',
        page.evaluate("() => ED.querySelectorAll('.comp').length") == 1)
    chk('sa couleur est conservée',
        page.evaluate("""() => getComputedStyle(ED.querySelector('.comp')).backgroundColor""")
        == 'rgb(39, 174, 96)', page.evaluate("() => ED.querySelector('.comp').outerHTML.slice(0,120)"))

    # ── export ──
    html = page.evaluate("""() => { let o='';const a0=HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click=function(){};const OB=window.Blob;
      window.Blob=function(p,x){o=p.join('');return new OB(p,x);};
      try{exportWeb();}finally{window.Blob=OB;HTMLAnchorElement.prototype.click=a0;}
      return o; }""")
    chk('export : la pastille est là', 'class="comp"' in html)
    chk('export : son style aussi', '.comp{' in html)
    chk('export : le pictogramme est vectoriel', '<svg viewBox="0 0 16 16"' in html)

    # ── impression ──
    page.evaluate("() => { window.__r = preparePrint(true); }")
    page.emulate_media(media='print')
    page.wait_for_timeout(200)
    chk('impression : la pastille garde sa couleur',
        page.evaluate("""() => getComputedStyle(ED.querySelector('.comp')).backgroundColor""")
        == 'rgb(39, 174, 96)')
    page.emulate_media(media='screen')
    page.evaluate("() => { window.__r(); }")

    chk('aucune erreur JS', not page.errors, page.errors[:3])
print('\n%d PASS / %d FAIL' % (P,F))
