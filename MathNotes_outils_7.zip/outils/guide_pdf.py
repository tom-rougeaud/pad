# -*- coding: utf-8 -*-
"""Imprime MathNotes_Guide.html en PDF A4, polices embarquées,
avec un pied de page « page / total »."""
import base64, pathlib, re
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).parent
SRC = pathlib.Path('/mnt/user-data/outputs/MathNotes_Guide.html')
OUT = pathlib.Path('/mnt/user-data/outputs/MathNotes_Guide.pdf')
CHROME = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
FONTS = ROOT / 'node_modules' / '@fontsource'

WANT = [
    ('DM Sans', 'dm-sans', '400', 'normal'),
    ('DM Sans', 'dm-sans', '500', 'normal'),
    ('DM Sans', 'dm-sans', '600', 'normal'),
    ('DM Sans', 'dm-sans', '700', 'normal'),
    ('DM Sans', 'dm-sans', '400', 'italic'),
    ('DM Mono', 'dm-mono', '400', 'normal'),
    ('Lora', 'lora', '400', 'normal'),
    ('Lora', 'lora', '700', 'normal'),
]

faces = []
for family, pkg, weight, style in WANT:
    f = FONTS / pkg / 'files' / ('%s-latin-%s-%s.woff2' % (pkg, weight, style))
    if not f.exists():
        print('  (absente) ', f.name)
        continue
    b64 = base64.b64encode(f.read_bytes()).decode()
    faces.append("@font-face{font-family:'%s';font-style:%s;font-weight:%s;font-display:block;"
                 "src:url(data:font/woff2;base64,%s) format('woff2');}" % (family, style, weight, b64))
print('polices embarquées :', len(faces))

html = SRC.read_text(encoding='utf-8')
# la feuille distante de Google Fonts est injoignable hors ligne : on l'enlève
html = re.sub(r'<link href="https://fonts\.googleapis\.com[^>]*>', '', html)
html = html.replace('<style>', '<style>\n' + '\n'.join(faces) + '\n', 1)
# tout est déplié dans le PDF
html = html.replace('class="acc "', 'class="acc open"').replace('class="acc faq"', 'class="acc faq open"')

tmp = ROOT / '_guide_print.html'
tmp.write_text(html, encoding='utf-8')

HEADER = '<div style="font-size:6pt;"></div>'
FOOTER = ("<div style=\"width:100%;font-family:'DM Sans',sans-serif;font-size:8.5pt;color:#6B7280;"
          "padding:0 13mm;display:flex;justify-content:space-between;\">"
          "<span>MathNotes — Guide complet</span>"
          "<span><span class='pageNumber'></span> / <span class='totalPages'></span></span></div>")

with sync_playwright() as pw:
    b = pw.chromium.launch(executable_path=CHROME, args=['--no-sandbox'])
    page = b.new_page()
    page.goto(tmp.as_uri())
    page.wait_for_timeout(700)
    page.evaluate("""() => { document.querySelectorAll('.acc').forEach(a => a.classList.add('open')); }""")
    page.emulate_media(media='print')
    page.wait_for_timeout(400)
    page.pdf(path=str(OUT), format='A4', print_background=True,
             display_header_footer=True, header_template=HEADER, footer_template=FOOTER,
             margin={'top': '12mm', 'bottom': '15mm', 'left': '13mm', 'right': '13mm'})
    b.close()

print('PDF :', OUT, OUT.stat().st_size, 'octets')
