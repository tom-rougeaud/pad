# -*- coding: utf-8 -*-
"""Signature du défaut : un nombre utilisé dans la conclusion alors qu'il
n'apparaît ni dans l'énoncé (1re ligne) ni dans aucun calcul affiché.
C'est exactement le cas « d'où vient le 50 ? »."""
import re, tpl_a, tpl_b

ALL = {}; ALL.update(tpl_a.CH); ALL.update(tpl_b.CH)

def nums(s):
    s = (s.replace('\\,', '').replace('\\ ', '').replace(' ', '')
          .replace(' ', '').replace('{,}', ','))
    out = []
    for m in re.finditer(r'\d+(?:[,.]\d+)?', s):
        try: out.append(float(m.group(0).replace(',', '.')))
        except ValueError: pass
    return out

TRIVIAL = set(range(0, 13)) | {100, 1000, 0.5}

bad = 0
for chap, items in ALL.items():
    for name, lls, ex, exc in items:
        for key, lines in (('exemple', ex), ('situation pro', exc)):
            if not lines: continue
            enonce = set(nums(lines[0]))
            calculs = set()
            for l in lines:
                t = l.strip()
                if t.startswith('$$'):
                    calculs |= set(nums(t))
                else:                       # formules en ligne $…$ de la prose
                    for seg in t.split('$')[1::2]:
                        calculs |= set(nums(seg))
            for i, line in enumerate(lines[1:], 1):
                if line.strip().startswith('$$'): continue
                # texte seul, hors formules
                prose = '$'.join(line.split('$')[0::2])
                for v in nums(prose):
                    if v in TRIVIAL or v in enonce or v in calculs: continue
                    bad += 1
                    print('ORPHELIN | %s | %s | %s' % (chap, name, key))
                    print('   %s n\'est ni donné, ni calculé' % v)
                    print('   %s' % line[:170])
print('\n%s' % ('PASS — aucun nombre ne sort de nulle part'
                if not bad else 'FAIL — %d donnée(s) orpheline(s)' % bad))
