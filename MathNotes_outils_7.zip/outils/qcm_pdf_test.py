# -*- coding: utf-8 -*-
"""Un QCM plus long qu'une page : la coupure doit tomber entre deux questions,
et chaque question doit rester avec ses réponses sur la même page du PDF."""
import subprocess, pathlib, tempfile, re
from harness import open_app

P = F = 0
def chk(label, cond, extra=''):
    global P, F
    if cond: P += 1; print('PASS', label)
    else: F += 1; print('FAIL', label, repr(extra)[:250])

TMP = pathlib.Path(tempfile.mkdtemp())
NQ, NA = 15, 4

DOC = """([nq, na]) => {
  ED.innerHTML = '<h1>Évaluation — calculs commerciaux</h1><p><br></p>';
  const p = ED.querySelector('p');
  const r = document.createRange(); r.selectNodeContents(p); r.collapse(true);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
  document.getElementById('qcm-nq').value = nq;
  document.getElementById('qcm-na').value = na;
  document.getElementById('qcm-multi').value = 'multi';
  insQCM();
  ED.querySelectorAll('.qcm-q').forEach((q, i) => {
    q.querySelector('.qcm-q-text').textContent = 'QQ' + (i+1) + ' énoncé de la question numéro ' + (i+1);
    q.querySelectorAll('.qcm-cell').forEach((c, j) => c.textContent = 'RR' + (i+1) + '_' + (j+1));
    q.querySelectorAll('.qcm-box')[i % na].click();
  });
  ED.querySelectorAll('.qcm-corr-q-btn')[3].click();
  ED.querySelectorAll('.qcm-q-corr')[3].textContent = 'CORRQ4 explication de la question 4.';
  paginate();
  return document.querySelectorAll('.pg-auto').length + 1;
}"""

with open_app() as page:
    screen_pages = page.evaluate(DOC, [NQ, NA])
    page.wait_for_timeout(400)
    screen_pages = page.evaluate("() => pgInfo.pages")
    chk('le QCM s\'étale sur plusieurs pages à l\'écran (%d)' % screen_pages, screen_pages >= 2)

    for name, with_corr in (('eleve', False), ('prof', True)):
        page.evaluate("(w) => { window.__r = preparePrint(w); }", with_corr)
        page.wait_for_timeout(250)
        out = TMP / ('qcm_%s.pdf' % name)
        page.pdf(path=str(out), format='A4', print_background=True,
                 margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
        page.evaluate("() => { window.__r(); }")
        page.wait_for_timeout(200)

        txt = subprocess.run(['pdftotext', '-layout', str(out), '-'],
                             capture_output=True, text=True).stdout
        pages = [x for x in txt.split('\f') if x.strip()]
        info = subprocess.run(['pdfinfo', str(out)], capture_output=True, text=True).stdout
        npdf = int(re.search(r'Pages:\s+(\d+)', info).group(1))

        chk('%s : autant de pages qu\'à l\'écran (%d/%d)' % (name, npdf, screen_pages), npdf == screen_pages)

        def where(tok):
            return [i for i, pg in enumerate(pages) if tok in pg]

        broken, missing = [], []
        for i in range(1, NQ + 1):
            pq = where('QQ%d ' % i)
            if len(pq) != 1:
                missing.append(('QQ%d' % i, pq)); continue
            for j in range(1, NA + 1):
                pa = where('RR%d_%d' % (i, j))
                if pa != pq:
                    broken.append(('Q%d' % i, 'R%d' % j, pq, pa))
        chk('%s : les %d questions sont toutes présentes une seule fois' % (name, NQ), not missing, missing)
        chk('%s : chaque question est sur la même page que ses réponses' % name, not broken, broken)

        chk('%s : aucun élément de menu' % name,
            not any(w in txt for w in ('TUTO', 'Confid.', 'Symboles', 'Calculatrice')))
        if with_corr:
            chk('prof : commentaire de la question 4 imprimé', 'CORRQ4' in txt)
            chk('prof : commentaire sur la page de sa question',
                where('CORRQ4') == where('QQ4 '), (where('CORRQ4'), where('QQ4 ')))
        else:
            chk('élève : commentaire de question absent', 'CORRQ4' not in txt)

    chk('aucune erreur JS', not page.errors, page.errors[:3])

print('\n%d PASS / %d FAIL' % (P, F))
