# -*- coding: utf-8 -*-
"""QCM : création, édition, correction, impression, export interactif."""
import re, pathlib, tempfile
from harness import open_app

P = F = 0
def chk(label, cond, extra=''):
    global P, F
    if cond: P += 1; print('PASS', label)
    else: F += 1; print('FAIL', label, repr(extra)[:220])

CREATE = """([nq, na, multi]) => {
  const p = ED.querySelector('p') || ED;
  const r = document.createRange(); r.selectNodeContents(p); r.collapse(false);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
  document.getElementById('qcm-nq').value = nq;
  document.getElementById('qcm-na').value = na;
  document.getElementById('qcm-multi').value = multi;
  insQCM();
  return ED.querySelectorAll('.qcm-block').length;
}"""

with open_app() as page:
    # ── création ────────────────────────────────────────────
    chk('fenêtre de création présente', page.evaluate("() => !!document.getElementById('m-qcm')"))
    chk('bouton QCM dans le ruban',
        page.evaluate("""() => [...document.querySelectorAll('.rbb')].some(b => (b.getAttribute('onclick')||'').includes('openQcmDlg'))"""))
    chk('commande /qcm', page.evaluate("() => SC.some(x => x.c === 'qcm' && x.special === 'qcm')"))

    chk('QCM créé', page.evaluate(CREATE, [3, 4, 'multi']) == 1)
    chk('3 questions', page.evaluate("() => ED.querySelectorAll('.qcm-q').length") == 3)
    chk('4 réponses par question',
        page.evaluate("() => [...ED.querySelectorAll('.qcm-q')].every(q => q.querySelectorAll('.qcm-a').length === 4)"))
    chk('numérotation 1. 2. 3.',
        page.evaluate("() => [...ED.querySelectorAll('.qcm-num')].map(n => n.textContent).join('')") == '1.2.3.')
    chk('titre éditable',
        page.evaluate("() => ED.querySelector('.qcm-label').getAttribute('contenteditable')") == 'true')
    chk('cellules éditables',
        page.evaluate("() => [...ED.querySelectorAll('.qcm-cell,.qcm-q-text')].every(c => c.getAttribute('contenteditable') === 'true')"))
    chk('retour à la ligne automatique dans les cellules',
        page.evaluate("""() => { const c = ED.querySelector('.qcm-cell');
            const s = getComputedStyle(c); return s.overflowWrap === 'anywhere' && s.wordBreak === 'break-word'; }"""))
    chk('bloc non éditable (enveloppe scellée)',
        page.evaluate("() => ED.querySelector('.qcm-block').getAttribute('contenteditable')") == 'false')

    # ── texte long : la cellule ne déborde pas ───────────────
    over = page.evaluate("""() => {
      const c = ED.querySelector('.qcm-cell');
      c.textContent = 'Une réponse particulièrement longue qui doit impérativement revenir à la ligne automatiquement sans jamais dépasser la largeur de la page A4 ni celle du tableau.';
      const blk = ED.querySelector('.qcm-block');
      return c.getBoundingClientRect().right <= blk.getBoundingClientRect().right + 1;
    }""")
    chk('cellule longue : pas de débordement', over)

    # ── +/− questions et réponses ───────────────────────────
    page.evaluate("""() => ED.querySelector('.qcm-head-right .qcm-btn').click()""")
    chk('+ Question', page.evaluate("() => ED.querySelectorAll('.qcm-q').length") == 4)
    chk('renumérotation après ajout',
        page.evaluate("() => [...ED.querySelectorAll('.qcm-num')].map(n => n.textContent).join('')") == '1.2.3.4.')
    page.evaluate("""() => ED.querySelectorAll('.qcm-head-right .qcm-btn')[1].click()""")
    chk('− Question', page.evaluate("() => ED.querySelectorAll('.qcm-q').length") == 3)

    page.evaluate("""() => ED.querySelector('.qcm-q [title="Ajouter une réponse"]').click()""")
    chk('+ Réponse',
        page.evaluate("() => ED.querySelector('.qcm-q').querySelectorAll('.qcm-a').length") == 5)
    page.evaluate("""() => ED.querySelector('.qcm-q [title="Retirer la dernière réponse"]').click()""")
    chk('− Réponse',
        page.evaluate("() => ED.querySelector('.qcm-q').querySelectorAll('.qcm-a').length") == 4)

    page.evaluate("""() => { for (let i = 0; i < 3; i++) ED.querySelector('.qcm-q [title="Retirer la dernière réponse"]').click(); }""")
    chk('plancher de 2 réponses',
        page.evaluate("() => ED.querySelector('.qcm-q').querySelectorAll('.qcm-a').length") == 2)
    page.evaluate("""() => { for (let i = 0; i < 5; i++) ED.querySelectorAll('.qcm-head-right .qcm-btn')[1].click(); }""")
    chk('plancher d\'une question', page.evaluate("() => ED.querySelectorAll('.qcm-q').length") == 1)

    # ── remise en place d'un QCM de travail ─────────────────
    page.evaluate("() => { ED.querySelector('.qcm-block').remove(); }")
    page.evaluate(CREATE, [2, 3, 'multi'])

    # ── cocher les bonnes réponses ──────────────────────────
    page.evaluate("""() => {
      const qs = ED.querySelectorAll('.qcm-q');
      qs[0].querySelectorAll('.qcm-cell').forEach((c, i) => c.textContent = 'Réponse ' + (i+1));
      qs[0].querySelector('.qcm-q-text').textContent = 'Combien font 3 x 4 ?';
      qs[0].querySelectorAll('.qcm-box')[1].click();
      qs[1].querySelectorAll('.qcm-box')[0].click();
      qs[1].querySelectorAll('.qcm-box')[2].click();
    }""")
    chk('réponses justes mémorisées',
        page.evaluate("() => [...ED.querySelectorAll('.qcm-a')].map(a => a.dataset.ok).join('')") == '010101')
    chk('marque verte visible en mode correction',
        page.evaluate("""() => { const a = ED.querySelectorAll('.qcm-a')[1];
          return getComputedStyle(a.querySelector('.qcm-box')).backgroundColor === 'rgb(13, 148, 136)'; }"""))

    # ── une seule bonne réponse ─────────────────────────────
    page.evaluate("""() => ED.querySelector('.qcm-q .qcm-multi-btn').click()""")
    chk('bascule en réponse unique',
        page.evaluate("() => ED.querySelector('.qcm-q').dataset.multi") == '0')
    chk('case ronde en réponse unique',
        page.evaluate("""() => getComputedStyle(ED.querySelector('.qcm-q .qcm-box')).borderRadius.startsWith('50')"""))
    page.evaluate("""() => { const q = ED.querySelectorAll('.qcm-q')[1];
      q.querySelector('.qcm-multi-btn').click();
      q.querySelector('.qcm-multi-btn').click();   /* repasse en multiple */
      q.dataset.multi = '0'; q.querySelectorAll('.qcm-box')[1].click(); }""")
    chk('réponse unique : une seule case cochée',
        page.evaluate("""() => [...ED.querySelectorAll('.qcm-q')[1].querySelectorAll('.qcm-a')]
            .filter(a => a.dataset.ok === '1').length""") == 1)

    # ── masquer / afficher la correction ────────────────────
    page.evaluate("() => ED.querySelector('.qcm-corr-btn').click()")
    chk('correction masquée', page.evaluate("() => ED.querySelector('.qcm-block').dataset.corr") == '0')
    chk('case redevenue vide',
        page.evaluate("""() => { const a = [...ED.querySelectorAll('.qcm-a')].find(x => x.dataset.ok === '1');
          return getComputedStyle(a.querySelector('.qcm-box')).backgroundColor === 'rgb(255, 255, 255)'; }"""))
    page.evaluate("() => ED.querySelector('.qcm-corr-btn').click()")
    chk('correction réaffichée', page.evaluate("() => ED.querySelector('.qcm-block').dataset.corr") == '1')

    # ── commentaire de correction ───────────────────────────
    page.evaluate("""() => { ED.querySelector('.qcm-corr-toggle').click();
      ED.querySelector('.qcm-corr-body').textContent = 'On reconnaît la table de 3.'; }""")
    chk('commentaire saisissable',
        'table de 3' in page.evaluate("() => ED.querySelector('.qcm-corr-body').textContent"))

    # ── Entrée passe au champ suivant ───────────────────────
    moved = page.evaluate("""() => {
      const t = ED.querySelector('.qcm-q-text'); focusInto(t);
      t.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', bubbles:true, cancelable:true}));
      return document.activeElement && document.activeElement.classList.contains('qcm-cell');
    }""")
    chk('Entrée passe à la réponse suivante', moved)

    # ── impression élève / professeur ───────────────────────
    page.evaluate("() => { window.__r = preparePrint(false); }")
    chk('impression élève : cases vides',
        page.evaluate("() => ED.querySelector('.qcm-block').dataset.corr") == '0')
    chk('impression élève : commentaire masqué',
        page.evaluate("() => ED.querySelector('.qcm-corr-wrap').style.display") == 'none')
    page.emulate_media(media='print')
    chk('impression : outils cachés',
        page.evaluate("""() => getComputedStyle(ED.querySelector('.qcm-q-tools')).display === 'none'"""))
    page.emulate_media(media='screen')
    page.evaluate("() => { window.__r(); }")
    page.evaluate("() => { window.__r = preparePrint(true); }")
    chk('impression professeur : bonnes réponses cochées',
        page.evaluate("() => ED.querySelector('.qcm-block').dataset.corr") == '1')
    chk('impression professeur : commentaire visible',
        page.evaluate("() => ED.querySelector('.qcm-corr-wrap').style.display") != 'none')
    page.evaluate("() => { window.__r(); }")
    chk('état restauré après impression',
        page.evaluate("() => ED.querySelector('.qcm-block').dataset.corr") == '1')

    # ── export Page Web ─────────────────────────────────────
    html = page.evaluate("""() => {
      let out = '';
      const old = URL.createObjectURL;
      const a0 = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function(){};
      const oldBlob = window.Blob;
      window.Blob = function(parts, opts){ out = parts.join(''); return new oldBlob(parts, opts); };
      try { exportWeb(); } finally { window.Blob = oldBlob; HTMLAnchorElement.prototype.click = a0; }
      return out;
    }""")
    chk('export produit un fichier', len(html) > 5000, len(html))
    chk('export : QCM présent', 'qcm-block' in html)
    chk('export : clé de correction non lisible en clair',
        'qcmTick' not in html and not re.search(r'<div class="qcm-a" data-ok', html))
    chk('export : clé de correction encodée', 'data-k=' in html)
    chk('export : bouton Vérifier', 'qcm-check' in html)
    chk('export : outils d\'édition retirés',
        'qcm-q-tools' not in html and 'qcmAddQ' not in html and 'qcmTick' not in html)
    chk('export : correction repliée', 'qcm-corr-export' in html)
    chk('export : styles du QCM conservés', '.qcm-cell' in html and '.qcm-box' in html)
    chk('export : rien n\'est éditable',
        not re.search(r'<(?!script)[^>]*\scontenteditable=', html))

    tmp = pathlib.Path(tempfile.mkdtemp()) / 'export.html'
    tmp.write_text(html, encoding='utf-8')
    chk('aucune erreur JS dans l\'éditeur', not page.errors, page.errors[:3])

# ── la page exportée fonctionne vraiment ────────────────────
with open_app(app=tmp) as ex:
    chk('export : 2 questions rendues', ex.evaluate("() => document.querySelectorAll('.qcm-q').length") == 2)
    chk('export : plus aucune bonne réponse en clair',
        ex.evaluate("() => document.querySelectorAll('[data-ok]').length") == 0)
    chk('export : cases vides au départ',
        ex.evaluate("""() => [...document.querySelectorAll('.qcm-a')].every(a => a.getAttribute('data-sel') !== '1')"""))
    # l'élève répond juste à la question 1, faux à la question 2
    ex.evaluate("""() => {
      const qs = document.querySelectorAll('.qcm-q');
      qs[0].querySelectorAll('.qcm-box')[1].click();
      qs[1].querySelectorAll('.qcm-box')[0].click();   /* faux : la bonne est la 2e */
    }""")
    chk('export : la coche de l\'élève est prise en compte',
        ex.evaluate("""() => document.querySelectorAll('.qcm-q')[0].querySelectorAll('.qcm-a')[1].getAttribute('data-sel')""") == '1')
    ex.evaluate("() => document.querySelector('.qcm-check').click()")
    score = ex.evaluate("() => document.querySelector('.qcm-score').textContent")
    chk('export : score calculé', re.search(r'1\s*/\s*2', score), score)
    chk('export : bonne réponse en vert',
        ex.evaluate("""() => document.querySelectorAll('.qcm-q')[0].querySelectorAll('.qcm-a')[1].className.includes('qcm-right')"""))
    chk('export : mauvaise réponse en rouge',
        ex.evaluate("""() => document.querySelectorAll('.qcm-q')[1].querySelectorAll('.qcm-a')[0].className.includes('qcm-wrong')"""))
    chk('export : réponse manquée signalée',
        ex.evaluate("""() => [...document.querySelectorAll('.qcm-q')[1].querySelectorAll('.qcm-a')].some(a => a.className.includes('qcm-miss'))"""))
    ex.evaluate("() => document.querySelector('.qcm-check').click()")
    chk('export : bouton Recommencer remet à zéro',
        ex.evaluate("""() => [...document.querySelectorAll('.qcm-a')].every(a => a.className === 'qcm-a')"""))
    chk('export : correction repliée par défaut',
        ex.evaluate("() => !document.querySelector('details.qcm-corr-export').open"))
    chk('export : aucune erreur JS', not ex.errors, ex.errors[:3])

print('\n%d PASS / %d FAIL' % (P, F))
