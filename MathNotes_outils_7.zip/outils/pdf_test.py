# -*- coding: utf-8 -*-
"""PDF : pas d'éléments de menu, correspondance page écran ↔ page PDF,
version élève sans corrections, version professeur avec."""
import subprocess, pathlib, tempfile, re
from harness import open_app

P = F = 0
def chk(label, cond, extra=''):
    global P, F
    if cond: P += 1; print('PASS', label)
    else: F += 1; print('FAIL', label, repr(extra)[:220])

TMP = pathlib.Path(tempfile.mkdtemp())

DOC = """() => {
  ED.innerHTML = '';
  const add = (tag, txt) => { const e = document.createElement(tag); e.textContent = txt; ED.appendChild(e); return e; };
  add('h1', 'Calculs commerciaux');
  for (let i = 1; i <= 26; i++) add('p', 'Paragraphe ' + i + ' — MARQUEUR_UN, prix de revient et marge commerciale dans un négoce de pneumatiques.');
  const br = document.createElement('div'); br.className = 'pg-manual'; br.setAttribute('contenteditable','false'); ED.appendChild(br);
  add('h2', 'Évaluation');
  const p = ED.lastElementChild;
  const r = document.createRange(); r.selectNodeContents(p); r.collapse(false);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
  document.getElementById('qcm-nq').value = 1;
  document.getElementById('qcm-na').value = 3;
  insQCM();
  const q = ED.querySelector('.qcm-q');
  q.querySelector('.qcm-q-text').textContent = 'Quel est le taux de marge ?';
  q.querySelectorAll('.qcm-cell').forEach((c, i) => c.textContent = 'MARQUEUR_REP' + (i+1));
  q.querySelectorAll('.qcm-box')[1].click();
  ED.querySelector('.qcm-corr-toggle').click();
  ED.querySelector('.qcm-corr-body').textContent = 'MARQUEUR_CORRIGE : marge divisée par le coût d\\'achat.';
  const e = document.createElement('p'); e.textContent = 'MARQUEUR_DEUX fin du document.'; ED.appendChild(e);
  paginate();
  return 1;
}"""

with open_app() as page:
    page.evaluate(DOC)
    page.wait_for_timeout(300)
    screen_pages = page.evaluate("() => document.querySelectorAll('.pg-auto,.pg-manual').length + 1")

    for name, with_corr in (('eleve', False), ('prof', True)):
        page.evaluate("(w) => { window.__r = preparePrint(w); }", with_corr)
        page.wait_for_timeout(200)
        out = TMP / ('%s.pdf' % name)
        page.pdf(path=str(out), format='A4', print_background=True,
                 margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
        page.evaluate("() => { window.__r(); }")
        page.wait_for_timeout(150)

        txt = subprocess.run(['pdftotext', str(out), '-'], capture_output=True, text=True).stdout
        info = subprocess.run(['pdfinfo', str(out)], capture_output=True, text=True).stdout
        pages = int(re.search(r'Pages:\s+(\d+)', info).group(1))

        chk('%s : PDF produit' % name, out.exists() and out.stat().st_size > 1000)
        chk('%s : autant de pages qu\'à l\'écran (%d/%d)' % (name, pages, screen_pages), pages == screen_pages)
        chk('%s : aucun élément de menu' % name,
            not any(w in txt for w in ('TUTO', 'Confid.', 'Éditeur', 'Insérer', 'Symboles', 'Calculatrice')))
        first = txt.split('\f')[0]
        chk('%s : la page 1 du PDF est la page 1 de l\'écran' % name,
            'MARQUEUR_UN' in first and 'MARQUEUR_DEUX' not in first)
        pgs = [x for x in txt.split('\f') if x.strip()]
        hit = [i for i, x in enumerate(pgs) if 'MARQUEUR_REP' in x]
        chk('%s : le QCM tient sur une seule page' % name,
            len(hit) == 1 and all(('MARQUEUR_REP%d' % k) in pgs[hit[0]] for k in (1, 2, 3)), hit)
        if with_corr:
            chk('prof : commentaire de correction imprimé', 'MARQUEUR_CORRIGE' in txt)
        else:
            chk('élève : commentaire de correction absent', 'MARQUEUR_CORRIGE' not in txt)

    chk('aucune erreur JS', not page.errors, page.errors[:3])

print('\n%d PASS / %d FAIL' % (P, F))
