# -*- coding: utf-8 -*-
"""Réduction des images : allègement, transparence, non-régression."""
from harness import open_app
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:200])

MAKE = """([w,h,kind]) => {
  const cv=document.createElement('canvas'); cv.width=w; cv.height=h;
  const cx=cv.getContext('2d');
  if(kind==='alpha'){ cx.clearRect(0,0,w,h); cx.fillStyle='#2F80ED';
    cx.beginPath(); cx.arc(w/2,h/2,Math.min(w,h)/3,0,7); cx.fill(); }
  else { /* image de type photographique : formes larges et dégradés, comme une vraie photo */
    const g=cx.createLinearGradient(0,0,w,h);
    g.addColorStop(0,'#6b8fbf'); g.addColorStop(.5,'#d8c7a8'); g.addColorStop(1,'#3a6b45');
    cx.fillStyle=g; cx.fillRect(0,0,w,h);
    for(let i=0;i<220;i++){
      const rg=cx.createRadialGradient(Math.random()*w,Math.random()*h,2,Math.random()*w,Math.random()*h,w/6);
      rg.addColorStop(0,'rgba('+(30+i%200)+','+(60+(i*3)%180)+','+(90+(i*7)%160)+',.55)');
      rg.addColorStop(1,'rgba(0,0,0,0)');
      cx.fillStyle=rg; cx.fillRect(0,0,w,h);
    }
    cx.globalAlpha=.06;
    for(let i=0;i<9000;i++){ cx.fillStyle='rgb('+(i%256)+',120,90)';
      cx.fillRect(Math.random()*w,Math.random()*h,3,3); }
    cx.globalAlpha=1; }
  return cv.toDataURL(kind==='alpha'?'image/png':'image/jpeg',0.92);
}"""

with open_app() as page:
    # photo volumineuse
    big = page.evaluate(MAKE, [3000,2200,'photo'])
    r = page.evaluate("""async ([url]) => await shrinkImage(url,'image/jpeg')""", [big])
    chk('photo allégée sous l\'objectif', r['changed'] and r['after'] <= 420*1024
        and r['after'] < r['before']/3, '%d → %d' % (r['before'], r['after']))
    chk('ramenée à 1600 px', max(r['w'], r['h']) == 1600, (r['w'], r['h']))
    print('    %.2f Mo → %.0f Ko  (%.0f× plus léger)'
          % (r['before']/1048576, r['after']/1024, r['before']/r['after']))

    # petite image : intacte
    small = page.evaluate(MAKE, [400,300,'photo'])
    r2 = page.evaluate("""async ([url]) => await shrinkImage(url,'image/jpeg')""", [small])
    chk('petite image conservée telle quelle', not r2['changed'] or r2['after'] <= r2['before'])

    # transparence préservée
    alpha = page.evaluate(MAKE, [2400,2400,'alpha'])
    r3 = page.evaluate("""async ([url]) => {
      const res = await shrinkImage(url,'image/png');
      const img = new Image();
      await new Promise(ok => { img.onload = ok; img.src = res.url; });
      const cv = document.createElement('canvas'); cv.width = img.width; cv.height = img.height;
      const cx = cv.getContext('2d'); cx.drawImage(img,0,0);
      const px = cx.getImageData(2,2,1,1).data;
      return {changed: res.changed, before: res.before, after: res.after,
              type: res.url.slice(5,14), coin_alpha: px[3]};
    }""", [alpha])
    chk('image transparente réencodée en PNG', r3['type'].startswith('image/png'), r3['type'])
    chk('transparence préservée', r3['coin_alpha'] == 0, r3['coin_alpha'])
    chk('et tout de même allégée', r3['after'] < r3['before'],
        '%d → %d' % (r3['before'], r3['after']))

    # combien de photos tiennent maintenant
    n_avant = 5*1024*1024 // (r['before']*2)
    n_apres = 5*1024*1024 // (r['after']*2)
    print('    photos stockables : %d avant → %d après' % (n_avant, n_apres))
    chk('au moins 10 photos stockables', n_apres >= 10, n_apres)

    # l'insertion complète fonctionne toujours
    page.evaluate("""([url]) => {
      const p=ED.querySelector('p')||ED;
      const r=document.createRange();r.selectNodeContents(p);r.collapse(false);
      const s=getSelection();s.removeAllRanges();s.addRange(r);SR=r.cloneRange();
      imgB64=url; document.getElementById('img-url').value=''; document.getElementById('img-alt').value='Figure';
      confirmImg();
    }""", [small])
    chk('image insérée dans le document',
        page.evaluate("() => ED.querySelectorAll('.media-block img').length") == 1)
    chk('texte de remplacement conservé',
        page.evaluate("() => ED.querySelector('.media-block img').getAttribute('alt')") == 'Figure')
    chk('la fenêtre est remise à zéro',
        page.evaluate("() => imgB64 === null && document.getElementById('img-info').style.display === 'none'"))
    chk('aucune erreur JS', not page.errors, page.errors[:3])
print('\n%d PASS / %d FAIL' % (P,F))
