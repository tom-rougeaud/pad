import base64, pathlib, re
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path('/home/claude')
SRC=ROOT/'presentation.html'
OUT=pathlib.Path('/mnt/user-data/outputs/MathNotes_Presentation.pdf')
CHROME='/opt/pw-browsers/chromium-1194/chrome-linux/chrome'
F=ROOT/'node_modules'/'@fontsource'
WANT=[('DM Sans','dm-sans','400','normal'),('DM Sans','dm-sans','500','normal'),
      ('DM Sans','dm-sans','600','normal'),('DM Sans','dm-sans','700','normal'),
      ('DM Sans','dm-sans','400','italic'),('DM Sans','dm-sans','700','italic')]
faces=[]
for fam,pkg,w,st in WANT:
    f=F/pkg/'files'/('%s-latin-%s-%s.woff2'%(pkg,w,st))
    if f.exists():
        faces.append("@font-face{font-family:'%s';font-style:%s;font-weight:%s;font-display:block;src:url(data:font/woff2;base64,%s) format('woff2');}"%(fam,st,w,base64.b64encode(f.read_bytes()).decode()))
html=SRC.read_text(encoding='utf-8').replace('<style>','<style>\n'+'\n'.join(faces)+'\n',1)
tmp=ROOT/'_pres_print.html'; tmp.write_text(html,encoding='utf-8')
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path=CHROME,args=['--no-sandbox'])
    p=b.new_page(); p.goto(tmp.as_uri()); p.wait_for_timeout(700)
    p.emulate_media(media='print'); p.wait_for_timeout(300)
    p.pdf(path=str(OUT),format='A4',print_background=True,
          margin={'top':'0','bottom':'0','left':'0','right':'0'})
    b.close()
print('polices',len(faces),'|',OUT,OUT.stat().st_size,'octets')
