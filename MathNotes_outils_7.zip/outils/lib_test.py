# -*- coding: utf-8 -*-
"""Sauvegarde protégée + bibliothèque de cours."""
from harness import open_app
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:200])

with open_app() as page:
    # ── 1. alerte de sauvegarde ──
    chk('bandeau d\'alerte masqué au départ',
        page.evaluate("() => !document.getElementById('storage-alert').classList.contains('on')"))
    r=page.evaluate("""async () => {
      const vrai=DB; DB=null;                       /* base locale hors service */
      const real=localStorage.setItem.bind(localStorage);
      localStorage.setItem=function(k,v){ if(k.indexOf('mn_doc_')===0){const e=new Error('Quota');e.name='QuotaExceededError';throw e;} return real(k,v); };
      let threw=false;
      try{ await saveDoc(true); }catch(e){ threw=true; }
      const box=document.getElementById('storage-alert');
      const out={threw, visible:box.classList.contains('on'), texte:box.querySelector('.sa-txt').textContent};
      localStorage.setItem=real; DB=vrai;
      return out;
    }""")
    chk('la sauvegarde ne lève plus d\'erreur', not r['threw'])
    chk('le bandeau rouge apparaît', r['visible'])
    chk('le message est explicite', "n'est plus enregistré" in r['texte'], r['texte'][:90])
    chk('le message propose d\'enregistrer le fichier',
        page.evaluate("""() => (document.querySelector('#storage-alert .sa-btn').getAttribute('onclick')||'').includes('saveProject')"""))
    chk('sauvegarde réussie → bandeau retiré',
        page.evaluate("() => { saveDoc(true); return !document.getElementById('storage-alert').classList.contains('on'); }"))
    chk('stockage bloqué (navigation privée) : message adapté',
        page.evaluate("""() => {
          const real=localStorage.setItem.bind(localStorage);
          localStorage.setItem=function(){ throw new Error('SecurityError'); };
          storageMuted=false; saveDoc(false);
          const t=document.querySelector('#storage-alert .sa-txt').textContent;
          localStorage.setItem=real; hideStorageAlert(); storageOK=true;
          return /navigation privée|bloqué/.test(t);
        }"""))

    # ── 2. bibliothèque ──
    chk('un cours existe au démarrage', page.evaluate("() => LIB.docs.length") == 1)
    chk('le cours courant est bien stocké',
        page.evaluate("async () => !!LIB.cur && (await docGet(LIB.cur)) !== null"))
    page.evaluate("""() => { ED.innerHTML='<h1>Cours A</h1><p>Contenu A</p>';
      document.getElementById('doc-title').textContent='Cours A'; saveDoc(false); }""")
    page.evaluate("() => libNew()")
    page.wait_for_timeout(200)
    chk('nouveau cours créé', page.evaluate("() => LIB.docs.length") == 2)
    chk('le nouveau cours part de la page par défaut',
        'Bienvenue' in page.evaluate("() => ED.textContent"))
    page.evaluate("""() => { ED.innerHTML='<h1>Cours B</h1><p>Contenu B</p>';
      document.getElementById('doc-title').textContent='Cours B'; saveDoc(false); }""")
    first = page.evaluate("() => LIB.docs[0].id")
    page.evaluate("(id) => libOpen(id)", first)
    page.wait_for_timeout(250)
    chk('retour au premier cours', 'Contenu A' in page.evaluate("() => ED.textContent"))
    chk('le titre suit le cours',
        page.evaluate("() => document.getElementById('doc-title').textContent") == 'Cours A')
    chk('le second cours est intact',
        'Contenu B' in (page.evaluate("async (id) => await docGet(id)",
                                      page.evaluate("() => LIB.docs[1].id")) or ''))
    chk('aucun mélange de contenu',
        'Contenu B' not in page.evaluate("() => ED.textContent"))
    page.evaluate("() => libDup(LIB.cur)")
    chk('duplication', page.evaluate("() => LIB.docs.length") == 3)
    chk('la copie est nommée', '(copie)' in page.evaluate("() => LIB.docs.map(d=>d.title).join('|')"))
    page.evaluate("() => libRename(LIB.docs[2].id,'Chapitre 3')")
    chk('renommage', 'Chapitre 3' in page.evaluate("() => LIB.docs.map(d=>d.title).join('|')"))
    # suppression en deux temps
    page.evaluate("() => openLib()")
    page.wait_for_timeout(150)
    page.evaluate("""() => { const b=[...document.querySelectorAll('.lib-b.lib-del')][2]; b.click(); }""")
    chk('premier clic : demande de confirmation',
        page.evaluate("() => LIB.docs.length") == 3
        and page.evaluate("() => !!document.querySelector('.lib-b.armed')"))
    page.evaluate("""() => { document.querySelector('.lib-b.armed').click(); }""")
    chk('second clic : suppression', page.evaluate("() => LIB.docs.length") == 2)
    chk('le contenu supprimé est effacé du stockage',
        page.evaluate("""async () => {
          const ids = LIB.docs.map(d => d.id);
          const restants = await new Promise(res => {
            const st = DB.transaction('docs','readonly').objectStore('docs');
            const rq = st.getAllKeys();
            rq.onsuccess = () => res(rq.result.filter(k => k !== '__backup__'));
            rq.onerror = () => res([]);
          });
          return restants.every(k => ids.indexOf(k) >= 0);
        }"""))
    # dernier cours indéboulonnable
    page.evaluate("""async () => {
      while (LIB.docs.length > 1) {
        const id = LIB.docs.find(d => d.id !== LIB.cur).id;
        libArmed = id;
        await libAskDel(document.createElement('button'), id);
      }
      libArmed = LIB.cur;
      await libAskDel(document.createElement('button'), LIB.cur);
    }""")
    chk('le dernier cours ne peut pas être supprimé',
        page.evaluate("() => LIB.docs.length") == 1)
    chk('indicateur d\'espace affiché',
        'utilisés' in page.evaluate("() => { renderLib(); return document.getElementById('lib-usage').textContent; }"))
    chk('aucune erreur JS', not page.errors, page.errors[:3])
print('\n%d PASS / %d FAIL' % (P,F))
