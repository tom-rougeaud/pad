# -*- coding: utf-8 -*-
"""Audit : que voit-on à l'impression qui ne devrait pas y être,
et qu'est-ce qui change d'aspect entre l'écran et le PDF ?"""
from harness import open_app

DOC = """() => {
  ED.innerHTML = '<h1>Tous les blocs</h1><p>Un paragraphe avec du <strong>gras</strong>.</p>';
  const caret = el => { const r = document.createRange(); r.selectNodeContents(el); r.collapse(false);
    const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange(); };
  caret(ED.querySelector('p'));
  insColorZone();
  ED.querySelector('.czone-body').textContent = 'Zone colorée bleue.';
  const last = () => { const p = document.createElement('p'); p.innerHTML = '<br>'; ED.appendChild(p); caret(p); };
  last(); insCallout('def', '📘', 'Définition');
  last(); insExo();
  last(); insMathBlock('a^2 + b^2 = c^2', 'Pythagore');
  last();
  document.getElementById('tbl-r').value = 2; document.getElementById('tbl-c').value = 2;
  document.getElementById('tbl-h').checked = true; confirmTbl();
  last();
  document.getElementById('qcm-nq').value = 1; document.getElementById('qcm-na').value = 2;
  insQCM();
  ED.querySelector('.qcm-q-text').textContent = 'Question ?';
  ED.querySelectorAll('.qcm-cell').forEach((c, i) => c.textContent = 'Réponse ' + (i+1));
  ED.querySelector('.qcm-box').click();
  paginate();
  return true;
}"""

VISIBLE = """() => {
  const out = [];
  const walk = el => {
    const s = getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity) === 0) return;
    const r = el.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) {
      const cls = (el.className && String(el.className)) || '';
      if (cls) out.push(el.tagName.toLowerCase() + '.' + cls.split(/\\s+/).join('.'));
    }
    [...el.children].forEach(walk);
  };
  walk(ED);
  return out;
}"""

BG = """() => {
  const pick = sel => {
    const el = ED.querySelector(sel);
    if (!el) return null;
    const s = getComputedStyle(el);
    return {bg: s.backgroundColor, bd: s.borderLeftColor, bw: s.borderLeftWidth};
  };
  return {
    czone: pick('.czone'), callout: pick('.callout'), exo: pick('.exo-block'),
    md: pick('.md'), qcmq: pick('.qcm-q'), qcmhead: pick('.qcm-head'),
    th: pick('table th'),
  };
}"""

with open_app() as page:
    page.evaluate(DOC)
    page.wait_for_timeout(400)
    screen = page.evaluate(VISIBLE)
    bg_screen = page.evaluate(BG)

    page.evaluate("() => { window.__r = preparePrint(true); }")
    page.emulate_media(media='print')
    page.wait_for_timeout(300)
    printed = page.evaluate(VISIBLE)
    bg_print = page.evaluate(BG)

    CHROME = ('czone-bar', 'cz-sw', 'exo-btn', 'exo-corr-toggle', 'qcm-btn', 'qcm-mini',
              'qcm-trash', 'qcm-corr-toggle', 'zone-hint', 'col-resizer', 'ss-fill',
              'md-lh', 'pg-tools', 'pg-num', 'qcm-foot', 'qcm-check', 'qcm-q-tools',
              'qcm-head-right', 'exo-badge')
    leaks = sorted({p for p in printed if any(c in p for c in CHROME)})
    print('── Éléments d\'interface encore visibles à l\'impression ──')
    for l in leaks or ['(aucun)']:
        print('  ', l)

    print('\n── Fonds et bordures : écran → impression ──')
    for k in bg_screen:
        a, b = bg_screen[k], bg_print[k]
        flag = '' if a == b else '   ⚠ DIFFÉRENT'
        print('  %-9s écran %s | impr %s%s' % (k, a, b, flag))

    only_print = sorted(set(printed) - set(screen))
    print('\n── Apparu uniquement à l\'impression ──')
    for x in only_print or ['(aucun)']:
        print('  ', x)
