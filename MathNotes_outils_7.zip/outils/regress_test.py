# -*- coding: utf-8 -*-
"""Non-régression : toutes les fonctions historiques doivent rester intactes."""
import re, pathlib, tempfile
from harness import open_app

P = F = 0
def chk(label, cond, extra=''):
    global P, F
    if cond: P += 1; print('PASS', label)
    else: F += 1; print('FAIL', label, repr(extra)[:200])

CARET = """(sel) => {
  const el = sel ? document.querySelector(sel) : (ED.querySelector('p') || ED);
  const r = document.createRange(); r.selectNodeContents(el); r.collapse(false);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
  el.focus && el.focus();
}"""

with open_app() as page:
    page.evaluate(CARET, None)

    # ── structure de départ ─────────────────────────────────
    chk('page A4 par défaut',
        abs(page.evaluate("() => ED.getBoundingClientRect().width") - 210 * 96 / 25.4) < 3)
    chk('page de départ : titre + texte d\'accueil',
        page.evaluate("() => !!ED.querySelector('h1') && /Bienvenue dans/.test(ED.textContent)"))

    # ── ruban : tous les boutons se cliquent sans erreur ────
    total = page.evaluate("""() => {
      let n = 0;
      document.querySelectorAll('.rbb,.vbb').forEach(b => {
        const code = b.getAttribute('onclick') || '';
        if (/askBlankSheet|loadProject|exportWeb|saveProject|window\\.print|doPrint/.test(code)) return;
        try { b.click(); n++; } catch (e) {}
      });
      document.querySelectorAll('.overlay.on').forEach(o => o.classList.remove('on'));
      return n;
    }""")
    chk('tous les boutons du ruban répondent (%d)' % total, total > 25 and not page.errors, page.errors[:3])

    # ── formules ────────────────────────────────────────────
    page.evaluate("() => { ED.innerHTML = '<p><br></p>'; }")
    page.evaluate(CARET, None)
    page.evaluate("() => insMathInline('\\\\frac{a}{b}')")
    chk('formule en ligne rendue',
        page.evaluate("() => { const m = ED.querySelector('.mx'); return !!m && !!m.querySelector('.katex'); }"))
    page.evaluate("() => insMathBlock('x^2 + y^2 = z^2', 'Pythagore')")
    chk('formule en bloc + titre',
        page.evaluate("() => ED.querySelector('.md').getAttribute('data-title')") == 'Pythagore')
    chk('caractère % accepté en LaTeX',
        page.evaluate("() => sanitizeLatex('50%')") == '50\\%')
    chk('TVA rendue',
        page.evaluate("""() => { const c = SC.find(x => x.c === 'tva');
          return /katex/.test(katex.renderToString(sanitizeLatex(c.l), {throwOnError:false})) && !/katex-error/.test(katex.renderToString(sanitizeLatex(c.l), {throwOnError:false})); }"""))

    # ── tableau ─────────────────────────────────────────────
    page.evaluate("() => { ED.innerHTML = '<p><br></p>'; }")
    page.evaluate(CARET, None)
    page.evaluate("""() => { document.getElementById('tbl-r').value = 3;
        document.getElementById('tbl-c').value = 3;
        document.getElementById('tbl-h').checked = true; confirmTbl(); }""")
    chk('tableau inséré', page.evaluate("() => ED.querySelectorAll('table').length") == 1)
    chk('colonnes en pourcentage, total 100 %',
        abs(page.evaluate("""() => [...ED.querySelectorAll('table colgroup col')]
            .reduce((s, c) => s + parseFloat(c.style.width), 0)""") - 100) < 0.5)
    chk('tableau dans la largeur de page',
        page.evaluate("""() => ED.querySelector('table').getBoundingClientRect().width
            <= ED.getBoundingClientRect().width + 1"""))
    chk('retour à la ligne dans une cellule',
        page.evaluate("""() => getComputedStyle(ED.querySelector('table td')).overflowWrap === 'anywhere'"""))

    # ── tableur ─────────────────────────────────────────────
    page.evaluate("() => { ED.innerHTML = '<p><br></p>'; }")
    page.evaluate(CARET, None)
    page.evaluate("""() => { document.getElementById('ss-r').value = 4;
        document.getElementById('ss-c').value = 4; confirmSS(); }""")
    sid = page.evaluate("() => ED.querySelector('.ss-wrap').dataset.sid")
    page.evaluate("""(sid) => {
      const cell = (r, c) => document.querySelector('.ss-wrap[data-sid="' + sid + '"] input[data-r="' + r + '"][data-c="' + c + '"]');
      cell(0,0).value = '12'; cell(0,0).dispatchEvent(new Event('input', {bubbles:true}));
      cell(1,0).value = '30'; cell(1,0).dispatchEvent(new Event('input', {bubbles:true}));
      cell(2,0).value = '=SOMME(A1:A2)'; cell(2,0).dispatchEvent(new Event('input', {bubbles:true}));
      cell(2,0).dispatchEvent(new Event('change', {bubbles:true}));
      recalc(sid);
    }""", sid)
    chk('tableur : =SOMME calcule',
        page.evaluate("""(sid) => document.querySelector('.ss-wrap[data-sid="' + sid + '"] input[data-r="2"][data-c="0"]').value""", sid) == '42')
    chk('tableur : séparateur ;',
        page.evaluate("""(sid) => {
          const cell = (r, c) => document.querySelector('.ss-wrap[data-sid="' + sid + '"] input[data-r="' + r + '"][data-c="' + c + '"]');
          cell(3,0).value = '=SOMME(1;2;3)'; cell(3,0).dispatchEvent(new Event('input', {bubbles:true}));
          recalc(sid); return cell(3,0).value; }""", sid) == '6')

    # ── exercice ────────────────────────────────────────────
    page.evaluate("() => { ED.innerHTML = '<p><br></p>'; }")
    page.evaluate(CARET, None)
    page.evaluate("() => insExo()")
    chk('exercice numéroté',
        'Exercice 1' in page.evaluate("() => ED.querySelector('.exo-label').textContent"))
    chk('numéro d\'exercice éditable',
        page.evaluate("() => ED.querySelector('.exo-label').getAttribute('contenteditable')") == 'true')
    page.evaluate("() => ED.querySelector('.exo-validate').click()")
    chk('validation ouvre la correction',
        page.evaluate("() => ED.querySelector('.exo-corr-wrap').style.display") != 'none')

    # ── liens ───────────────────────────────────────────────
    chk('lien sans schéma corrigé', page.evaluate("() => normalizeUrl('www.google.fr')") == 'https://www.google.fr')
    chk('adresse e-mail', page.evaluate("() => normalizeUrl('a@b.fr')") == 'mailto:a@b.fr')

    # ── titre et nom de fichier ─────────────────────────────
    chk('accents conservés dans le nom de fichier',
        page.evaluate("() => safeFileName('Proportionnalité — 2de')").startswith('Proportionnalité'))

    # ── pagination ──────────────────────────────────────────
    page.evaluate("""() => {
      ED.innerHTML = '';
      for (let i = 0; i < 160; i++) { const p = document.createElement('p'); p.textContent = 'Ligne ' + i; ED.appendChild(p); }
      paginate();
    }""")
    pages = page.evaluate("() => document.querySelectorAll('.pg-auto').length + 1")
    chk('pages multiples créées (%d)' % pages, pages >= 3)
    chk('aucun bloc coupé par une page',
        page.evaluate("""() => {
          const MM = 96/25.4, PAGE_H = 297*MM, PAD = 22*MM, PITCH = PAGE_H + 28;
          const base = ED.getBoundingClientRect().top + PAD;
          return [...ED.children].filter(e => !e.classList.contains('pg-auto')).every(e => {
            const r = e.getBoundingClientRect(), top = r.top - base;
            const p = Math.floor((top + 3) / PITCH);
            return top + r.height <= p*PITCH + PAGE_H - 2*PAD + 1;
          });
        }"""))

    # ── enregistrement / réouverture ────────────────────────
    page.evaluate("""() => {
      ED.innerHTML = '<p><br></p>';
      const p = ED.querySelector('p');
      const r = document.createRange(); r.selectNodeContents(p); r.collapse(true);
      const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
      document.getElementById('qcm-nq').value = 2; document.getElementById('qcm-na').value = 3;
      insQCM();
      ED.querySelectorAll('.qcm-box')[1].click();
      window.__saved = cleanHTML({});
    }""")
    page.evaluate("""() => {
      ED.innerHTML = window.__saved;
      migrateExoLabels(); bindExoLabel(ED); bindQcm(ED); reattachSheets(); 
    }""")
    chk('QCM survit à la réouverture',
        page.evaluate("() => ED.querySelectorAll('.qcm-q').length") == 2)
    chk('bonne réponse conservée',
        page.evaluate("""() => [...ED.querySelectorAll('.qcm-a')].filter(a => a.dataset.ok === '1').length""") == 1)
    chk('QCM rouvert : boutons de nouveau actifs',
        page.evaluate("""() => { ED.querySelector('.qcm-head-right .qcm-btn').click();
          return ED.querySelectorAll('.qcm-q').length === 3; }"""))
    chk('QCM rouvert : Entrée enchaîne les champs',
        page.evaluate("""() => { const t = ED.querySelector('.qcm-q-text'); focusInto(t);
          t.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter', bubbles:true, cancelable:true}));
          return document.activeElement.classList.contains('qcm-cell'); }"""))

    chk('aucune erreur JS sur l\'ensemble du parcours', not page.errors, page.errors[:5])

print('\n%d PASS / %d FAIL' % (P, F))
