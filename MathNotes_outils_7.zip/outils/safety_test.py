# -*- coding: utf-8 -*-
"""Feuille blanche réversible et verrou entre onglets."""
from harness import open_app
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:200])

with open_app() as page:
    # ── 3. feuille blanche ──
    page.evaluate("""() => { ED.innerHTML='<h1>Chapitre important</h1><p>Deux heures de travail.</p>';
      document.getElementById('doc-title').textContent='Chapitre important'; saveDoc(false); }""")
    chk('bouton Restaurer masqué tant qu\'il n\'y a rien à restaurer',
        page.evaluate("() => document.getElementById('btn-restore').style.display") == 'none')
    page.evaluate("() => blankSheet()")
    page.wait_for_timeout(200)
    chk('la feuille est bien vidée', 'Deux heures' not in page.evaluate("() => ED.textContent"))
    chk('une copie de secours existe', page.evaluate("() => hasBackup()"))
    chk('le message propose d\'annuler',
        page.evaluate("""() => { const t=document.getElementById('toast');
          return t.classList.contains('on') && /Annuler/.test(t.textContent); }"""))
    chk('bouton Restaurer apparu',
        page.evaluate("() => document.getElementById('btn-restore').style.display") != 'none')
    page.evaluate("() => document.querySelector('#toast .toast-act').click()")
    page.wait_for_timeout(200)
    chk('« Annuler » restaure le cours', 'Deux heures' in page.evaluate("() => ED.textContent"))
    chk('le titre est restauré',
        page.evaluate("() => document.getElementById('doc-title').textContent") == 'Chapitre important')
    chk('bouton Restaurer de nouveau masqué',
        page.evaluate("() => document.getElementById('btn-restore').style.display") == 'none')

    # la copie survit à un rechargement
    page.evaluate("() => { blankSheet(); }")
    page.wait_for_timeout(200)
    chk('la copie de secours est conservée',
        page.evaluate("async () => !!(await docGet(BACKUP_ID)) && hasBackup()"))
    page.reload(); page.wait_for_timeout(900)
    chk('après rechargement, le bouton Restaurer est offert',
        page.evaluate("() => document.getElementById('btn-restore').style.display") != 'none')
    page.evaluate("() => restoreBackup()")
    page.wait_for_timeout(200)
    chk('restauration après rechargement', 'Deux heures' in page.evaluate("() => ED.textContent"))

    # une feuille déjà vide ne crée pas de copie inutile
    page.evaluate("() => { lsDel('mn_backup'); ED.innerHTML='<p><br></p>'; blankSheet(); }")
    chk('pas de copie pour une feuille vide', not page.evaluate("() => hasBackup()"))

    # ── 5. verrou entre onglets ──
    chk('cet onglet détient le verrou', page.evaluate("() => lockIsMine()"))
    chk('éditeur modifiable', page.evaluate("() => ED.isContentEditable"))
    # un autre onglet réclame le cours
    page.evaluate("""() => { lsSet(lockKey(), JSON.stringify({id:'autre-onglet', ts:Date.now()})); }""")
    page.wait_for_timeout(2600)
    chk('passage automatique en lecture seule', page.evaluate("() => tabReadOnly"))
    chk('l\'éditeur n\'est plus modifiable', not page.evaluate("() => ED.isContentEditable"))
    chk('bandeau de lecture seule affiché',
        page.evaluate("() => document.getElementById('tab-alert').classList.contains('on')"))
    chk('un onglet spectateur n\'écrit pas', page.evaluate("() => saveDoc(false)") is False)
    # l'autre onglet écrit, puis on reprend la main
    page.evaluate("""async () => {
      await docPut(LIB.cur, '<h1>Écrit par l\\'autre onglet</h1>');
      delete DOC_CACHE[LIB.cur];
      await takeOver();
    }""")
    page.wait_for_timeout(200)
    chk('reprise de la main', page.evaluate("() => !tabReadOnly && ED.isContentEditable"))
    chk('le travail de l\'autre onglet est repris, pas écrasé',
        "autre onglet" in page.evaluate("() => ED.textContent"))
    chk('bandeau retiré',
        not page.evaluate("() => document.getElementById('tab-alert').classList.contains('on')"))
    # verrou périmé : on le récupère seul
    page.evaluate("""() => { lsSet(lockKey(), JSON.stringify({id:'fantome', ts:Date.now()-60000})); }""")
    page.wait_for_timeout(2600)
    chk('un verrou périmé ne bloque pas', page.evaluate("() => !tabReadOnly && lockIsMine()"))
    chk('aucune erreur JS', not page.errors, page.errors[:3])
print('\n%d PASS / %d FAIL' % (P,F))
