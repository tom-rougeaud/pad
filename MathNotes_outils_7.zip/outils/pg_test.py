# -*- coding: utf-8 -*-
"""Pagination : un long texte se poursuit page suivante, et rien ne se fige.

On vérifie des garanties visibles par l'utilisateur, pas des mécanismes :
aucune ligne de texte ne tombe dans le blanc entre deux pages, le texte reste
modifiable là où il a été coupé, ce qu'on enregistre ne contient aucun
espaceur, et le papier a le même nombre de pages que l'écran.
"""
import os
import re
import subprocess
import tempfile
from harness import open_app

ok = ko = 0


def t(nom, cond, detail=''):
    global ok, ko
    if cond:
        ok += 1
        print('  PASS  ' + nom)
    else:
        ko += 1
        print('  FAIL  ' + nom + ('   → ' + str(detail) if detail else ''))


LONG = ("Le taux de marge se calcule sur le cout d'achat alors que le taux de marque "
        "se calcule sur le prix de vente hors taxes, ce qui change le resultat. ")

# Toute ligne de texte doit tenir dans la zone imprimable de sa page.
LIGNES = """() => {
  const MM=96/25.4,PAGE_H=297*MM,PAD=22*MM,PITCH=PAGE_H+28,CH=PAGE_H-2*PAD-8;
  const base=ED.getBoundingClientRect().top+PAD;
  const dehors=[];let lignes=0;
  const w=document.createTreeWalker(ED,NodeFilter.SHOW_TEXT,null);let t;
  while((t=w.nextNode())){
    if(!t.nodeValue.trim())continue;
    if(t.parentNode.closest('#pg-overlay,.pg-tools,.zone-hint'))continue;
    const rg=document.createRange();rg.selectNodeContents(t);
    for(const r of rg.getClientRects()){
      if(!r.height)continue;lignes++;
      const top=r.top-base,bot=r.bottom-base;
      const p=Math.floor((top+3)/PITCH);
      if(bot>p*PITCH+CH+2)dehors.push({page:p+1,bas:Math.round(bot),
        limite:Math.round(p*PITCH+CH),texte:t.nodeValue.slice(0,30)});
    }
  }
  return {lignes:lignes,dehors:dehors.slice(0,4),nb:dehors.length};
}"""

POS = """(id) => {
  const MM=96/25.4,PITCH=297*MM+28,base=ED.getBoundingClientRect().top+22*MM;
  const r=document.getElementById(id).getBoundingClientRect();
  return Math.floor((r.top-base+3)/PITCH)+1;
}"""

with open_app() as page:
    print('\n── 1. UN LONG TEXTE COLLÉ SE POURSUIT PAGE SUIVANTE ──')
    page.evaluate("""(mots) => {
      ED.innerHTML='<h1>Pagination</h1><p id="lg">'+mots.repeat(120)+'</p><p id="fin">Fin.</p>';
      paginate();
    }""", LONG)
    page.wait_for_timeout(600)
    r = page.evaluate(LIGNES)
    t('le texte occupe plusieurs pages', page.evaluate('() => pgInfo.pages') >= 5,
      page.evaluate('() => pgInfo.pages'))
    t('aucune ligne ne tombe entre deux pages', r['nb'] == 0, r['dehors'])
    t('toutes les lignes sont présentes', r['lignes'] > 150, r['lignes'])
    t('le paragraphe reste un seul bloc',
      page.evaluate("() => ED.querySelectorAll('p#lg').length") == 1)
    t('le texte qui suit est bien après',
      page.evaluate(POS, 'fin') >= page.evaluate(POS, 'lg') + 4)

    print('\n── 2. LE TEXTE COUPÉ RESTE MODIFIABLE ──')
    avant = page.evaluate("() => document.getElementById('lg').textContent.length")
    page.evaluate("""() => {
      const p=document.getElementById('lg');
      const sp=p.querySelector('.pg-inline');
      const n=sp?sp.nextSibling:p.firstChild;
      const r=document.createRange();r.setStart(n,0);r.collapse(true);
      const s=getSelection();s.removeAllRanges();s.addRange(r);
      ED.focus();
    }""")
    page.keyboard.type('ZZZ')
    page.wait_for_timeout(500)
    txt = page.evaluate("() => document.getElementById('lg').textContent")
    t('la frappe arrive dans le paragraphe', 'ZZZ' in txt, txt[:40])
    t('rien n\'a été perdu', len(txt) == avant + 3, (len(txt), avant))
    r = page.evaluate(LIGNES)
    t('après frappe, aucune ligne dans le blanc', r['nb'] == 0, r['dehors'])

    print('\n── 3. CE QUI EST ENREGISTRÉ NE CONTIENT AUCUN ESPACEUR ──')
    body = page.evaluate("() => cleanHTML()")
    t('pas d\'espaceur de page enregistré', 'pg-auto' not in body)
    t('pas d\'espaceur en ligne enregistré', 'pg-inline' not in body)
    t('le texte, lui, est bien enregistré', body.count('taux de marque') > 100,
      body.count('taux de marque'))
    exp = page.evaluate("() => cleanHTML({export:true})")
    t('l\'export non plus n\'emporte d\'espaceur', 'pg-inline' not in exp)

    print('\n── 4. UN BLOC RACCOURCI REMONTE ──')
    page.evaluate("""() => {
      ED.innerHTML='';
      for(let i=0;i<40;i++){const p=document.createElement('p');
        p.textContent='Ligne '+i+' de contenu ordinaire pour remplir la page.';ED.appendChild(p);}
      const c=document.createElement('p');c.id='cible';
      c.textContent='CIBLE '+'mot '.repeat(400);ED.appendChild(c);
      paginate();
    }""")
    page.wait_for_timeout(500)
    p_av = page.evaluate(POS, 'cible')
    page.evaluate("""() => {document.getElementById('cible').textContent='CIBLE court';paginate();}""")
    page.wait_for_timeout(500)
    p_ap = page.evaluate(POS, 'cible')
    t('le bloc raccourci remonte', p_ap < p_av, (p_av, p_ap))
    t('aucun saut de page n\'a été inventé',
      page.evaluate("() => ED.querySelectorAll('.pg-manual').length") == 0)

    print('\n── 5. LES OUTILS DE PAGE NE FIGENT PLUS LA MISE EN PAGE ──')
    page.evaluate("""() => {
      ED.innerHTML='';
      for(let i=0;i<40;i++){const p=document.createElement('p');
        p.textContent='Ligne '+i+' de contenu ordinaire pour remplir la page.';ED.appendChild(p);}
      const c=document.createElement('p');c.id='cible';
      c.textContent='CIBLE '+'mot '.repeat(400);ED.appendChild(c);
      paginate();
    }""")
    page.wait_for_timeout(500)
    base_pg = page.evaluate(POS, 'cible')
    page.evaluate("() => pageOp('ins',0)")
    page.wait_for_timeout(700)
    apres_ins = page.evaluate(POS, 'cible')
    sauts = page.evaluate("() => ED.querySelectorAll('.pg-manual').length")
    t('la page vierge décale bien la suite', apres_ins == base_pg + 1, (base_pg, apres_ins))
    t('la page vierge ne coûte que ses deux bornes', sauts <= 2, sauts)
    page.evaluate("""() => {document.getElementById('cible').textContent='CIBLE court';paginate();}""")
    page.wait_for_timeout(600)
    t('après une opération de page, le texte circule encore',
      page.evaluate(POS, 'cible') < apres_ins, page.evaluate(POS, 'cible'))

    print('\n── 6. DÉPLACER ET SUPPRIMER N\'AJOUTENT PAS DE SAUTS ──')
    page.evaluate("""() => {
      ED.innerHTML='';
      for(let i=0;i<70;i++){const p=document.createElement('p');
        p.textContent='Ligne '+i+' de contenu ordinaire pour remplir la page.';ED.appendChild(p);}
      paginate();
    }""")
    page.wait_for_timeout(500)
    page.on('dialog', lambda d: d.accept())
    n0 = page.evaluate("() => pgInfo.pages")
    par0 = page.evaluate("() => ED.querySelectorAll('p').length")
    page.evaluate("() => pageOp('down',0)")
    page.wait_for_timeout(700)
    t('descendre une page ne fige rien',
      page.evaluate("() => ED.querySelectorAll('.pg-manual').length") == 0)
    t('descendre une page change bien l\'ordre',
      not page.evaluate("() => ED.querySelector('p').textContent").startswith('Ligne 0 '),
      page.evaluate("() => ED.querySelector('p').textContent"))
    t('descendre une page ne perd aucun paragraphe',
      page.evaluate("() => ED.querySelectorAll('p').length") == par0)
    page.evaluate("() => pageOp('del',0)")
    page.wait_for_timeout(700)
    t('supprimer une page ne fige rien',
      page.evaluate("() => ED.querySelectorAll('.pg-manual').length") == 0)
    t('supprimer une page en retire bien le contenu',
      page.evaluate("() => ED.querySelectorAll('p').length") < par0,
      (par0, page.evaluate("() => ED.querySelectorAll('p').length")))
    t('supprimer une page en retire bien une',
      page.evaluate("() => pgInfo.pages") < n0,
      (n0, page.evaluate("() => pgInfo.pages")))

    print('\n── 6 bis. UN SAUT VOULU S\'ENLÈVE AU RETOUR ARRIÈRE ──')
    page.evaluate("""() => {
      ED.innerHTML='<p id="a">Avant le saut.</p><div class="pg-manual" contenteditable="false"></div>'
        +'<p id="b">Après le saut.</p>';
      reattach();paginate();
    }""")
    page.wait_for_timeout(500)
    t('le saut voulu envoie bien la suite page 2', page.evaluate(POS, 'b') == 2,
      page.evaluate(POS, 'b'))
    page.evaluate("""() => {
      const p=document.getElementById('b');
      const r=document.createRange();r.setStart(p.firstChild,0);r.collapse(true);
      const s=getSelection();s.removeAllRanges();s.addRange(r);ED.focus();
    }""")
    page.keyboard.press('Backspace')
    page.wait_for_timeout(600)
    t('le retour arrière retire le saut voulu',
      page.evaluate("() => ED.querySelectorAll('.pg-manual').length") == 0)
    t('le texte est remonté page 1', page.evaluate(POS, 'b') == 1, page.evaluate(POS, 'b'))
    t('le texte lui-même est intact',
      page.evaluate("() => document.getElementById('b').textContent") == 'Après le saut.')

    print('\n── 7. LES ÉLÉMENTS INSÉRÉS SURVIVENT À LA COUPURE ──')
    page.evaluate("""(mots) => {
      ED.innerHTML='<p id="mix">'+mots.repeat(40)
        +'<span class="mn-icon">📐</span>'+mots.repeat(40)
        +'<span class="comp" data-c="rea" data-v="i" contenteditable="false" style="background:#27AE60;">'
        +'<svg viewBox="0 0 16 16"></svg></span>'+mots.repeat(40)+'</p>';
      paginate();
    }""", LONG)
    page.wait_for_timeout(600)
    t('l\'icône est toujours là',
      page.evaluate("() => ED.querySelectorAll('.mn-icon').length") == 1)
    t('la pastille de compétence est toujours là',
      page.evaluate("() => ED.querySelectorAll('.comp').length") == 1)
    r = page.evaluate(LIGNES)
    t('texte mêlé : aucune ligne dans le blanc', r['nb'] == 0, r['dehors'])

    print('\n── 8. UN BLOC INSÉCABLE N\'EST PAS ABÎMÉ ──')
    page.evaluate("""() => {
      let t='<table class="mn-table">';
      for(let i=0;i<80;i++)t+='<tr><td>Ligne '+i+'</td><td>valeur</td></tr>';
      ED.innerHTML=t+'</table><p id="apres">Suite.</p>';
      paginate();
    }""")
    page.wait_for_timeout(600)
    t('le tableau garde toutes ses lignes',
      page.evaluate("() => ED.querySelectorAll('tr').length") == 80)
    t('aucun espaceur n\'a été glissé dans le tableau',
      page.evaluate("() => ED.querySelectorAll('table .pg-inline').length") == 0)
    t('la suite est bien après le tableau',
      page.evaluate("() => document.getElementById('apres').getBoundingClientRect().top > "
                    "document.querySelector('table').getBoundingClientRect().bottom - 2"))

    print('\n── 9. ANNULER REVIENT À L\'ÉTAT D\'AVANT ──')
    page.evaluate("""(mots) => {
      ED.innerHTML='<p id="u">'+mots.repeat(120)+'</p>';
      paginate();hist=[cleanHTML()];histIdx=0;
    }""", LONG)
    page.wait_for_timeout(500)
    page.evaluate("""() => {
      const p=document.getElementById('u');
      const r=document.createRange();r.setStart(p.firstChild,0);r.collapse(true);
      const s=getSelection();s.removeAllRanges();s.addRange(r);ED.focus();
    }""")
    page.keyboard.type('QQQ')
    page.wait_for_timeout(700)
    page.evaluate("() => doUndo()")
    page.wait_for_timeout(600)
    t('l\'annulation retire bien la frappe',
      'QQQ' not in page.evaluate("() => ED.textContent"))
    t('aucun espaceur n\'a été réinjecté par l\'historique',
      'pg-inline' not in page.evaluate("() => hist[histIdx]"))
    r = page.evaluate(LIGNES)
    t('après annulation, aucune ligne dans le blanc', r['nb'] == 0, r['dehors'])

    print('\n── 10. LE PAPIER A LE MÊME NOMBRE DE PAGES QUE L\'ÉCRAN ──')
    page.evaluate("""(mots) => {
      ED.innerHTML='<h1>Marges et marques</h1><p>'+mots.repeat(150)+'</p>';
      paginate();
    }""", LONG)
    page.wait_for_timeout(700)
    ecran = page.evaluate("() => pgInfo.pages")
    pdf = os.path.join(tempfile.gettempdir(), 'pg_test.pdf')
    page.evaluate("() => document.body.classList.add('printing')")
    page.pdf(path=pdf, format='A4', print_background=True,
             margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
    page.evaluate("() => document.body.classList.remove('printing')")
    info = subprocess.run(['pdfinfo', pdf], capture_output=True, text=True).stdout
    m = re.search(r'Pages:\s+(\d+)', info)
    papier = int(m.group(1)) if m else -1
    t('même nombre de pages à l\'écran et sur le papier', papier == ecran, (ecran, papier))
    txt = subprocess.run(['pdftotext', pdf, '-'], capture_output=True, text=True).stdout
    plat = re.sub(r'\s+', ' ', txt)
    t('le texte est entièrement imprimé',
      plat.count('taux de marque') == 150, plat.count('taux de marque'))

    print('\nerreurs de console :', page.errors[:3] or 'aucune')
    t('aucune erreur de console', not page.errors, page.errors[:2])

print('\n%d PASS / %d FAIL' % (ok, ko))
raise SystemExit(1 if ko else 0)
