# -*- coding: utf-8 -*-
"""Extrait le script principal de l'application pour l'analyser."""
import re
src = open('MathNotes.html', encoding='utf-8').read()
blocs = re.findall(r'<script>([\s\S]*?)</script>', src)
blocs = [b for b in blocs if 'function paginateCore' in b or len(b) > 50000]
open('_app.js', 'w', encoding='utf-8').write('\n'.join(blocs))
print('%d bloc(s), %d caractères' % (len(blocs), sum(len(b) for b in blocs)))
