# -*- coding: utf-8 -*-
"""Construit MathNotes_Guide.html à partir du Tuto de MathNotes.html.
Le guide ne peut donc jamais diverger de l'application."""
import re, datetime
from bs4 import BeautifulSoup

soup = BeautifulSoup(open('MathNotes.html', encoding='utf-8').read(), 'html.parser')
tuto = soup.find(id='page-tuto')
assert tuto, 'page Tuto introuvable'

def clean(tag):
    """Enlève tout ce qui n'a de sens que dans l'application."""
    for el in tag.find_all(True):
        for a in ('onclick', 'oninput', 'onchange', 'contenteditable', 'spellcheck', 'data-tip'):
            if el.has_attr(a):
                del el[a]
    return tag

# ── raccourcis clavier ──────────────────────────────────────
keys = []
cols = tuto.find('div', class_='tuto-cols')
for block in cols.find_all('div', recursive=False):
    sub = block.find('div', class_='tuto-sub')
    rows = []
    for tr in block.find_all('tr'):
        td = tr.find_all('td')
        if len(td) == 2:
            rows.append((td[0].decode_contents(), td[1].decode_contents()))
    keys.append((sub.get_text(strip=True), rows))

# ── fonctionnalités : thèmes + accordéons ───────────────────
themes, cur = [], None
node = tuto.find('div', class_='page-sec', id='tuto-feat')
for el in node.find_next_siblings():
    if el.get('class') and 'faq-zone' in el['class']:
        break
    cls = el.get('class') or []
    if 'tuto-theme' in cls:
        cur = {'title': el.get_text(' ', strip=True), 'items': []}
        themes.append(cur)
    elif 'acc' in cls and cur is not None:
        h = el.find('button', class_='acc-h')
        c = el.find('div', class_='acc-c')
        cur['items'].append((h.get_text(' ', strip=True).rstrip('▸ ').strip(),
                             clean(c).decode_contents()))

# ── FAQ ─────────────────────────────────────────────────────
faq, fcur = [], None
for el in tuto.find(id='tuto-faq').find_all(recursive=False):
    cls = el.get('class') or []
    if 'faq-cat' in cls:
        fcur = {'title': el.get_text(' ', strip=True), 'items': []}
        faq.append(fcur)
    elif 'acc' in cls and fcur is not None:
        h = el.find('button', class_='acc-h')
        c = el.find('div', class_='acc-c')
        fcur['items'].append((h.get_text(' ', strip=True).rstrip('▸ ').strip(),
                              clean(c).decode_contents()))

n_items = sum(len(t['items']) for t in themes)
n_faq = sum(len(f['items']) for f in faq)

# ── quelques chiffres tirés de l'application elle-même ──────
src = open('MathNotes.html', encoding='utf-8').read()
n_tpl = len(re.findall(r'\{name:"', src))
n_chap = len(re.findall(r'^  "[^"]+":\[$', src, re.M))
n_sc = len(re.findall(r"\{c:'", src)) + len(re.findall(r'\{c:"', src))

BREF = [
    ('📄', 'Page A4 fidèle', "Ce que vous voyez à l'écran est exactement ce qui sortira sur le papier : même pagination, mêmes coupures, jamais un tableau ni une formule coupés en deux."),
    ('∫', 'Formules sans LaTeX', "Une barre oblique et un mot suffisent. Un clic sélectionne une formule, deux modifient une valeur, trois ouvrent l'éditeur complet."),
    ('📚', '%d modèles, %d chapitres' % (n_tpl, n_chap), "Du calcul numérique à l'analyse, avec trois chapitres tournés vers le métier : calculs commerciaux, fixation des prix, finance et paie."),
    ('💡', 'Exemples prêts à l\'emploi', "Chaque modèle propose une application chiffrée et une situation professionnelle, insérées en un clic et entièrement modifiables."),
    ('☑️', 'QCM avec correction', "Questions à choix unique ou multiple, bonnes réponses masquables, version élève et version professeur, et un QCM interactif dans la page web exportée."),
    ('📝', 'Exercices et corrigés', "Un bloc par exercice, numéroté automatiquement, dont la correction se replie pour l'élève et se déplie pour vous."),
    ('⊞', 'Tableaux et tableur', "Largeurs de colonnes ajustables, retour à la ligne automatique, formules de calcul et recopie par glissement."),
    ('🖨', 'PDF et page web', "Deux versions en un clic, élève ou professeur. La page web s'ouvre sur n'importe quel ordinateur, sans rien installer."),
]

STEPS = [
    ("Écrire le cours", "Tapez directement dans la page. Le ruban du haut reprend les commandes d'un traitement de texte, et les raccourcis habituels fonctionnent."),
    ("Poser une formule", "Tapez <span class=\"kbd\">/</span> suivi d'un mot — <span class=\"kbd\">/tva</span>, <span class=\"kbd\">/pythagore</span>, <span class=\"kbd\">/marge</span> — ou <span class=\"kbd\">Ctrl</span> + <span class=\"kbd\">/</span> pour écrire au fil du texte."),
    ("Illustrer", "Le panneau de droite réunit symboles, modèles, fonctions et calculatrice. Sur un modèle, <strong>💡 Exemple</strong> et <strong>🏭 Situation pro</strong> insèrent un cas chiffré modifiable."),
    ("Évaluer", "Le bouton <strong>☑️ QCM</strong> crée un questionnaire ; <strong>📝 Exercice</strong> crée un énoncé avec sa correction repliable."),
    ("Distribuer", "<strong>🖨 Imprimer</strong> produit la version élève ou la version professeur. <strong>Page Web</strong> produit un fichier autonome où l'élève peut répondre au QCM et voir son score."),
]

def acc(idx, title, body, kind=''):
    return ('<div class="acc %s" data-i="%d">'
            '<button class="acc-h" type="button"><span class="acc-t">%s</span><span class="acc-ar">▸</span></button>'
            '<div class="acc-c">%s</div></div>') % (kind, idx, title, body)

parts = []
i = 0
for t in themes:
    parts.append('<h3 class="theme">%s</h3>' % t['title'])
    for title, body in t['items']:
        parts.append(acc(i, title, body)); i += 1
themes_html = '\n'.join(parts)

parts = []
for f in faq:
    parts.append('<h3 class="fcat">%s</h3>' % f['title'])
    for title, body in f['items']:
        parts.append(acc(i, title, body, 'faq')); i += 1
faq_html = '\n'.join(parts)

keys_html = ''
for sub, rows in keys:
    keys_html += '<div class="ktable"><h4>%s</h4><table>' % sub
    for a, b in rows:
        keys_html += '<tr><td class="kc">%s</td><td>%s</td></tr>' % (a, b)
    keys_html += '</table></div>'

bref_html = ''.join(
    '<div class="card"><div class="card-ic">%s</div><div class="card-t">%s</div>'
    '<div class="card-d">%s</div></div>' % c for c in BREF)

steps_html = ''.join(
    '<li><span class="stp-n">%d</span><span class="stp-t">%s</span>'
    '<span class="stp-d">%s</span></li>' % (n + 1, t, d) for n, (t, d) in enumerate(STEPS))

DATE = datetime.date.today().strftime('%d/%m/%Y')
FAVICON = ("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E"
           "%3Crect width='32' height='32' rx='6' fill='%2327AE60'/%3E%3Ctext x='50%25' y='53%25' "
           "dominant-baseline='middle' text-anchor='middle' font-size='21' fill='white' "
           "font-family='Georgia,serif' font-weight='bold'%3E%CE%A3%3C/text%3E%3C/svg%3E")

HTML = f"""<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MathNotes — Guide complet</title>
<link rel="icon" type="image/svg+xml" href="{FAVICON}">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&family=Lora:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{{--t1:#1A1A2E;--t2:#6B7280;--acc:#2F80ED;--grn:#27AE60;--pur:#7C3AED;--tea:#0D9488;
--bdr:#E3E1DA;--bg:#F5F2EA;--card:#FFFFFF;}}
*{{box-sizing:border-box;}}
body{{margin:0;background:var(--bg);color:var(--t1);font-family:'DM Sans',system-ui,sans-serif;
font-size:15px;line-height:1.68;-webkit-print-color-adjust:exact;print-color-adjust:exact;}}
.wrap{{max-width:940px;margin:0 auto;padding:0 26px 70px;}}
.hero{{background:linear-gradient(135deg,#1A1A2E 0%,#2F3B63 55%,#0D9488 100%);color:#fff;
padding:54px 26px 46px;margin-bottom:34px;}}
.hero-in{{max-width:940px;margin:0 auto;}}
.logo{{width:46px;height:46px;border-radius:11px;background:var(--grn);color:#fff;font-family:Georgia,serif;
font-weight:700;font-size:29px;display:flex;align-items:center;justify-content:center;margin-bottom:17px;}}
.hero h1{{font-family:Lora,Georgia,serif;font-size:39px;margin:0 0 9px;line-height:1.15;}}
.hero p{{margin:0;font-size:16.5px;opacity:.9;max-width:660px;}}
.hero .meta{{margin-top:19px;font-size:12.5px;opacity:.72;}}
h2.sec{{font-family:Lora,Georgia,serif;font-size:25px;margin:46px 0 6px;
padding-bottom:9px;border-bottom:2px solid var(--bdr);}}
h2.sec .n{{color:var(--acc);}}
.lead{{color:var(--t2);font-size:14px;margin:0 0 20px;}}
.cards{{display:grid;grid-template-columns:repeat(auto-fill,minmax(248px,1fr));gap:13px;}}
.card{{background:var(--card);border:1px solid var(--bdr);border-radius:12px;padding:16px 17px;
break-inside:avoid;page-break-inside:avoid;}}
.card-ic{{font-size:21px;line-height:1;margin-bottom:9px;}}
.card-t{{font-weight:700;font-size:14.5px;margin-bottom:5px;}}
.card-d{{font-size:13px;color:var(--t2);line-height:1.6;}}
ol.steps{{list-style:none;padding:0;margin:0;counter-reset:s;}}
ol.steps li{{background:var(--card);border:1px solid var(--bdr);border-left:4px solid var(--acc);
border-radius:11px;padding:14px 17px 14px 56px;margin-bottom:10px;position:relative;
break-inside:avoid;page-break-inside:avoid;}}
.stp-n{{position:absolute;left:15px;top:14px;width:26px;height:26px;border-radius:50%;
background:var(--acc);color:#fff;font-weight:700;font-size:13px;display:flex;
align-items:center;justify-content:center;}}
.stp-t{{display:block;font-weight:700;font-size:14.5px;margin-bottom:3px;}}
.stp-d{{display:block;font-size:13.5px;color:var(--t2);}}
.keys{{display:grid;grid-template-columns:1fr 1fr;gap:17px;}}
.ktable{{background:var(--card);border:1px solid var(--bdr);border-radius:12px;padding:14px 16px;
break-inside:avoid;page-break-inside:avoid;}}
.ktable h4{{margin:0 0 9px;font-size:12px;text-transform:uppercase;letter-spacing:.07em;color:var(--t2);}}
.ktable table{{width:100%;border-collapse:collapse;font-size:13px;}}
.ktable td{{padding:5px 3px;border-bottom:1px solid #F0EEE7;vertical-align:top;}}
.ktable tr:last-child td{{border-bottom:none;}}
.kc{{white-space:nowrap;width:41%;}}
.kbd{{display:inline-block;font-family:'DM Mono',monospace;font-size:11.5px;background:#EEF2F7;
border:1px solid #D7DEE8;border-bottom-width:2px;border-radius:5px;padding:1px 6px;color:#31405B;}}
h3.theme{{font-size:16.5px;margin:26px 0 10px;display:flex;align-items:center;gap:9px;}}
h3.fcat{{font-size:12px;text-transform:uppercase;letter-spacing:.07em;color:var(--pur);
margin:24px 0 9px;font-weight:700;}}
.acc{{background:var(--card);border:1px solid var(--bdr);border-radius:11px;margin-bottom:7px;
overflow:hidden;break-inside:avoid;page-break-inside:avoid;}}
.acc-h{{width:100%;text-align:left;background:transparent;border:none;padding:11px 15px;
font-size:14px;font-weight:600;color:var(--t1);display:flex;align-items:center;gap:9px;
cursor:pointer;font-family:inherit;}}
.acc-h:hover{{background:#F4F7FC;}}
.acc-t{{flex:1;}}
.acc-ar{{color:var(--t2);font-size:11px;transition:transform .15s;}}
.acc.open .acc-ar{{transform:rotate(90deg);}}
.acc-c{{display:none;padding:0 17px 14px;font-size:13.7px;color:#33384A;}}
.acc.open .acc-c{{display:block;}}
.acc-c ul{{margin:0;padding-left:19px;}}
.acc-c li{{margin-bottom:5px;}}
.acc-c p{{margin:0 0 7px;}}
.acc.faq{{border-color:rgba(124,58,237,.22);}}
.acc.faq .acc-h:hover{{background:rgba(124,58,237,.06);}}
.tools{{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin:20px 0 4px;}}
.tools input{{flex:1;min-width:210px;padding:9px 13px;border:1px solid var(--bdr);border-radius:9px;
font-family:inherit;font-size:14px;background:var(--card);}}
.tools button{{padding:9px 15px;border:1px solid var(--bdr);background:var(--card);border-radius:9px;
font-family:inherit;font-size:13px;font-weight:600;cursor:pointer;}}
.none{{display:none!important;}}
footer{{margin-top:54px;padding-top:22px;border-top:1px solid var(--bdr);font-size:12.5px;color:var(--t2);}}
footer a{{color:var(--acc);}}
@media (max-width:760px){{.keys{{grid-template-columns:1fr;}}.hero h1{{font-size:30px;}}}}
@media print{{
  body{{background:#fff;font-size:11.2pt;}}
  .tools,.acc-ar{{display:none!important;}}
  .hero{{padding:30px 0 26px;margin-bottom:22px;}}
  .wrap{{max-width:none;padding:0;}}
  .acc-c{{display:block!important;}}
  .acc{{break-inside:avoid;page-break-inside:avoid;}}
  h2.sec{{break-after:avoid;page-break-after:avoid;}}
  h3.theme,h3.fcat{{break-after:avoid;page-break-after:avoid;}}
  @page{{size:A4;margin:14mm 13mm 16mm;}}
}}
</style></head><body>

<div class="hero"><div class="hero-in">
  <div class="logo">Σ</div>
  <h1>MathNotes — Guide complet</h1>
  <p>Écrire, illustrer et évaluer un cours de mathématiques de lycée professionnel, puis le distribuer en PDF ou en page web.</p>
  <div class="meta">{n_items} fiches · {n_faq} questions fréquentes · {n_tpl} modèles · {n_sc} commandes — mis à jour le {DATE}</div>
</div></div>

<div class="wrap">

<h2 class="sec"><span class="n">1.</span> En bref</h2>
<p class="lead">Ce que MathNotes fait, en huit points.</p>
<div class="cards">{bref_html}</div>

<h2 class="sec"><span class="n">2.</span> Premiers pas</h2>
<p class="lead">Un cours complet, de la première ligne à la distribution.</p>
<ol class="steps">{steps_html}</ol>

<h2 class="sec"><span class="n">3.</span> Raccourcis clavier</h2>
<p class="lead">Les habitudes d'un traitement de texte, plus ce qui est propre à MathNotes.</p>
<div class="keys">{keys_html}</div>

<h2 class="sec"><span class="n">4.</span> Fonctionnalités par thème</h2>
<p class="lead">Cliquez un titre pour le déplier. À l'impression, tout est déplié.</p>
<div class="tools">
  <input id="q" type="search" placeholder="Rechercher dans le guide…" aria-label="Rechercher">
  <button type="button" id="all">Tout déplier</button>
  <button type="button" id="none">Tout replier</button>
</div>
{themes_html}

<h2 class="sec"><span class="n">5.</span> Questions fréquentes</h2>
<p class="lead">Les réponses aux questions qui reviennent le plus souvent.</p>
{faq_html}

<footer>
  MathNotes — éditeur de cours de mathématiques pour le lycée professionnel.
  Guide produit automatiquement à partir de l'onglet Tuto de l'application, le {DATE}.<br>
  Tom Rougeaud — <a href="https://www.linkedin.com/in/tomrougeaud/">LinkedIn</a> ·
  <a href="https://tom-rougeaud.github.io/casier/">Mon Casier Pédagogique Numérique</a>
</footer>
</div>

<script>
(function(){{
  var accs=[].slice.call(document.querySelectorAll('.acc'));
  accs.forEach(function(a){{
    a.querySelector('.acc-h').addEventListener('click',function(){{a.classList.toggle('open');}});
  }});
  document.getElementById('all').addEventListener('click',function(){{
    accs.forEach(function(a){{a.classList.add('open');}});
  }});
  document.getElementById('none').addEventListener('click',function(){{
    accs.forEach(function(a){{a.classList.remove('open');}});
  }});
  var q=document.getElementById('q');
  q.addEventListener('input',function(){{
    var v=q.value.trim().toLowerCase();
    accs.forEach(function(a){{
      var hit=!v||a.textContent.toLowerCase().indexOf(v)>=0;
      a.classList.toggle('none',!hit);
      if(v&&hit)a.classList.add('open');
    }});
    [].forEach.call(document.querySelectorAll('h3.theme,h3.fcat'),function(h){{
      var any=false,n=h.nextElementSibling;
      while(n&&n.classList.contains('acc')){{if(!n.classList.contains('none'))any=true;n=n.nextElementSibling;}}
      h.classList.toggle('none',!any);
    }});
  }});
}})();
</script>
</body></html>
"""

open('/mnt/user-data/outputs/MathNotes_Guide.html', 'w', encoding='utf-8').write(HTML)
print('Guide : %d fiches, %d questions, %d modèles, %d chapitres, %d commandes'
      % (n_items, n_faq, n_tpl, n_chap, n_sc))
