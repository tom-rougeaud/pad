# -*- coding: utf-8 -*-
"""QCM v2 : correction par question, corbeille, coupure de page, vérification orange."""
import re, pathlib, tempfile, subprocess
from harness import open_app

P = F = 0
def chk(label, cond, extra=''):
    global P, F
    if cond: P += 1; print('PASS', label)
    else: F += 1; print('FAIL', label, repr(extra)[:230])

MK = """([nq, na]) => {
  ED.innerHTML = '<p><br></p>';
  const p = ED.querySelector('p');
  const r = document.createRange(); r.selectNodeContents(p); r.collapse(true);
  const s = getSelection(); s.removeAllRanges(); s.addRange(r); SR = r.cloneRange();
  document.getElementById('qcm-nq').value = nq;
  document.getElementById('qcm-na').value = na;
  document.getElementById('qcm-multi').value = 'multi';
  insQCM();
  ED.querySelectorAll('.qcm-q').forEach((q, i) => {
    q.querySelector('.qcm-q-text').textContent = 'Question numéro ' + (i + 1) + ' du questionnaire';
    q.querySelectorAll('.qcm-cell').forEach((c, j) => c.textContent = 'Réponse ' + (j + 1));
    q.querySelectorAll('.qcm-box')[i % na].click();
  });
  paginate();
  return ED.querySelectorAll('.qcm-q').length;
}"""

with open_app() as page:
    # ═══ 1. correction par question ═══
    page.evaluate(MK, [3, 4])
    chk('bouton ✎ sur chaque question',
        page.evaluate("() => ED.querySelectorAll('.qcm-corr-q-btn').length") == 3)
    chk('commentaire masqué au départ',
        page.evaluate("() => ED.querySelector('.qcm-q-corr-wrap').style.display") == 'none')
    page.evaluate("() => ED.querySelectorAll('.qcm-corr-q-btn')[1].click()")
    chk('✎ ouvre le commentaire de LA question',
        page.evaluate("""() => { const w = [...ED.querySelectorAll('.qcm-q-corr-wrap')];
          return w[1].style.display !== 'none' && w[0].style.display === 'none'; }"""))
    chk('commentaire éditable',
        page.evaluate("() => ED.querySelectorAll('.qcm-q-corr')[1].getAttribute('contenteditable')") == 'true')
    page.evaluate("""() => { ED.querySelectorAll('.qcm-q-corr')[1].textContent = 'On divise la marge par le coût d\\'achat.';
      ED.querySelectorAll('.qcm-corr-q-btn')[0].click();
      ED.querySelectorAll('.qcm-q-corr')[0].textContent = 'Commentaire de la question 1.'; }""")
    chk('deux commentaires distincts',
        page.evaluate("""() => [...ED.querySelectorAll('.qcm-q-corr')].map(c => c.textContent).filter(Boolean).length""") == 2)
    chk('commentaires masqués en vue élève',
        page.evaluate("""() => { ED.querySelector('.qcm-corr-btn').click();
          return getComputedStyle(ED.querySelector('.qcm-q-corr-wrap')).display === 'none'; }"""))
    page.evaluate("() => ED.querySelector('.qcm-corr-btn').click()")
    chk('commentaires revenus en vue professeur',
        page.evaluate("""() => getComputedStyle(ED.querySelectorAll('.qcm-q-corr-wrap')[1]).display !== 'none'"""))

    # ═══ 2. corbeille ═══
    chk('bouton corbeille présent', page.evaluate("() => !!ED.querySelector('.qcm-trash')"))
    page.evaluate("() => ED.querySelector('.qcm-trash').click()")
    chk('fenêtre de confirmation ouverte',
        page.evaluate("() => document.getElementById('m-qcm-del').classList.contains('on')"))
    chk('le QCM annonce ses 3 questions',
        '3 question' in page.evaluate("() => document.getElementById('qcm-del-txt').textContent"))
    page.evaluate("() => closeM('m-qcm-del')")
    chk('annuler ne supprime rien', page.evaluate("() => ED.querySelectorAll('.qcm-block').length") == 1)
    page.evaluate("() => { ED.querySelector('.qcm-trash').click(); qcmConfirmDelete(); }")
    chk('confirmer supprime tout le QCM',
        page.evaluate("() => ED.querySelectorAll('.qcm-block').length") == 0)
    chk('rien ne reste dans le document',
        page.evaluate("() => ED.querySelectorAll('.qcm-q,.qcm-head,.qcm-corr-wrap').length") == 0)
    page.wait_for_timeout(250); page.evaluate("() => doUndo()")
    page.wait_for_timeout(150)
    chk('Ctrl+Z restaure le QCM', page.evaluate("() => ED.querySelectorAll('.qcm-block').length") == 1)

    # ═══ 3. coupure de page ═══
    page.evaluate(MK, [14, 4])
    page.wait_for_timeout(400)
    chk('QCM long : plusieurs pages',
        page.evaluate("() => document.querySelectorAll('.pg-auto').length") >= 1)
    chk('espaceur placé À L\'INTÉRIEUR du QCM',
        page.evaluate("() => !!ED.querySelector('.qcm-body > .pg-auto')"))
    intact = page.evaluate("""() => {
      const MM = 96/25.4, PAGE_H = 297*MM, PAD = 22*MM, PITCH = PAGE_H + 28, CH = PAGE_H - 2*PAD - 8;
      const base = ED.getBoundingClientRect().top + PAD;
      const bad = [];
      ED.querySelectorAll('.qcm-q').forEach((q, i) => {
        const r = q.getBoundingClientRect(), top = r.top - base;
        const p = Math.floor((top + 3) / PITCH);
        if (top + r.height > p*PITCH + CH + 1) bad.push([i+1, Math.round(top), Math.round(r.height)]);
      });
      return bad;
    }""")
    chk('aucune question coupée entre deux pages', intact == [], intact)
    chk('en-tête et 1re question sur la même page',
        page.evaluate("""() => {
          const MM = 96/25.4, PITCH = 297*MM + 28, base = ED.getBoundingClientRect().top + 22*MM;
          const pg = el => Math.floor((el.getBoundingClientRect().top - base + 3) / PITCH);
          return pg(ED.querySelector('.qcm-head')) === pg(ED.querySelector('.qcm-q'));
        }"""))
    chk('le bloc reste d\'un seul tenant dans le DOM',
        page.evaluate("() => ED.querySelectorAll('.qcm-block').length") == 1
        and page.evaluate("() => ED.querySelector('.qcm-block').querySelectorAll('.qcm-q').length") == 14)
    chk('les outils de page connaissent toutes les pages',
        page.evaluate("() => pgInfo.groups.length") == page.evaluate("() => pgInfo.pages"))
    chk('aucun fragment de QCM dans les groupes de page',
        page.evaluate("""() => pgInfo.groups.every(g => g.every(n => n.parentElement === ED))"""))

    # une opération de page ne doit pas démembrer le QCM
    page.evaluate("() => pageOp('ins', 0)")
    page.wait_for_timeout(300)
    chk('après insertion de page, le QCM est intact',
        page.evaluate("() => ED.querySelectorAll('.qcm-block').length") == 1
        and page.evaluate("() => ED.querySelector('.qcm-block').querySelectorAll('.qcm-q').length") == 14)

    # ═══ 4. export : vérification en orange ═══
    page.evaluate(MK, [2, 3])
    page.evaluate("""() => {
      ED.querySelectorAll('.qcm-corr-q-btn')[0].click();
      ED.querySelectorAll('.qcm-q-corr')[0].textContent = 'EXPLICATION_Q1 : on applique la formule.';
    }""")
    html = page.evaluate("""() => {
      let out = '';
      const a0 = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function(){};
      const oldBlob = window.Blob;
      window.Blob = function(parts, opts){ out = parts.join(''); return new oldBlob(parts, opts); };
      try { exportWeb(); } finally { window.Blob = oldBlob; HTMLAnchorElement.prototype.click = a0; }
      return out;
    }""")
    chk('export : commentaire de question conservé', 'EXPLICATION_Q1' in html)
    chk('export : commentaire masqué au départ', 'qcm-q-corr-hidden' in html)
    chk('export : corbeille et ✎ retirés', 'qcm-trash' not in html and 'qcmToggleQCorr' not in html)
    tmp = pathlib.Path(tempfile.mkdtemp()) / 'export.html'
    tmp.write_text(html, encoding='utf-8')
    chk('aucune erreur JS dans l\'éditeur', not page.errors, page.errors[:3])

with open_app(app=tmp) as ex:
    chk('export : commentaire invisible avant vérification',
        ex.evaluate("""() => getComputedStyle(document.querySelector('.qcm-q-corr-hidden')).display === 'none'"""))
    # q1 : bonne réponse = index 0 ; q2 : bonne réponse = index 1
    ex.evaluate("""() => {
      const qs = document.querySelectorAll('.qcm-q');
      qs[0].querySelectorAll('.qcm-box')[0].click();   /* juste */
      qs[1].querySelectorAll('.qcm-box')[2].click();   /* faux  */
      document.querySelector('.qcm-check').click();
    }""")
    ORANGE = 'rgb(234, 140, 0)'
    chk('bonne réponse cochée : case orange',
        ex.evaluate("""() => getComputedStyle(document.querySelectorAll('.qcm-q')[0]
            .querySelectorAll('.qcm-box')[0]).backgroundColor""") == ORANGE)
    chk('bonne réponse manquée : case orange aussi',
        ex.evaluate("""() => getComputedStyle(document.querySelectorAll('.qcm-q')[1]
            .querySelectorAll('.qcm-box')[1]).backgroundColor""") == ORANGE)
    chk('case cochée à tort : rouge',
        ex.evaluate("""() => getComputedStyle(document.querySelectorAll('.qcm-q')[1]
            .querySelectorAll('.qcm-box')[2]).backgroundColor""") == 'rgb(220, 38, 38)')
    chk('case juste non concernée : reste vide',
        ex.evaluate("""() => getComputedStyle(document.querySelectorAll('.qcm-q')[0]
            .querySelectorAll('.qcm-box')[1]).backgroundColor""") == 'rgb(255, 255, 255)')
    chk('score correct',
        re.search(r'1\s*/\s*2', ex.evaluate("() => document.querySelector('.qcm-score').textContent")))
    chk('commentaire révélé après vérification',
        ex.evaluate("""() => getComputedStyle(document.querySelector('.qcm-q-corr-hidden')).display !== 'none'"""))
    ex.evaluate("() => document.querySelector('.qcm-check').click()")
    chk('Recommencer remasque le commentaire',
        ex.evaluate("""() => getComputedStyle(document.querySelector('.qcm-q-corr-hidden')).display === 'none'"""))
    chk('Recommencer remet les cases à zéro',
        ex.evaluate("""() => [...document.querySelectorAll('.qcm-a')].every(a => a.className === 'qcm-a')"""))
    chk('export : aucune erreur JS', not ex.errors, ex.errors[:3])

print('\n%d PASS / %d FAIL' % (P, F))
