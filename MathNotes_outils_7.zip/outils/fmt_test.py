from harness import open_app
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:160])
with open_app() as page:
    cas = page.evaluate("""() => [
      [0,'0 o'],[512,'512 o'],[1024,'1 Ko'],[204800,'200 Ko'],
      [1048576,'1,0 Mo'],[3670016,'3,5 Mo'],[52428800,'50 Mo'],
      [1073741824,'1,0 Go'],[10737418650,'10 Go'],[483183820,'461 Mo']
    ].map(([o,attendu]) => [o, fmtSize(o), attendu])""")
    for o,obtenu,attendu in cas:
        chk('%11d → %s' % (o,obtenu), obtenu == attendu, 'attendu '+attendu)
    lbl = page.evaluate("""async () => {
      renderLibUsage();
      await new Promise(r=>setTimeout(r,300));
      return document.getElementById('lib-usage').textContent;
    }""")
    print('\n  libellé :', lbl)
    import re as _re
    trop = [m for m in _re.findall(r'([\d ]+)(?:,\d+)? Mo', lbl)
            if int(m.replace(' ','') or 0) >= 1024]
    chk('aucune valeur ≥ 1024 affichée en Mo', not trop, (lbl, trop))
    chk('l\'occupé est annoncé en premier', lbl.index('utilisés') < lbl.index('autorise'), lbl)
    chk('aucune erreur JS', not page.errors, page.errors[:2])
print('\n%d PASS / %d FAIL' % (P,F))
