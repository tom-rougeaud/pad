# -*- coding: utf-8 -*-
"""Stockage large : capacité, migration vérifiée, repli, intégrité."""
from harness import open_app
P=F=0
def chk(l,c,e=''):
    global P,F
    if c: P+=1; print('PASS',l)
    else: F+=1; print('FAIL',l,repr(e)[:220])

with open_app() as page:
    page.wait_for_timeout(600)
    chk('base locale ouverte', page.evaluate("() => !!DB"))
    chk('un cours existe', page.evaluate("() => LIB.docs.length") == 1)
    chk('demande de conservation émise',
        page.evaluate("() => typeof askPersist === 'function'"))

    # ── capacité réelle ──
    u = page.evaluate("async () => await docUsage()")
    print('    espace annoncé : %.0f Mo disponibles' % (u['quota']/1048576))
    chk('capacité très supérieure à 5 Mo', u['quota'] > 50*1024*1024, u['quota'])
    chk('la jauge se fonde sur la place réelle', u['reel'])

    # ── un cours lourd passe ──
    r = page.evaluate("""async () => {
      const gros = '<h1>Cours lourd</h1><p>' + 'A'.repeat(12*1024*1024) + '</p>';
      ED.innerHTML = gros;
      const ok = await saveDoc(false);
      delete DOC_CACHE[LIB.cur];
      const relu = await docGet(LIB.cur);
      return {ok, taille_Mo:+(gros.length/1048576).toFixed(1),
              relu_identique: relu === cleanHTML(),
              alerte: document.getElementById('storage-alert').classList.contains('on')};
    }""")
    chk('un cours de %s Mo s\'enregistre' % r['taille_Mo'], r['ok'] and not r['alerte'], r)
    chk('et se relit à l\'identique', r['relu_identique'])
    print('    → %s Mo acceptés, contre 5 Mo pour la totalité auparavant' % r['taille_Mo'])

    # ── migration depuis l'ancien emplacement ──
    m = page.evaluate("""async () => {
      // on simule deux cours écrits par l'ancienne version
      localStorage.clear();
      const a='da'+Date.now().toString(36), b='db'+Date.now().toString(36);
      LIB={cur:a,docs:[{id:a,title:'Ancien A',updated:1,size:0},{id:b,title:'Ancien B',updated:1,size:0}]};
      libSave();
      localStorage.setItem('mn_doc_'+a,'<h1>Contenu ancien A</h1>');
      localStorage.setItem('mn_doc_'+b,'<h1>Contenu ancien B</h1>');
      localStorage.setItem('mn_backup','<h1>Secours ancien</h1>');
      delete DOC_CACHE[a]; delete DOC_CACHE[b]; delete DOC_CACHE['__backup__'];
      const repris = await docMigrate();
      delete DOC_CACHE[a]; delete DOC_CACHE[b]; delete DOC_CACHE['__backup__'];
      return {repris,
              a_en_base: await docGet(a), b_en_base: await docGet(b),
              secours_en_base: await docGet('__backup__'),
              ancien_a_efface: localStorage.getItem('mn_doc_'+a)===null,
              ancien_b_efface: localStorage.getItem('mn_doc_'+b)===null,
              ancien_secours_efface: localStorage.getItem('mn_backup')===null};
    }""")
    chk('les 2 cours anciens sont repris', m['repris'] == 2, m['repris'])
    chk('contenu A transféré fidèlement', 'Contenu ancien A' in (m['a_en_base'] or ''))
    chk('contenu B transféré fidèlement', 'Contenu ancien B' in (m['b_en_base'] or ''))
    chk('copie de secours transférée', 'Secours ancien' in (m['secours_en_base'] or ''))
    chk('ancien emplacement libéré, après relecture',
        m['ancien_a_efface'] and m['ancien_b_efface'] and m['ancien_secours_efface'])

    # ── migration refusée : on ne détruit rien ──
    s = page.evaluate("""async () => {
      const c='dc'+Date.now().toString(36);
      LIB={cur:c,docs:[{id:c,title:'Fragile',updated:1,size:0}]}; libSave();
      localStorage.setItem('mn_doc_'+c,'<h1>Ne pas perdre</h1>');
      delete DOC_CACHE[c];
      const vrai = DB;                      // on coupe la base le temps du test
      DB = null;
      const repris = await docMigrate();
      DB = vrai;
      return {repris, ancien_intact: localStorage.getItem('mn_doc_'+c)};
    }""")
    chk('sans base locale, aucune reprise', s['repris'] == 0)
    chk('et l\'ancienne copie reste intacte', 'Ne pas perdre' in (s['ancien_intact'] or ''))

    # ── repli complet sur l'ancien emplacement ──
    f = page.evaluate("""async () => {
      const vrai = DB; DB = null;
      const id = 'dr'+Date.now().toString(36);
      delete DOC_CACHE[id];
      const ok = await docPut(id, '<h1>Par repli</h1>');
      delete DOC_CACHE[id];
      const relu = await docGet(id);
      const ou = localStorage.getItem('mn_doc_'+id) !== null;
      await docDel(id);
      DB = vrai;
      return {ok, relu, dans_ancien_emplacement: ou};
    }""")
    chk('repli : l\'écriture réussit quand même', f['ok'])
    chk('repli : la relecture est fidèle', 'Par repli' in (f['relu'] or ''))
    chk('repli : les données vont bien dans l\'ancien emplacement', f['dans_ancien_emplacement'])


    # ── persistance après rechargement complet ──
    page.evaluate("""async () => {
      localStorage.clear();                       /* on repart d'une bibliothèque propre */
      LIB = {cur:'', docs:[]}; libInit();
      ED.innerHTML = '<h1>Cours qui doit survivre</h1><p>REPERE_PERSISTANT</p>';
      document.getElementById('doc-title').textContent = 'Survivant';
      setTitleManual(true);            /* comme si le professeur l'avait saisi */
      await saveDoc(false);
    }""")
    page.wait_for_timeout(300)
    reste_en_local = page.evaluate(
        "() => Object.keys(localStorage).filter(k => k.indexOf('mn_doc_') === 0).length")
    chk('rien n\'encombre plus l\'ancien emplacement', reste_en_local == 0, reste_en_local)
    page.reload(); page.wait_for_timeout(1200)
    chk('le cours revient après rechargement',
        'REPERE_PERSISTANT' in page.evaluate("() => ED.textContent"))
    chk('le titre saisi est restauré',
        page.evaluate("() => document.getElementById('doc-title').textContent") == 'Survivant',
        page.evaluate("() => document.getElementById('doc-title').textContent"))

    # ── le cas qui bloquait : plusieurs photos ──
    photos = page.evaluate("""async () => {
      const photo = n => {
        const cv = document.createElement('canvas'); cv.width = 1600; cv.height = 1200;
        const cx = cv.getContext('2d');
        const g = cx.createLinearGradient(0,0,1600,1200);
        g.addColorStop(0,'#6b8fbf'); g.addColorStop(1,'#3a6b45');
        cx.fillStyle = g; cx.fillRect(0,0,1600,1200);
        for (let i=0;i<140;i++){
          const rg = cx.createRadialGradient(Math.random()*1600,Math.random()*1200,2,
                                             Math.random()*1600,Math.random()*1200,260);
          rg.addColorStop(0,'rgba('+((i*n)%220)+',120,90,.5)'); rg.addColorStop(1,'rgba(0,0,0,0)');
          cx.fillStyle = rg; cx.fillRect(0,0,1600,1200);
        }
        return cv.toDataURL('image/jpeg', 0.85);
      };
      ED.innerHTML = '<h1>Cours très illustré</h1>';
      let n = 0, octets = 0;
      for (; n < 30; n++) {
        const w = document.createElement('div'); w.className = 'media-block';
        const img = document.createElement('img'); img.src = photo(n+1);
        w.appendChild(img); ED.appendChild(w);
        const ok = await saveDoc(false);
        if (!ok) break;
        octets = cleanHTML().length;
      }
      return {photos: n, Mo: +(octets/1048576).toFixed(1),
              alerte: document.getElementById('storage-alert').classList.contains('on')};
    }""")
    chk('30 photos dans un même cours, sans alerte',
        photos['photos'] == 30 and not photos['alerte'], photos)
    print('    %d photos · %s Mo dans un seul cours (limite précédente : 5 Mo pour tout)'
          % (photos['photos'], photos['Mo']))

    chk('aucune erreur JS', not page.errors, page.errors[:3])
print('\n%d PASS / %d FAIL' % (P,F))
