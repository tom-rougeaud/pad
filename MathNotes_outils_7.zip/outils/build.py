# -*- coding: utf-8 -*-
"""Chaîne de fabrication de MathNotes.

    python3 build.py source   MathNotes.html  → MathNotes_source.html
        Retire KaTeX du fichier et le remplace par un appel au CDN.
        Version légère (≈ 490 Ko), faite pour être éditée et transmise.

    python3 build.py dist     MathNotes_source.html → MathNotes.html
        Intègre KaTeX et ses polices. Version à publier (≈ 1,10 Mo),
        qui fonctionne sans aucun accès réseau.

Les deux sens sont rejouables : fabriquer puis défabriquer redonne le
fichier de départ, aux repères près. Le bloc concerné est délimité par
<!-- KATEX:DEBUT --> … <!-- KATEX:FIN -->.
"""
import base64, pathlib, re, sys

DIST = pathlib.Path('node_modules/katex/dist')
CDN = ('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">\n'
       '<script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>')
BLOC = re.compile(r'<!-- KATEX:DEBUT -->.*?<!-- KATEX:FIN -->', re.S)


def embarquer():
    """CSS de KaTeX avec ses polices en données intégrées, + le script."""
    css = (DIST / 'katex.min.css').read_text(encoding='utf-8')
    polices = {f.name: base64.b64encode(f.read_bytes()).decode()
               for f in (DIST / 'fonts').glob('*.woff2')}

    def src(m):
        nom = re.search(r'url\(fonts/([\w-]+)\.woff2\)', m.group(1))
        if not nom:
            return m.group(0)
        b64 = polices.get(nom.group(1) + '.woff2')
        return ('src:url(data:font/woff2;base64,%s) format("woff2")' % b64) if b64 else m.group(0)

    css = re.sub(r'src:((?:url\([^)]*\)\s*format\("[^"]*"\),?\s*)+)', src, css)
    assert 'fonts/' not in css, 'des polices restent externes'
    js = (DIST / 'katex.min.js').read_text(encoding='utf-8')
    assert '</script' not in js.lower(), 'le script contient une balise fermante'
    return ('<!-- KATEX:DEBUT -->\n'
            '<style id="katex-style">/* KaTeX 0.16.9 — MIT — embarqué, polices comprises */\n'
            + css + '</style>\n'
            '<script id="katex-js">/* KaTeX 0.16.9 — MIT */\n' + js + '\n</script>\n'
            '<!-- KATEX:FIN -->'), len(polices)


def main():
    if len(sys.argv) < 3 or sys.argv[1] not in ('source', 'dist'):
        sys.exit(__doc__)
    sens, entree = sys.argv[1], pathlib.Path(sys.argv[2])
    sortie = pathlib.Path(sys.argv[3]) if len(sys.argv) > 3 else pathlib.Path(
        'MathNotes_source.html' if sens == 'source' else 'MathNotes.html')
    src = entree.read_text(encoding='utf-8')
    if not BLOC.search(src):
        sys.exit('Repères KATEX absents du fichier : il n\'est pas fabricable.')

    if sens == 'source':
        out = BLOC.sub('<!-- KATEX:DEBUT -->\n' + CDN + '\n<!-- KATEX:FIN -->', src)
        note = 'KaTeX appelé par le CDN'
    else:
        bloc, n = embarquer()
        out = BLOC.sub(lambda _: bloc, src)
        note = 'KaTeX embarqué (%d polices)' % n

    sortie.write_text(out, encoding='utf-8')
    print('%s → %s | %s | %.2f Mo'
          % (entree.name, sortie.name, note, len(out.encode()) / 1048576))


if __name__ == '__main__':
    main()
